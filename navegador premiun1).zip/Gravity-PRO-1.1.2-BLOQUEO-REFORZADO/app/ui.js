'use strict';
// Gravity PRO. Toda la interfaz vive en HTML local, sin ejecutar código de los sitios externos.
const $ = selector => document.querySelector(selector);
const api = window.gravity;
const HOME='gravity://home';
const emptyState={tabs:[],active:'',bookmarks:[],history:[],shortcuts:[],downloads:[],tabGroups:[],settings:{},permissions:[]};
let snapshot=emptyState;
let noticeTimer;
let submitting=false;
let suggestionsTimer;
let suggestions=[];
let suggestionIndex=-1;
let downloadOpen=false;
let draggingId='';
let lastTabKey='';

function notice(value){
  const node=$('#notice');node.textContent=String(value);
  node.style.display='block';clearTimeout(noticeTimer);
  noticeTimer=setTimeout(()=>{node.style.display='none'},4400);
}
async function command(action,value){
  if(!api){notice('Abre Gravity con INICIAR-GRAVITY-WINDOWS.bat; el HTML no es el navegador.');return false}
  try{return await api.command(action,value)}catch(error){notice(error.message||String(error));return false}
}
function text(body,value){const p=document.createElement('p');p.textContent=value;body.append(p);return p}
function action(body,label,handler){
  const button=document.createElement('button');button.className='action';button.textContent=label;
  button.onclick=handler;body.append(button);return button;
}
function heading(body,label){const p=document.createElement('div');p.className='panel-heading';p.textContent=label;body.append(p)}
function closePanel(){if($('#panel').open)$('#panel').close();void command('overlay',false)}
$('#closePanel').onclick=closePanel;
$('#panel').addEventListener('close',()=>{downloadOpen=false;void command('overlay',false)});
function panel(title,build){
  closeSuggestions();downloadOpen=false;
  $('#panelTitle').textContent=title;$('#panelBody').replaceChildren();
  build($('#panelBody'));
  void command('overlay',true);
  if(!$('#panel').open)$('#panel').showModal();
}
function field(body,label,value,placeholder){
  const wrapper=document.createElement('label');wrapper.className='field';
  wrapper.textContent=label;
  const input=document.createElement('input');input.value=value||'';input.placeholder=placeholder||'';
  wrapper.append(input);body.append(wrapper);return input;
}
async function submit(value){
  if(submitting||!String(value||'').trim())return;
  submitting=true;
  closeSuggestions();
  try{
    if($('#panel').open)closePanel();
    await command('navigate',value);
  }finally{submitting=false}
}
$('#searchForm').onsubmit=event=>{event.preventDefault();void submit(suggestions[suggestionIndex]?.url||$('#query').value)};
$('#addressForm').onsubmit=event=>{event.preventDefault();void submit($('#address').value);$('#address').blur()};
for(const id of ['new','back','forward','home','min','max','quit'])$('#'+id).onclick=()=>void command(id);
$('#reload').onclick=()=>{const tab=snapshot.tabs.find(t=>t.id===snapshot.active);void command(tab?.loading?'stop':'reload')};
$('#retry').onclick=()=>void command('reload');$('#returnHome').onclick=()=>void command('home');
$('#bookmark').onclick=()=>void command('bookmark');

const defaults=[
  ['YouTube','https://www.youtube.com','youtube.svg'],
  ['Google','https://www.google.com','google.svg'],
  ['Facebook','https://www.facebook.com','facebook.svg'],
  ['Instagram','https://www.instagram.com','instagram.svg'],
  ['Gmail','https://mail.google.com','gmail.svg'],
  ['Netflix','https://www.netflix.com','netflix.svg'],
  ['Amazon','https://www.amazon.com','amazon-a.svg']
];
let shortcutsKey='';
function renderLinks(){
  const key=JSON.stringify(snapshot.shortcuts);
  if(key===shortcutsKey&&$('#shortcuts').children.length)return;
  shortcutsKey=key;$('#shortcuts').replaceChildren();
  for(const link of [...defaults.map(([name,url,icon])=>({name,url,icon})),...snapshot.shortcuts]){
    const wrapper=document.createElement('div');wrapper.className='shortcut';
    const launch=document.createElement('button');launch.className='launch';launch.title=link.url;
    const tile=document.createElement('span');tile.className='tile';
    if(link.icon){const img=document.createElement('img');img.src='assets/'+link.icon;img.alt='';tile.append(img)}
    else{const letter=document.createElement('span');letter.className='letter';letter.textContent=link.name[0].toUpperCase();tile.append(letter)}
    const label=document.createElement('small');label.textContent=link.name;
    launch.append(tile,label);launch.onclick=()=>void submit(link.url);wrapper.append(launch);
    if(link.id){
      const remove=document.createElement('button');remove.className='remove';remove.textContent='×';remove.title='Eliminar '+link.name;
      remove.onclick=()=>void command('removeShortcut',link.id);wrapper.append(remove);
    }
    $('#shortcuts').append(wrapper);
  }
  if(snapshot.shortcuts.length<5){
    const wrapper=document.createElement('div');wrapper.className='shortcut';
    const button=document.createElement('button');button.className='launch';
    const tile=document.createElement('span');tile.className='tile';tile.textContent='+';tile.style.fontSize='35px';
    const label=document.createElement('small');label.textContent='Añadir';
    button.append(tile,label);button.onclick=addShortcut;wrapper.append(button);$('#shortcuts').append(wrapper);
  }
}
function addShortcut(){
  panel('Añadir acceso',body=>{
    const form=document.createElement('form');
    const name=field(form,'Nombre','','Mi sitio');name.required=true;name.maxLength=24;
    const url=field(form,'Dirección','','https://ejemplo.com');url.required=true;
    const save=action(form,'Guardar',()=>{});save.type='submit';
    form.onsubmit=async event=>{
      event.preventDefault();if(await command('addShortcut',{name:name.value,url:url.value})!==false)closePanel();
    };body.append(form);
  });
}
function showList(type){
  const favorites=type==='bookmarks';
  panel(favorites?'Favoritos':'Historial',body=>{
    const search=document.createElement('input');search.className='panel-search';search.type='search';
    search.placeholder=favorites?'Buscar en favoritos…':'Buscar en historial…';
    search.setAttribute('aria-label','Filtrar resultados');body.append(search);
    const results=document.createElement('div');body.append(results);
    function render(){
      const query=search.value.trim().toLocaleLowerCase();results.replaceChildren();
      const items=(snapshot[type]||[]).filter(x=>(x.title+' '+x.url).toLocaleLowerCase().includes(query)).slice(0,250);
      if(!items.length)text(results,'No se encontraron entradas.');
      for(const item of items){
        const row=document.createElement('div');row.className='listrow';
        const button=document.createElement('button');button.className='item';
        button.textContent=(item.title||item.url)+' · '+item.url;button.title=item.url;
        button.onclick=()=>{closePanel();void submit(item.url)};row.append(button);
        if(favorites){
          const remove=document.createElement('button');remove.textContent='×';remove.title='Quitar favorito';
          remove.onclick=async()=>{await command('removeBookmark',item.url);render()};row.append(remove);
        }else{
          const time=document.createElement('time');time.className='download-meta';
          time.textContent=item.time?new Date(item.time).toLocaleDateString('es'):'';row.append(time);
        }
        results.append(row);
      }
    }
    search.oninput=render;render();
    if(favorites){
      heading(body,'Copias e intercambio de favoritos');
      action(body,'Importar favoritos desde HTML',async()=>{
        const result=await command('importBookmarks');
        if(result&&result!==false&&!result.cancelled){
          if(!result.imported)notice('Todos esos favoritos ya estaban guardados.');
          render();
        }
      });
      action(body,'Exportar favoritos a HTML',async()=>{await command('exportBookmarks')});
      text(body,'Compatible con archivos HTML de favoritos de otros navegadores. No se importan contraseñas ni cookies.');
    }
    if(!favorites)action(body,'Borrar historial',async()=>{await command('clearHistory');render()});
  });
}
function formatBytes(bytes){
  const count=Math.max(0,Number(bytes)||0);if(!count)return '0 B';
  const i=Math.min(3,Math.floor(Math.log(count)/Math.log(1024)));
  return `${(count/Math.pow(1024,i)).toFixed(i?1:0)} ${['B','KB','MB','GB'][i]}`;
}
function updateDownloads(body){
  if(!downloadOpen)return;
  const target=$('#downloadItems');if(!target)return;
  target.replaceChildren();
  if(!snapshot.downloads.length)text(target,'No hay descargas todavía.');
  for(const item of snapshot.downloads){
    const row=document.createElement('div');row.className='download-row';
    const name=document.createElement('div');name.className='download-name';name.textContent=item.name+(item.privateTab?' · Privada':'');row.append(name);
    const meta=document.createElement('div');meta.className='download-meta';
    const states={progressing:item.paused?'En pausa':'Descargando',completed:'Completada',cancelled:'Cancelada',interrupted:'Interrumpida'};
    const checks={'analizando':' · Revisando con Defender…','alert':' · ⚠️ Revisar Seguridad de Windows','review':' · Escaneo finalizado (comprobar Windows)','unavailable':' · Antivirus no disponible'};
    meta.textContent=`${states[item.status]||item.status} · ${formatBytes(item.received)}${item.total?' de '+formatBytes(item.total):''}${checks[item.scanStatus]||''}`;
    row.append(meta);
    if(item.status==='progressing'){
      const bar=document.createElement('div');bar.className='download-bar';
      const fill=document.createElement('div');fill.className='download-progress';
      fill.style.width=item.total?Math.max(0,Math.min(100,item.received/item.total*100))+'%':'10%';bar.append(fill);row.append(bar);
      action(row,item.paused?'Reanudar':'Pausar',()=>void command('downloadAction',{id:item.id,action:item.paused?'resume':'pause'}));
      action(row,'Cancelar',()=>void command('downloadAction',{id:item.id,action:'cancel'}));
    }else{
      if(item.status==='completed'){
        action(row,'Mostrar en carpeta',()=>void command('downloadAction',{id:item.id,action:'folder'}));
        action(row,'Analizar con Microsoft Defender',()=>void command('downloadAction',{id:item.id,action:'scan'}));
        action(row,'Abrir archivo',()=>void command('downloadAction',{id:item.id,action:'open'}));
      }
      action(row,'Quitar de la lista',()=>void command('downloadAction',{id:item.id,action:'clear'}));
    }
    target.append(row);
  }
}
function downloadsPanel(){
  panel('Descargas',body=>{
    downloadOpen=true;
    text(body,'Los archivos se guardan en Descargas, a menos que actives «Preguntar ubicación» en Ajustes.');
    action(body,'Abrir carpeta Descargas',()=>void command('downloadFolder'));
    const items=document.createElement('div');items.id='downloadItems';body.append(items);
    updateDownloads(body);
  });
}
function createSetting(body,label,description,key){
  const row=document.createElement('label');row.className='setting';
  const wrapper=document.createElement('span');wrapper.className='setting-label';wrapper.textContent=label;
  const note=document.createElement('span');note.className='setting-note';note.textContent=description;wrapper.append(note);
  const check=document.createElement('input');check.type='checkbox';check.checked=Boolean(snapshot.settings[key]);
  check.onchange=async()=>{if(await command('settings',{key,value:check.checked})===false)check.checked=!check.checked};
  row.append(wrapper,check);body.append(row);
}
function settingsPanel(){
  panel('Ajustes de Gravity',body=>{
    heading(body,'Buscador predeterminado');
    const select=document.createElement('select');select.className='settings-select';select.setAttribute('aria-label','Motor de búsqueda');
    for(const [name,label] of [['google','Google'],['duckduckgo','DuckDuckGo'],['bing','Bing']]){
      const option=document.createElement('option');option.value=name;option.textContent=label;option.selected=name===snapshot.settings.searchEngine;select.append(option);
    }
    select.onchange=()=>void command('settings',{key:'searchEngine',value:select.value});body.append(select);
    heading(body,'Sesión y privacidad');
    createSetting(body,'Restaurar pestañas','Recupera las pestañas normales y su orden al abrir Gravity.','restoreTabs');
    createSetting(body,'Escudos de Gravity: bloquear publicidad y rastreadores','Activados por defecto en perfiles nuevos. Basados en dominios y listas opcionales, con excepciones por sitio. No pueden eliminar todos los anuncios.','blockTrackers');
    createSetting(body,'Bloquear cookies de terceros','Intenta impedir cookies de solicitudes cruzadas; puede afectar algunos inicios de sesión integrados. No equivale a aislamiento total del almacenamiento.','blockThirdPartyCookies');
    createSetting(body,'Actualizar filtros de protección automáticamente','Activado por defecto. Cada 7 días descarga filtros por HTTPS cuando hace falta; el proveedor recibe la conexión y puede ver tu IP, pero Gravity no envía tu historial ni búsquedas.','autoUpdateFilterLists');
    createSetting(body,'Eliminar datos de sitios al cerrar Gravity','Opcional: elimina cookies y almacenamiento local al salir. Cierra tus sesiones; no borra nada de servidores externos.','clearSiteDataOnExit');
    action(body,'Actualizar listas públicas de protección',async()=>{const result=await command('updateFilterLists');if(result?.updated)notice('Filtros locales actualizados.')});
    createSetting(body,'Preguntar dónde guardar descargas','Si se desactiva, los archivos se guardan automáticamente en Descargas.','askDownloadLocation');
    createSetting(body,'Ahorro de memoria automático (opcional)','Desactivado por defecto. Solo páginas simples inactivas 30 min. Puede recargar páginas al volver; nunca se garantiza conservar formularios de aplicaciones complejas.','autoSleepTabs');
    const tab=snapshot.tabs.find(t=>t.id===snapshot.active);
    if(tab?.url?.startsWith('http')&&!tab.private){
      const siteOrigin=new URL(tab.url).origin;
      const excluded=(snapshot.settings.trackerExceptions||[]).includes(siteOrigin);
      const site=document.createElement('label');site.className='setting';
      const textNode=document.createElement('span');textNode.className='setting-label';textNode.textContent='Permitir rastreadores en este sitio';
      const note=document.createElement('small');note.className='setting-note';note.textContent=siteOrigin;textNode.append(note);
      const check=document.createElement('input');check.type='checkbox';check.checked=excluded;
      check.onchange=()=>void command('settings',{key:'trackerSite',value:check.checked});
      site.append(textNode,check);body.append(site);
    }
    heading(body,'Gestión local');
    action(body,'Ver descargas',downloadsPanel);
    action(body,'Borrar cookies y caché',async()=>{await command('clearSites')});
    action(body,'Revocar permisos',async()=>{await command('clearPermissions');notice('Permisos temporales revocados')});
  });
}
function privacy(){
  panel('Privacidad y datos',body=>{
    text(body,'Gravity no dispone de un servidor de registro de navegación ni envía tus favoritos o historial a Gravity. Tus datos normales quedan en este equipo. Las páginas visitadas, el proveedor de Internet y el buscador seleccionado pueden conocer conexiones o consultas.');
    text(body,'El bloqueo de cookies de terceros no anula tu consentimiento legal ni elimina cookies del propio sitio: usa el ajuste de limpieza al cerrar para borrarlas localmente.');
    text(body,'Las pestañas privadas usan una sesión temporal separada y no guardan su historial en Gravity. Archivos descargados y actividad de red pueden seguir siendo visibles fuera de Gravity.');
    action(body,'Abrir pestaña privada',()=>{closePanel();void command('newPrivate')});
    action(body,'Borrar cookies y caché',()=>void command('clearSites'));
    action(body,'Revocar permisos de sitios',()=>void command('clearPermissions'));
    action(body,'Ver y configurar Escudos',settingsPanel);
    action(body,'Ver historial',()=>showList('history'));
  });
}
function security(){
  panel('Seguridad y protección',body=>{
    text(body,'Gravity aísla las páginas externas del código de la aplicación mediante sandbox, contextIsolation y la ausencia de Node.js en los sitios.');
    text(body,'El indicador HTTPS muestra cifrado de transporte, no que un sitio sea legítimo. Las páginas HTTP se señalan como no cifradas.');
    text(body,'Los Escudos bloquean muchos dominios de publicidad y rastreo, con filtros básicos locales ampliables por listas públicas. No garantizan cero anuncios, detección de todo malware, ni anonimato.');
    text(body,'Gravity NO cambia tu IP pública por una ficticia. Para ocultarla necesitas una VPN, Tor o un proxy real y bien configurado; estos servicios tienen límites y proveedores propios.');
    text(body,'Las advertencias de sitios sospechosos usan señales heurísticas y pueden fallar. Para archivos, Gravity ofrece análisis con Microsoft Defender si está instalado en Windows.');
    void command('shieldsStatus').then(status=>{
      if(status&&$('#panelTitle').textContent==='Seguridad y protección')text(body,`Escudos: ${status.enabled?'activos':'desactivados'} · reglas disponibles: ${status.rules} · cookies de terceros: ${status.crossSiteCookies?'bloqueadas parcialmente':'sin filtro adicional'}.`);
    });
    const t=snapshot.tabs.find(tab=>tab.id===snapshot.active);
    if(t?.blocked)text(body,`Peticiones de rastreo bloqueadas en esta pestaña: ${t.blocked}.`);
    if(snapshot.permissions?.length){
      heading(body,'Permisos temporales autorizados');
      for(const granted of snapshot.permissions){
        const tag=document.createElement('div');tag.className='download-meta';
        tag.textContent=`${granted.origin} · ${granted.permission} (${granted.partition})`;body.append(tag);
      }
      action(body,'Revocar permisos',()=>void command('clearPermissions'));
    }
    action(body,'Ajustes de protección',settingsPanel);
  });
}
function voice(){
  const target=$('#homepage').hidden?$('#address'):$('#query');
  target.focus();notice('Para dictar con Windows, usa Win+H en el campo de búsqueda.');
}
$('#security').onclick=security;$('#privacy').onclick=privacy;
$('#voice').onclick=voice;$('#voice2').onclick=voice;
function motionPanel(){
  panel('Movimiento del escenario',body=>{
    const effects=window.GravityEffects;
    if(!effects){text(body,'Preparando los recursos gráficos…');return}
    text(body,'Las animaciones originales se mantienen. Se reactivan al regresar al inicio.');
    const button=action(body,effects.isEnabled()?'Pausar todo':'Activar movimiento',()=>{
      effects.setEnabled(!effects.isEnabled(),true);
      button.textContent=effects.isEnabled()?'Pausar todo':'Activar movimiento';
    });
    for(const [key,label] of [['clouds','Nubes'],['planet','Planeta'],['water','Agua y reflejos'],['lava','Grietas luminosas'],['gold','Órbita y dorados']]){
      const row=document.createElement('label');row.className='setting';
      const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.checked=effects.config[key];
      checkbox.onchange=()=>effects.setLayer(key,checkbox.checked);row.append(label,checkbox);body.append(row);
    }
    const row=document.createElement('label');row.className='setting';row.append('Velocidad');
    const select=document.createElement('select');
    for(const [speed,label]of [[1,'Normal'],[1.7,'Demostración']]){
      const option=document.createElement('option');option.value=speed;option.textContent=label;option.selected=effects.config.speed===speed;select.append(option);
    }
    select.onchange=()=>effects.config.speed=Number(select.value);row.append(select);body.append(row);
  });
}
$('#motion').onclick=motionPanel;
function aboutPanel(){
  panel('Acerca de Gravity',body=>{
    heading(body,'Identidad del navegador');
    text(body,'Gravity es un navegador de escritorio en desarrollo, con una interfaz gráfica original.');
    text(body,'Esta edición es una candidata a lanzamiento para pruebas privadas, NO una versión pública validada.');
    text(body,'Los datos de navegación normales permanecen en el perfil local del equipo; no hay sincronización ni servidor configurado.');
    void command('about').then(info=>{
      if(!info)return;
      heading(body,'Información técnica');
      text(body,`Gravity ${info.version} · ${info.channel}`);
      text(body,`Electron ${info.electron} · Chromium ${info.chromium}`);
      text(body,`Perfil local: ${info.profile} · Actualizaciones: ${info.updates}`);
    });
    text(body,'El instalador y la firma digital deben verificarse antes de distribuir Gravity a otras personas.');
    action(body,'Comprobar actualizaciones oficiales',async()=>{const result=await command('checkUpdates');notice(result?.enabled?'Consulta iniciada.':'Las actualizaciones siguen desactivadas hasta configurar un canal oficial firmado y HTTPS.');});
  });
}
function diagnosticsPanel(){
  panel('Diagnóstico local · Gravity',body=>{
    text(body,'Los eventos técnicos permanecen en este equipo. Gravity no envía los registros a ningún servidor y no almacena URLs, cookies, búsquedas ni contraseñas en el diagnóstico.');
    void command('diagnostics').then(info=>{
      if(!info)return;
      heading(body,'Estado de procesos y pestañas');
      text(body,`Pestañas: ${info.tabCount} · Abiertas en memoria: ${info.liveTabs} · En reposo: ${info.suspendedTabs}`);
      text(body,`Privadas: ${info.privateTabs} · Descargas activas: ${info.activeDownloads}`);
      if(Number.isFinite(info.processMemoryMB))text(body,`Memoria estimada de procesos de Gravity: ${info.processMemoryMB} MB. La medición varía según el sistema y no representa toda la RAM del equipo.`);
      if(Number.isFinite(info.processCPUPercent))text(body,`CPU estimada de procesos de Gravity: ${info.processCPUPercent} %. Medición puntual, no promedio.`);
      else text(body,'Memoria de procesos no disponible en este entorno.');
      text(body,info.automaticSuspension?'Ahorro automático activado por el usuario: solo intenta suspender páginas sencillas e inactivas.':'El reposo automático está desactivado para proteger formularios. Puedes liberar memoria manualmente en el menú o activarlo voluntariamente en Ajustes.');
    });
    action(body,'Abrir carpeta de eventos locales',async()=>{
      const result=await command('diagnosticsFolder');
      if(typeof result==='string'&&result)notice('No se pudo abrir la carpeta de diagnóstico.');
    });
    text(body,'Antes de compartir registros, revísalos. Los diagnósticos no sustituyen pruebas de estabilidad en Windows.');
  });
}
// Herramientas 0.9.0: se muestran SOLO a petición, sin alterar el diseño de la portada.
function tabGroupsPanel(){
  const tab=snapshot.tabs.find(t=>t.id===snapshot.active);
  panel('Grupos de pestañas',body=>{
    text(body,'Organiza las pestañas por proyecto. Los grupos se conservan al reiniciar; no cierran ni reemplazan páginas.');
    const form=document.createElement('form');
    const name=field(form,'Nombre del nuevo grupo','','Trabajo, estudio, proyectos…');name.maxLength=32;name.required=true;
    const add=action(form,'Crear grupo',()=>{});add.type='submit';
    form.onsubmit=async ev=>{ev.preventDefault();const items=await command('createTabGroup',name.value);if(Array.isArray(items)){snapshot.tabGroups=items;tabGroupsPanel()}};
    body.append(form);
    heading(body,'Asignar grupo a la pestaña actual');
    const groupSelect=document.createElement('select');groupSelect.className='settings-select';groupSelect.setAttribute('aria-label','Grupo de pestaña');
    for(const value of ['',...(snapshot.tabGroups||[])]){
      const option=document.createElement('option');option.value=value;option.textContent=value||'Sin grupo';
      option.selected=value===(tab?.group||'');groupSelect.append(option);
    }
    groupSelect.onchange=async()=>{if(await command('setTabGroup',groupSelect.value)!==false)notice('Grupo de pestaña actualizado.')};
    body.append(groupSelect);
    heading(body,'Grupos disponibles');
    if(!(snapshot.tabGroups||[]).length)text(body,'Todavía no tienes grupos.');
    for(const group of snapshot.tabGroups||[]){
      const count=snapshot.tabs.filter(t=>t.group===group).length;
      const row=document.createElement('div');row.className='listrow';
      const label=document.createElement('span');label.textContent=`${group} (${count} pestaña(s))`;row.append(label);
      const first=snapshot.tabs.find(t=>t.group===group);
      if(first)action(row,'Ir',()=>{closePanel();void command('select',first.id)});
      action(row,'Eliminar grupo',async()=>{if(await command('deleteTabGroup',group)!==false){snapshot.tabGroups=snapshot.tabGroups.filter(x=>x!==group);tabGroupsPanel()}});
      body.append(row);
    }
  });
}
function profilePanel(){
  panel('Perfiles independientes de Gravity',body=>{
    text(body,'Cada perfil tiene cookies, historial, pestañas, favoritos y contraseñas separados. El perfil original nunca se borra.');
    const list=document.createElement('div');body.append(list);
    void command('profilesList').then(result=>{
      if(!result||!Array.isArray(result.profiles))return;
      list.replaceChildren();heading(list,'Seleccionar perfil');
      for(const profile of result.profiles){
        const title=profile.name+(profile.id===result.active?' (actual)':'');
        const button=action(list,title,async()=>{if(profile.id!==result.active)await command('profileSwitch',profile.id)});
        button.disabled=profile.id===result.active;
      }
    });
    heading(body,'Crear perfil adicional');
    const form=document.createElement('form');
    const name=field(form,'Nombre','','Ej.: Trabajo');name.required=true;name.maxLength=32;
    const button=action(form,'Crear sin alterar el actual',()=>{});button.type='submit';
    form.onsubmit=async ev=>{
      ev.preventDefault();const result=await command('profileCreate',name.value);
      if(result?.id){notice('Nuevo perfil creado. Elige su nombre para entrar.');profilePanel()}
    };body.append(form);
    text(body,'Antes de cambiar de perfil, termina las descargas. Gravity se reiniciará para aislar también las cookies del nuevo perfil.');
  });
}
function vaultPanel(){
  const current=snapshot.tabs.find(t=>t.id===snapshot.active);
  panel('Credenciales protegidas · Gravity',body=>{
    text(body,'Almacenamiento local cifrado por el sistema operativo. No hay sincronización ni guardado automático desde las páginas.');
    text(body,'La contraseña se copia solo cuando tú lo solicitas, y Gravity intenta borrarla a los 30 segundos si sigue abierto y nadie ha cambiado el portapapeles.');
    if(!current||current.private||!current.url?.startsWith('https://')){
      text(body,'Abre una página HTTPS en una pestaña normal para gestionar contraseñas de ese sitio.');return;
    }
    const origin=new URL(current.url).origin;
    heading(body,'Sitio actual: '+origin);
    const records=document.createElement('div');body.append(records);
    function render(){
      void command('vaultList').then(list=>{
        if(!list)return;
        records.replaceChildren();
        if(!list.available){text(records,'El cifrado seguro del sistema no está disponible; Gravity NO almacenará contraseñas sin cifrar.');return}
        const entries=list.entries.filter(entry=>entry.origin===origin);
        heading(records,'Contraseñas guardadas para este sitio');
        if(!entries.length)text(records,'No hay credenciales para este sitio.');
        for(const row of entries){
          const div=document.createElement('div');div.className='download-row';
          text(div,row.username);
          action(div,'Copiar contraseña',()=>void command('vaultCopy',row.id));
          action(div,'Eliminar',async()=>{if(await command('vaultRemove',row.id))render()});
          records.append(div);
        }
      });
    }
    render();heading(body,'Añadir o actualizar una credencial');
    const form=document.createElement('form');
    const name=field(form,'Usuario o correo','','usuario@ejemplo.com');name.autocomplete='off';name.required=true;name.maxLength=256;
    const pass=field(form,'Contraseña','','Contraseña de este sitio');pass.type='password';pass.autocomplete='new-password';pass.required=true;pass.maxLength=4096;
    const button=action(form,'Guardar cifrado en este equipo',()=>{});button.type='submit';
    form.onsubmit=async ev=>{
      ev.preventDefault();button.disabled=true;
      try{const outcome=await command('vaultAdd',{username:name.value,password:pass.value});
        if(outcome&&outcome.id){name.value='';pass.value='';render()}}
      finally{pass.value='';button.disabled=false}
    };body.append(form);
    text(body,'La protección del sistema operativo NO protege frente a malware ejecutándose con tu misma cuenta. Usa contraseñas únicas y autenticación multifactor.');
  });
}
function screenshotAction(mode){
  closePanel();
  void command('screenshot',mode);
}
function universalSearchPanel(){
  panel('Búsqueda universal · Gravity',body=>{
    text(body,'Busca simultáneamente en DuckDuckGo, Google y Bing: se abrirán tres pestañas, una por buscador. Las consultas se envían a esos servicios, no a servidores de Gravity.');
    const form=document.createElement('form');
    const query=field(form,'¿Qué quieres encontrar?','','Escribe la consulta');query.required=true;query.maxLength=220;
    const submit=action(form,'Buscar en tres motores',()=>{});submit.type='submit';
    form.onsubmit=async event=>{event.preventDefault();const ok=await command('searchUniversal',query.value);if(ok)closePanel()};
    body.append(form);
  });
}
function showMenu(){
  panel('Gravity · Menú',body=>{
    heading(body,'Navegación');
    action(body,'Nueva pestaña · Ctrl+T',()=>{closePanel();void command('new')});
    action(body,'Nueva pestaña privada · Ctrl+Mayús+N',()=>{closePanel();void command('newPrivate')});
    action(body,'Reabrir pestaña · Ctrl+Mayús+T',()=>{closePanel();void command('restoreClosed')});
    const activeTab=snapshot.tabs.find(t=>t.id===snapshot.active);
    action(body,activeTab?.pinned?'Desfijar pestaña actual':'📌 Fijar pestaña actual',()=>{closePanel();void command('togglePin')});
    action(body,'📂 Grupos de pestañas',tabGroupsPanel);
    action(body,'Buscar en página · Ctrl+F',()=>{closePanel();openFind()});
    action(body,'🌐 Buscar en varios motores',universalSearchPanel);
    action(body,'Favoritos · Ctrl+D para guardar',()=>showList('bookmarks'));
    action(body,'Historial · Ctrl+H',()=>showList('history'));
    action(body,'Descargas · Ctrl+J',downloadsPanel);
    heading(body,'Herramientas');
    action(body,'Duplicar pestaña actual',()=>{closePanel();void command('duplicateTab')});
    action(body,'Copiar enlace de esta pestaña',()=>{closePanel();void command('copyTabURL')});
    action(body,'Guardar pestañas en un archivo',()=>{closePanel();void command('exportTabSet')});
    action(body,'Abrir colección de pestañas',()=>{closePanel();void command('importTabSet')});
    action(body,'Guardar página como PDF',()=>{closePanel();void command('savePagePDF')});
    action(body,'🌎 Traducir página al español',()=>{closePanel();void command('translatePage','es')});
    action(body,'📖 Modo lectura sin distracciones',()=>{closePanel();void command('readerMode')});
    action(body,'📸 Capturar área visible',()=>screenshotAction('visible'));
    action(body,'📸 Capturar página completa',()=>screenshotAction('full'));
    action(body,'✂️ Seleccionar zona de captura',()=>screenshotAction('region'));
    action(body,'👤 Perfiles independientes',profilePanel);
    action(body,'🔐 Mis contraseñas protegidas',vaultPanel);
    action(body,'Imprimir página · Ctrl+P',()=>void command('print'));
    action(body,'Reducir zoom',()=>void command('zoom',-.1));
    action(body,'Zoom al 100 %',()=>void command('zoomReset'));
    action(body,'Aumentar zoom',()=>void command('zoom',.1));
    action(body,'Liberar memoria de pestañas inactivas',async()=>{
      const result=await command('sleepInactive');
      if(result&&result.suspended)closePanel();
    });
    action(body,'Diagnóstico de rendimiento y errores',diagnosticsPanel);
    action(body,'🛡️ Escudos contra anuncios y rastreadores',security);
    action(body,'Ajustes',settingsPanel);
    action(body,'Privacidad',privacy);action(body,'Protección',security);action(body,'Movimiento',motionPanel);
    action(body,'Acerca de Gravity · Versión y estado',aboutPanel);
    text(body,'Ctrl+Tab cambia de pestaña, Ctrl+1…8 abre la pestaña correspondiente y Ctrl+9 muestra la última. Alt+← vuelve atrás.');
  });
}
$('#menu').onclick=showMenu;

function renderTabs(){
  const rail=$('#tabs'),key=JSON.stringify(snapshot.tabs.map(t=>[t.id,t.title,t.loading,t.favicon,t.muted,t.audible,t.private,t.pinned,t.group,t.id===snapshot.active]));
  if(key===lastTabKey)return;lastTabKey=key;
  const scroll=rail.scrollLeft;
  const nodes=snapshot.tabs.map(tab=>{
    const wrapper=document.createElement('div');wrapper.className='tab'+(tab.id===snapshot.active?' active':'')+(tab.private?' private':'');
    wrapper.draggable=true;wrapper.dataset.id=tab.id;
    wrapper.title=tab.private?'Pestaña privada: '+tab.title:tab.title;
    const favicon=document.createElement('img');favicon.alt='';favicon.referrerPolicy='no-referrer';
    favicon.src=tab.favicon||'assets/gravity.svg';favicon.onerror=()=>{favicon.onerror=null;favicon.src='assets/gravity.svg'};
    const title=document.createElement('button');title.className='title';title.title=tab.url;
    title.textContent=(tab.pinned?'📌 ':'')+(tab.loading?'◌ ':'')+(tab.private?'◈ ':'')+(tab.group?`[${tab.group}] `:'')+tab.title;
    title.onclick=()=>void command('select',tab.id);
    wrapper.append(favicon,title);
    if(tab.audible||tab.muted){
      const mute=document.createElement('button');mute.className='tabmute';mute.textContent=tab.muted?'◌':'♪';
      mute.title=tab.muted?'Activar sonido':'Silenciar pestaña';
      mute.onclick=()=>{void command('select',tab.id).then(()=>command('mute'))};wrapper.append(mute);
    }
    const close=document.createElement('button');close.className='x';close.textContent=tab.pinned?'•':'×';close.title=tab.pinned?'Desfija esta pestaña en el menú antes de cerrarla':'Cerrar pestaña';close.disabled=Boolean(tab.pinned);
    close.onclick=()=>void command('close',tab.id);wrapper.append(close);
    wrapper.addEventListener('dragstart',event=>{
      draggingId=tab.id;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',tab.id);wrapper.classList.add('dragging');
    });
    wrapper.addEventListener('dragover',event=>{if(!draggingId)return;event.preventDefault();event.dataTransfer.dropEffect='move';wrapper.classList.add('drop-target')});
    wrapper.addEventListener('dragleave',()=>wrapper.classList.remove('drop-target'));
    wrapper.addEventListener('drop',event=>{
      event.preventDefault();wrapper.classList.remove('drop-target');
      if(draggingId&&draggingId!==tab.id){const to=snapshot.tabs.findIndex(t=>t.id===tab.id);void command('reorder',{id:draggingId,to})}
      draggingId='';
    });
    wrapper.addEventListener('dragend',()=>{draggingId='';wrapper.classList.remove('dragging')});
    return wrapper;
  });
  rail.replaceChildren(...nodes);rail.scrollLeft=scroll;
}
function state(s){
  snapshot=s||emptyState;
  renderTabs();
  const tab=snapshot.tabs.find(t=>t.id===snapshot.active);if(!tab)return;
  const home=tab.url===HOME;
  if(!home)closeSuggestions();
  $('#homepage').hidden=!home;$('#external').hidden=home;
  if(home&&!$('#findbar').hidden)closeFind();
  if(document.activeElement!==$('#address'))$('#address').value=home?'':tab.url;
  $('#back').disabled=!tab.back;$('#forward').disabled=!tab.forward;
  const bookmarked=snapshot.bookmarks.some(b=>b.url===tab.url);
  $('#bookmark').textContent=bookmarked?'★':'☆';
  $('#bookmark').title=bookmarked?'Quitar de favoritos':'Guardar favorito';
  $('#reload').textContent=tab.loading?'×':'↻';
  $('#externalTitle').textContent=tab.error?'No se pudo cargar la página':'Cargando página…';
  $('#externalUrl').textContent=tab.url;$('#externalError').textContent=tab.error||'';
  $('#errorActions').hidden=!tab.error;
  $('#siteHint').hidden=home;
  $('#siteHint').classList.toggle('private',tab.private);
  $('#siteHint').textContent=tab.private?'◈ Privado':tab.url.startsWith('https://')?'🔒 HTTPS':'⚠ HTTP';
  $('#siteHint').title=tab.private?'Sesión temporal: no añade sitios al historial de Gravity':tab.url.startsWith('https://')?'Conexión cifrada (HTTPS), no garantiza la identidad del sitio':'Conexión sin cifrar (HTTP)';
  document.title=tab.title+' — Gravity';
  renderLinks();
}
const tabsRail=$('#tabs');
tabsRail.addEventListener('wheel',event=>{
  if(tabsRail.scrollWidth>tabsRail.clientWidth&&Math.abs(event.deltaY)>Math.abs(event.deltaX)){
    event.preventDefault();tabsRail.scrollLeft+=event.deltaY;
  }
},{passive:false});

// Sugerencias privadas: solo favoritos e historial del propio equipo; ninguna petición a terceros.
function closeSuggestions(){clearTimeout(suggestionsTimer);$('#suggestions').hidden=true;$('#suggestions').replaceChildren();suggestions=[];suggestionIndex=-1}
function highlightSuggestion(){
  [...$('#suggestions').children].forEach((node,i)=>node.classList.toggle('selected',i===suggestionIndex));
}
async function updateSuggestions(){
  const input=$('#query'),query=input.value;
  if(query.trim().length<2){closeSuggestions();return}
  const list=await command('suggest',query);
  if(input.value!==query)return;
  if(!Array.isArray(list)||!list.length){closeSuggestions();return}
  suggestions=list;suggestionIndex=-1;
  const target=$('#suggestions');target.replaceChildren();target.hidden=false;
  target.style.top=($('#searchForm').offsetTop+$('#searchForm').offsetHeight+9)+'px';
  for(const item of list){
    const button=document.createElement('button');button.className='suggestion';button.type='button';
    const label=document.createElement('strong');label.textContent=item.title||item.url;
    const source=document.createElement('small');source.textContent=item.source;
    button.append(label,source);button.title=item.url;button.onclick=()=>void submit(item.url);
    target.append(button);
  }
}
$('#query').addEventListener('input',()=>{clearTimeout(suggestionsTimer);suggestionsTimer=setTimeout(()=>void updateSuggestions(),110)});
$('#query').addEventListener('keydown',event=>{
  if($('#suggestions').hidden)return;
  if(event.key==='ArrowDown'){event.preventDefault();suggestionIndex=(suggestionIndex+1)%suggestions.length;highlightSuggestion()}
  if(event.key==='ArrowUp'){event.preventDefault();suggestionIndex=(suggestionIndex-1+suggestions.length)%suggestions.length;highlightSuggestion()}
  if(event.key==='Escape'){event.preventDefault();closeSuggestions()}
});
document.addEventListener('pointerdown',event=>{
  if(!event.target.closest('#suggestions,#searchForm'))closeSuggestions();
});
function openFind(){
  if(!snapshot.tabs.find(t=>t.id===snapshot.active)||snapshot.tabs.find(t=>t.id===snapshot.active).url===HOME){notice('Abre una página para buscar texto.');return}
  $('#findbar').hidden=false;$('#chrome').classList.add('find-open');
  $('#findQuery').focus();$('#findQuery').select();
  requestAnimationFrame(()=>void command('bounds',Math.ceil($('#chrome').getBoundingClientRect().bottom)));
}
function closeFind(){
  $('#findbar').hidden=true;$('#chrome').classList.remove('find-open');$('#findCount').textContent='';
  void command('stopFind');requestAnimationFrame(()=>void command('bounds',Math.ceil($('#chrome').getBoundingClientRect().bottom)));
}
function find(next=false,forward=true){
  const query=$('#findQuery').value.trim();if(query)void command('find',{query,next,forward});
}
$('#findQuery').addEventListener('input',()=>find());
$('#findQuery').addEventListener('keydown',event=>{
  if(event.key==='Enter'){event.preventDefault();find(true,!event.shiftKey)}
  if(event.key==='Escape'){event.preventDefault();closeFind()}
});
$('#findPrev').onclick=()=>find(true,false);
$('#findNext').onclick=()=>find(true,true);
$('#findClose').onclick=closeFind;
window.addEventListener('keydown',event=>{
  if(event.key==='Escape'){
    if($('#findbar').hidden===false)closeFind();
    else if(!$('#suggestions').hidden)closeSuggestions();
  }
});
window.GravityUI={notice,isHome:()=>!$('#homepage').hidden};
if(api){
  api.onState(state);api.onNotice(notice);
  api.onDownloads(rows=>{snapshot.downloads=rows;if(downloadOpen)updateDownloads()});
  api.onFound(result=>{if(!$('#findbar').hidden)$('#findCount').textContent=`${result.activeMatchOrdinal||0}/${result.matches||0}`});
  api.onUIAction(name=>{
    if(name==='history')showList('history');
    if(name==='downloads')downloadsPanel();
    if(name==='find')openFind();
    if(name==='escape'&&!$('#findbar').hidden)closeFind();
  });
  api.onFocus(()=>{$('#address').focus();$('#address').select()});
  void api.command('state').then(s=>{if(s?.tabs?.length)state(s)}).catch(error=>notice(error.message));
  new ResizeObserver(()=>void command('bounds',Math.ceil($('#chrome').getBoundingClientRect().bottom))).observe($('#chrome'));
}else{
  renderLinks();notice('Abre Gravity con INICIAR-GRAVITY-WINDOWS.bat, no con doble clic en el HTML.');
}
