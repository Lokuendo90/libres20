'use strict';
const canvas=document.querySelector('#canvas'),ctx=canvas.getContext('2d'),image=new Image();
let selection=null,start=null,dragging=false;
function redraw(){
  if(!image.complete||!image.naturalWidth)return;
  ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0);
  if(selection){
    ctx.fillStyle='rgba(0,0,0,0.35)';ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.drawImage(image,selection.x,selection.y,selection.width,selection.height,selection.x,selection.y,selection.width,selection.height);
    ctx.strokeStyle='#f3c673';ctx.lineWidth=Math.max(2,canvas.width/600);ctx.strokeRect(selection.x,selection.y,selection.width,selection.height);
  }
}
function pointer(e){
  const rect=canvas.getBoundingClientRect();
  return {x:Math.max(0,Math.min(canvas.width,Math.round((e.clientX-rect.left)*canvas.width/rect.width))),
    y:Math.max(0,Math.min(canvas.height,Math.round((e.clientY-rect.top)*canvas.height/rect.height)))};
}
image.onload=()=>{canvas.width=image.naturalWidth;canvas.height=image.naturalHeight;redraw()};
window.gravityCrop.onImage(encoded=>{image.src='data:image/png;base64,'+encoded});
canvas.addEventListener('pointerdown',e=>{start=pointer(e);dragging=true;selection=null;canvas.setPointerCapture(e.pointerId);redraw()});
canvas.addEventListener('pointermove',e=>{
  if(!dragging||!start)return;const end=pointer(e);
  selection={x:Math.min(start.x,end.x),y:Math.min(start.y,end.y),width:Math.abs(end.x-start.x),height:Math.abs(end.y-start.y)};
  document.querySelector('#save').disabled=selection.width<8||selection.height<8;redraw();
});
canvas.addEventListener('pointerup',()=>{dragging=false});
canvas.addEventListener('pointercancel',()=>{dragging=false});
document.querySelector('#reset').onclick=()=>{selection=null;document.querySelector('#save').disabled=true;redraw()};
document.querySelector('#cancel').onclick=()=>window.close();
document.querySelector('#save').onclick=async()=>{
  if(!selection)return;
  const button=document.querySelector('#save');button.disabled=true;
  try{await window.gravityCrop.save(selection)}catch(e){document.querySelector('#instructions').textContent=String(e?.message||e)}
  finally{button.disabled=false}
};
