'use strict';
document.querySelector('#close').onclick=()=>window.close();
window.gravityShowReader=article=>{
  document.querySelector('#title').textContent=String(article.title||'Lectura');
  const content=document.querySelector('#body');content.replaceChildren();
  for(const block of article.paragraphs||[]){
    const node=document.createElement(block.kind==='heading'?'h2':'p');
    node.textContent=block.value;content.append(node);
  }
};
