'use strict';
const assert=require('node:assert/strict');const {EventEmitter}=require('node:events');
const {validateChannel,validatePublishSettings}=require('../release-channel.cjs');const {createUpdateService}=require('../update-service.cjs');
const good={version:1,enabled:true,channel:'stable',expectedPublisher:'GRAVITY SOFTWARE PUBLICADOR',feedUrl:'https://updates.gravity-ejemplo.org/stable/'};
const context={platform:'win32',isPackaged:true,builderPublisher:good.expectedPublisher};
assert.equal(validateChannel({},context).ready,false);
assert.equal(validateChannel(good,context).ready,true);
assert.equal(validatePublishSettings([],{enabled:false}),true);
assert.equal(validatePublishSettings([{provider:'generic',url:good.feedUrl}],good),true);
assert.equal(validatePublishSettings([{provider:'github',url:good.feedUrl}],good),false);
for(const feedUrl of ['http://updates.example.org/','https://127.0.0.1/','https://user:pass@updates.example.org/','https://updates.example.org/?secret=1','https://localhost/','https://example.test/','https://updates.example.org/stable']){
  assert.equal(validateChannel({...good,feedUrl},context).ready,false,`Denegar origen inseguro ${feedUrl}`);
}
assert.equal(validateChannel({...good,expectedPublisher:'OTHER PUBLISHER'},context).ready,false);
let remoteChecks=0;
const disabled=createUpdateService({app:{isPackaged:false},platform:'win32',channel:good,
  updaterFactory:()=>{remoteChecks++;throw Error('No debería cargar librerías')}});
assert.equal(disabled.start().enabled,false);assert.equal(remoteChecks,0);
class FakeUpdater extends EventEmitter{
  setFeedURL(config){this.feed=config}
  async checkForUpdates(){remoteChecks++;this.emit('update-not-available');return null}
  quitAndInstall(){this.installed=true}
}
(async()=>{
  const updater=new FakeUpdater(),events=[];
  const service=createUpdateService({app:{isPackaged:true},platform:'win32',builderPublisher:good.expectedPublisher,
    channel:good,updaterFactory:()=>updater,getWindow:()=>({isDestroyed:()=>false}),
    hasPendingDownloads:()=>false,saveProfile:()=>true,notice:()=>{},log:{write:name=>events.push(name)},
    dialog:{showMessageBox:async()=>({response:0})}});
  assert.equal(service.start().enabled,true);assert.equal(updater.feed.url,good.feedUrl);
  await service.check();assert.equal(remoteChecks,1);
  updater.emit('update-downloaded');await new Promise(r=>setImmediate(r));
  assert(events.includes('UPDATE_DOWNLOADED'));
  assert.equal(updater.installed,undefined,'No instalar sin permiso');
  service.stop();
  console.log('GRAVITY RC updates: canal HTTPS validado, no acceso desde beta, sin reinicio involuntario.');
})().catch(e=>{console.error(e);process.exitCode=1});
