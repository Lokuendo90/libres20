'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {readProfile,writeProfile}=require('../profile-store.cjs');
const {createLocalDiagnostics}=require('../diagnostics.cjs');
const folder=fs.mkdtempSync(path.join(os.tmpdir(),'gravity-profile-integrity-'));
try{
  const filename=path.join(folder,'profile.json');
  const before={restore:[{url:'https://test.example/123?token=SENSITIVE-TOKEN',pinned:false}],bookmarks:[],settings:{}};
  writeProfile(filename,before);writeProfile(filename,{...before,restore:[{url:'https://test.example/page'}]});
  fs.writeFileSync(filename,'{"broken":');
  const restored=readProfile(filename);
  assert.equal(restored.from,'backup');
  assert.deepEqual(restored.value,before,'El último perfil correcto debe recuperarse desde .bak');
  assert(fs.readdirSync(folder).some(n=>n.includes('.corrupt-')),'Archivar perfil corrupto sin borrarlo');
  const logger=createLocalDiagnostics(path.join(folder,'logs'));
  logger.write('RENDERER_CRASH',{url:'https://secret.example/?password=supersecret',password:'supersecret',scope:'normal'});
  logger.write('UPDATE_ERROR',{url:'https://updater.example/?access_key=supersecret'});
  const events=fs.readFileSync(logger.file,'utf8');
  assert(!events.includes('secret')&&!events.includes('password')&&!events.includes('access_key'));
  assert(events.includes('UPDATE_ERROR'));
  console.log('GRAVITY RC: recuperacion de respaldo, cuarentena y datos privados fuera del diagnostico OK.');
}finally{fs.rmSync(folder,{recursive:true,force:true})}
