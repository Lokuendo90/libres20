'use strict';
// Bloquea por diseño una versión pública si faltan pruebas en hardware real,
// evidencia, firma del instalador, identidad del editor o canal de actualizaciones.
// Pasar este control NO equivale a una auditoría independiente.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const pkg=require('../package.json');
const {validateChannel,validatePublishSettings}=require('../release-channel.cjs');
const channel=require('../release-channel.json');
const {evaluate,loadReports}=require('./release-evidence.cjs');
const missing=[];
if(process.platform!=='win32')missing.push('La compilación final debe ejecutarse en Windows.');
if(!/^\d+\.\d+\.\d+$/.test(pkg.version))missing.push('Aún es candidata RC; no marcar como estable antes de validar.');
if(process.env.GRAVITY_WINDOWS_TESTS_APPROVED!=='1')missing.push('La persona responsable debe confirmar por escrito pruebas en Windows 10/11 y reproducción/logins/Meet.');
if(process.env.GRAVITY_PUBLISHER_APPROVED!=='1')missing.push('Confirmar identidad del editor, marca, política de privacidad y soporte.');
if(!process.env.WIN_CSC_LINK||!process.env.WIN_CSC_KEY_PASSWORD)missing.push('Configurar certificado Authenticode válido (WIN_CSC_LINK y WIN_CSC_KEY_PASSWORD).');
if(!process.env.GRAVITY_EXPECTED_SIGNER)missing.push('Identificar el firmante esperado para verificar el instalador.');
if(!fs.existsSync(path.join(__dirname,'..','package-lock.json')))missing.push('Generar y fijar el package-lock.json con npm real.');
if(!validatePublishSettings(pkg.build?.publish,channel))missing.push('El feed de electron-builder no coincide con el canal HTTPS firmado.');
const release=validateChannel(channel,{platform:'win32',isPackaged:true,builderPublisher:pkg.build?.win?.publisherName});
if(!release.ready)missing.push('Configurar y verificar canal oficial HTTPS + publisherName: '+release.reason);
if(release.ready&&release.expectedPublisher!==process.env.GRAVITY_EXPECTED_SIGNER)missing.push('El firmante esperado no coincide con release-channel.json.');
const folder=process.env.GRAVITY_REPORT_DIR||path.join(os.homedir(),'Documents','Gravity-Diagnosticos');
const evidence=evaluate(loadReports(folder));
for(const item of evidence.failures)missing.push(item);
if(missing.length){console.error('Gravity: publicación BLOQUEADA. Motivos:\n'+missing.map(x=>' - '+x).join('\n'));process.exitCode=1}
else console.log('Control documental y técnico superado. REQUIERE comprobar Authenticode del instalador resultante, pruebas manuales y aprobación humana.');
