'use strict';
const assert=require('node:assert/strict');
const {parseBookmarksHTML,exportBookmarksHTML,mergeBookmarks,webAddress,MAX_BOOKMARK_FILE_BYTES,MAX_BOOKMARKS}=require('../bookmarks-io.cjs');
const sample=[{url:'https://example.com/a?x=1&y=2',title:'Café & más <3'},
  {url:'https://www.wikipedia.org/',title:'Enciclopedia'},
  {url:'javascript:alert(1)',title:'Malicioso'},
  {url:'https://alice:password@example.com',title:'Con credenciales'}];
const html=exportBookmarksHTML(sample);
assert(html.startsWith('<!DOCTYPE NETSCAPE-Bookmark-file-1>'));
assert(html.includes('Café &amp; más &lt;3'));
assert(html.includes('x=1&amp;y=2'));
assert(!html.includes('javascript:'));
assert(!html.includes('password'));
assert.deepEqual(parseBookmarksHTML(html),sample.slice(0,2));
const external='<DL><p><DT><A HREF="https://site.example/?a=1&amp;b=2">Prueba &#38; análisis</A>'+
  '<DT><A HREF="file:///c:/secret.txt">Archivo</A><DT><A HREF="data:text/html,evil">X</A>'+
  '<DT><A HREF="https://site.example/?a=1&amp;b=2">Duplicado</A>'+
  '<DT><A HREF="http://local.test">Local</A></DL>';
assert.deepEqual(parseBookmarksHTML(external),[
  {url:'https://site.example/?a=1&b=2',title:'Prueba & análisis'},
  {url:'http://local.test/',title:'Local'}
]);
assert.equal(webAddress('https://bob:secret@site.com/'),'');
const original=[{url:'https://example.com/',title:'Original'}];
const merged=mergeBookmarks(original,[...parseBookmarksHTML(external),{url:'https://example.com/',title:'Clon'}]);
assert.equal(merged.added,2);
assert.deepEqual(original,[{url:'https://example.com/',title:'Original'}],'nunca mutar arreglo anterior');
assert.equal(merged.items.length,3);
assert.throws(()=>parseBookmarksHTML('x'.repeat(MAX_BOOKMARK_FILE_BYTES+1)),/demasiado grande/);
assert.throws(()=>parseBookmarksHTML('sin enlaces'),/no parece/);
assert.equal(parseBookmarksHTML('<DL><A HREF="javascript:alert(1)">mal</A></DL>').length,0);
assert.throws(()=>parseBookmarksHTML('<DL><A HREF="https://a.com">A</A><A HREF="https://b.com">B</A></DL>',1),/supera 1/,'no recortar una importación por alcanzar un límite');
const many=Array.from({length:1004},(_,i)=>({url:`https://id-${i}.example/`,title:`Sitio ${i}`}));
const allHTML=exportBookmarksHTML(many);
assert.equal(parseBookmarksHTML(allHTML).length,1004,'exportación/importación completa por encima de 1000');
const limit=Array.from({length:MAX_BOOKMARKS},(_,i)=>({url:`https://limit-${i}.example/`,title:'X'}));
assert.equal(exportBookmarksHTML(limit).match(/<DT><A/g).length,MAX_BOOKMARKS,'no exportar solo los primeros mil');
assert.throws(()=>mergeBookmarks(limit,[{url:'https://nuevo.example',title:'Nuevo'}]),/límite/,'sin importación parcial por capacidad');
assert.equal(limit.length,MAX_BOOKMARKS,'la colección original permanece intacta');
assert.throws(()=>parseBookmarksHTML(exportBookmarksHTML([...limit,{url:'https://excedido.example/',title:'Excedido'}])),/supera 20000/);
console.log('Gravity: intercambio HTML de favoritos, deduplicación, entidad HTML y límites de seguridad OK.');
