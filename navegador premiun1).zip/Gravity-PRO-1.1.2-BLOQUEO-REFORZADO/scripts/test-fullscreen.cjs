'use strict';
const assert=require('node:assert/strict');
const {shouldAllowFullscreen:allow}=require('../fullscreen-policy.cjs');
const youtube='https://www.youtube.com/watch?v=test';
assert(allow('fullscreen',youtube,'https://www.youtube.com',{requestingUrl:youtube,isMainFrame:true,userGesture:true}));
assert(allow('fullscreen',youtube,'',{requestingUrl:youtube}),'Electron puede omitir userGesture');
assert(allow('fullscreen','http://localhost:3000/','',''), 'localhost válido si no hay marco ajeno');
for(const [permission,top,origin,details] of [
  ['automatic-fullscreen',youtube,'https://www.youtube.com',{}],
  ['media',youtube,'',{}],['geolocation',youtube,'',{}],
  ['fullscreen','http://example.org/','',{}],
  ['fullscreen','file:///C:/test.html','',{}],
  ['fullscreen','https://usuario:pass@youtube.com/','',{}],
  ['fullscreen',youtube,'https://evil.example',{}],
  ['fullscreen',youtube,'',{requestingUrl:'https://evil.example'}],
  ['fullscreen',youtube,'',{isMainFrame:false}],
  ['fullscreen',youtube,'',{userGesture:false}],
  ['fullscreen','https://youtube.evil.example/watch','',{securityOrigin:'https://www.youtube.com'}]
])assert.equal(allow(permission,top,origin,details),false,`${permission} ${top}`);
console.log('Gravity 1.1.1: fullscreen principal seguro sin diálogos, iframes y permisos sensibles protegidos PASS');
