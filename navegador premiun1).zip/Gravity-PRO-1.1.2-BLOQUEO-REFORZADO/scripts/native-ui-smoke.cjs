'use strict';
// Ejecutar SOLO con Electron nativo: `npm run native:ui`.
// Verifica WebContentsView, aislamiento y composición LOCAL sin cuentas ni páginas externas.
const {app,BrowserWindow,WebContentsView,session}=require('electron');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {randomUUID}=require('node:crypto');
const root=path.join(__dirname,'..');
const scratch=fs.mkdtempSync(path.join(os.tmpdir(),'gravity-native-ui-'));
app.setPath('userData',scratch); // NUNCA utiliza %APPDATA%\gravity-directo.
const timeout=(task,ms=15000)=>Promise.race([task,new Promise((_,reject)=>setTimeout(()=>reject(Error('Tiempo de espera agotado')),ms))]);
async function run(){
  await app.whenReady();
  const partition=`gravity-native-ui-${randomUUID()}`;
  const isolated=session.fromPartition(partition);
  isolated.setPermissionRequestHandler((_wc,_permission,done)=>done(false));
  isolated.setPermissionCheckHandler(()=>false);
  const win=new BrowserWindow({show:false,width:1366,height:768,
    webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,webviewTag:false}});
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  await timeout(win.loadFile(path.join(root,'app/index.html')));
  const ui=await win.webContents.executeJavaScript(`({
    title:document.title,hasTabs:!!document.getElementById('tabs'),
    hasAddress:!!document.getElementById('address'),hasHomepage:!!document.getElementById('homepage'),
    hasSearch:!!document.getElementById('searchForm'),hasPlaneta:!!document.getElementById('scene'),
    nodeExposed:typeof require!=='undefined'||typeof process!=='undefined'
  })`);
  if(!ui.hasTabs||!ui.hasAddress||!ui.hasHomepage||!ui.hasSearch||!ui.hasPlaneta||ui.nodeExposed)
    throw Error('La interfaz local no cumple los requisitos básicos de aislamiento.');
  const view=new WebContentsView({webPreferences:{partition,
    nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,webviewTag:false}});
  win.contentView.addChildView(view);
  view.setBounds({x:0,y:106,width:1366,height:662});
  view.setVisible(false);
  view.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  await timeout(view.webContents.loadURL('data:text/html;charset=UTF-8,'+encodeURIComponent('<title>Gravity Native</title><p>Test aislado</p>')));
  const remote=await view.webContents.executeJavaScript(`({
    title:document.title,
    hasNode:typeof require!=='undefined'||typeof process!=='undefined',
    hasGravityBridge:typeof window.gravity!=='undefined'
  })`);
  if(remote.hasNode||remote.hasGravityBridge||remote.title!=='Gravity Native')
    throw Error('El contenido de la vista tiene APIs de Node o el puente privado.');
  console.log('GRAVITY NATIVO: PASS | interfaz local, WebContentsView, sandbox y puente aislado.');
  view.webContents.close();
  win.destroy();
  try{await isolated.clearStorageData();await isolated.clearCache()}catch{}
}
run().then(()=>{app.quit()}).catch(e=>{
  console.error('GRAVITY NATIVO: FAIL |',String(e?.message||e));process.exitCode=1;app.quit();
});
app.on('before-quit',()=>{try{fs.rmSync(scratch,{recursive:true,force:true})}catch{}});
