'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {SUCCESS_PERIOD_MS,FAILURE_BACKOFF_MS,shouldRefreshFilters,writeAttempt}=require('../filter-refresh.cjs');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'gravity-filter-update-'));const file=path.join(dir,'rules.json'),attempt=path.join(dir,'attempt.json');
const now=Date.now();
try{
  assert(shouldRefreshFilters(file,attempt,now));
  writeAttempt(attempt,now);
  assert.equal(shouldRefreshFilters(file,attempt,now+FAILURE_BACKOFF_MS-1),false);
  assert(shouldRefreshFilters(file,attempt,now+FAILURE_BACKOFF_MS+1));
  fs.writeFileSync(file,'{}');fs.utimesSync(file,new Date(now),new Date(now));
  assert.equal(shouldRefreshFilters(file,attempt,now+SUCCESS_PERIOD_MS-1),false);
  assert(shouldRefreshFilters(file,attempt,now+SUCCESS_PERIOD_MS+1));
  fs.writeFileSync(file,'{"version":1,"rules":[]}');fs.utimesSync(file,new Date(now),new Date(now));
  assert(shouldRefreshFilters(file,attempt,now+FAILURE_BACKOFF_MS+1),'legacy v1 cache should be upgraded');
  fs.writeFileSync(file,'{"version":2,"rules":[]}');fs.utimesSync(file,new Date(now),new Date(now));
  assert.equal(shouldRefreshFilters(file,attempt,now+FAILURE_BACKOFF_MS+1),false,'current v2 cache remains fresh');
  const {FILTER_SOURCES}=require('../privacy-shields.cjs');
  assert(FILTER_SOURCES.every(source=>new URL(source).protocol==='https:'));
  assert(FILTER_SOURCES.every(source=>!source.includes('{query}')&&!source.includes('history')));
  console.log('Gravity 1.1.1: actualización periódica HTTPS, límites de frecuencia y privacidad local PASS');
}finally{fs.rmSync(dir,{recursive:true,force:true})}
