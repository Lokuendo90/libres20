'use strict';
// Integración simulada de Gravity PRO. NO sustituye abrir Electron en Windows.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const vm=require('node:vm');
const {EventEmitter}=require('node:events');
const root=path.join(__dirname,'..');
const scratch=fs.mkdtempSync(path.join(os.tmpdir(),'gravity-pro-test-'));
const paths={appData:scratch,userData:path.join(scratch,'Gravity')};
const legacyDir=path.join(scratch,'gravity-directo');
const events={notices:[],ui:[],downloads:[],stateSent:0,closeDecisions:[],dangerousDecisions:[],registered:null,views:[],permissions:[],opened:[],sessions:new Map(),windows:[],updates:[],errors:[],importPath:'',exportPath:path.join(scratch,'favoritos-exportados.html'),sessionExportPath:path.join(scratch,'tabs.json'),sessionImportPath:path.join(scratch,'tabs.json'),pdfPath:path.join(scratch,'pagina.pdf'),shotPath:path.join(scratch,'captura.png'),copied:''};
let nextWCId=1;
const FAKE_PNG=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aOWkAAAAASUVORK5CYII=','base64');
class WC extends EventEmitter {
  constructor(){super();this.url='';this.loads=[];this.id=nextWCId++;this.alive=true;this.muted=false;this.zoom=1;
    this.navigationHistory={canGoBack:()=>false,canGoForward:()=>false,goBack:()=>{},goForward:()=>{}};
    this.mainFrame={};
    this.debugger={attached:false,isAttached:()=>this.debugger.attached,attach:()=>{this.debugger.attached=true},detach:()=>{this.debugger.attached=false},
      sendCommand:async(name)=>name==='Page.getLayoutMetrics'?{cssContentSize:{width:800,height:1100}}:name==='Page.captureScreenshot'?{data:FAKE_PNG.toString('base64')}:{}};}

  setWindowOpenHandler(callback){this.popup=callback}
  getURL(){return this.url}
  async loadURL(url){this.url=url;this.loads.push(url);this.emit('did-start-loading');this.emit('did-navigate');return undefined}
  reload(){this.reloaded=(this.reloaded||0)+1}
  stop(){this.stopped=(this.stopped||0)+1}
  isDestroyed(){return !this.alive}
  close(){this.alive=false}
  send(name,payload){if(name==='state')events.stateSent++;if(name==='notice')events.notices.push(payload);if(name==='ui-action')events.ui.push(payload);if(name==='downloads')events.downloads.push(payload);}
  focus(){}
  setZoomFactor(v){this.zoom=v}
  getZoomFactor(){return this.zoom}
  isAudioMuted(){return this.muted}
  setAudioMuted(v){this.muted=Boolean(v)}
  findInPage(q,opts){this.found={q,opts}}
  stopFindInPage(q){this.stopFound=q}
  print(o){this.printed=o}
  async printToPDF(options){this.pdfOptions=options;return Buffer.from('%PDF-1.7\n1 0 obj\n<<>>\nendobj\n%%EOF\n');}
  async capturePage(){return {toPNG:()=>FAKE_PNG,getSize:()=>({width:200,height:120})}}
  async executeJavaScript(source){
    if(source.includes('gravityYoutubeContinueInstalled')){this.youtubeKeepListeningInstalled=true;return true}
    if(source.startsWith('window.gravityShowReader(')){this.readerShown=true;return true}
    if(source.includes('document.visibilityState')&&source.includes('contenteditable'))return true;
    return {title:'Artículo de prueba',paragraphs:[{kind:'text',value:'Esta es una prueba de lectura lo suficientemente larga para ser válida.'}]};
  }
}
class View {
  constructor(options){this.options=options;this.webContents=new WC();events.views.push(this)}
  setBackgroundColor(){}
  setBounds(bounds){this.bounds=bounds}
  setVisible(v){this.visible=v}
}
class BrowserWindow extends EventEmitter {
  constructor(opts){super();this.options=opts;this.webContents=new WC();this.contentView={addChildView(){},removeChildView(){}};this.dead=false;events.windows.push(this)}
  loadFile(name){this.html=name;if(name==='app/reader.html'||name==='app/crop.html')setImmediate(()=>this.webContents.emit('did-finish-load'));return Promise.resolve()}
  getBounds(){return {width:1500,height:960}}
  getContentSize(){return [1500,960]}
  isDestroyed(){return this.dead}
  close(){const e={preventDefault(){this.prevented=true}};this.emit('close',e);if(e.prevented)return;this.emit('closed');this.dead=true}
  minimize(){}
  maximize(){this.max=true}
  unmaximize(){this.max=false}
  isMaximized(){return Boolean(this.max)}
  isMinimized(){return false}
  restore(){}
  focus(){}
}
class Session extends EventEmitter {
  constructor(id){super();this.id=id;this.webRequest={onBeforeRequest:(_filter,fn)=>this.filter=fn??null,onBeforeSendHeaders:(_filter,fn)=>this.reqFilter=fn??null,onHeadersReceived:(_filter,fn)=>this.resFilter=fn??null};}
  setPermissionCheckHandler(fn){this.check=fn}
  setPermissionRequestHandler(fn){this.request=fn}
  setDevicePermissionHandler(fn){this.deviceCheck=fn}
  async clearStorageData(){this.storageCleared=true}
  async clearCache(){this.cacheCleared=true}
}
class Download extends EventEmitter {
  constructor(name='imagen.png'){super();this.name=name;this.path='';this.bytes=0;this.total=1000;this.paused=false;}
  getFilename(){return this.name}
  getTotalBytes(){return this.total}
  getReceivedBytes(){return this.bytes}
  getSavePath(){return this.path}
  setSavePath(value){this.path=value}
  isPaused(){return this.paused}
  pause(){this.paused=true}
  resume(){this.paused=false}
  cancel(){this.emit('done',{},'cancelled')}
}
const electron={
  app:{requestSingleInstanceLock:()=>true,whenReady:()=>Promise.resolve(),getPath:key=>key==='downloads'?scratch:paths[key]||scratch,setPath:(key,value)=>{paths[key]=value},getVersion:()=> require('../package.json').version,getAppMetrics:()=>[{memory:{workingSetSize:20480}},{memory:{workingSetSize:15360}}],on(){},quit(){}},
  BrowserWindow,WebContentsView:View,
  ipcMain:{handle:(name,fn)=>{if(name==='command')events.registered=fn;else if(name==='gravity-crop-save')events.cropSave=fn;else throw Error('Canal IPC inesperado '+name)}},
  session:{fromPartition:name=>{if(!events.sessions.has(name))events.sessions.set(name,new Session(name));return events.sessions.get(name)}},
  dialog:{showMessageBox:async(_win,opts)=>{
      events.permissions.push(opts);
      if(opts.message?.includes('descarga(s)'))return {response:events.closeDecisions.shift()??0};
      return {response:1};
    },
    showMessageBoxSync:(_win,opts)=>{events.permissions.push(opts);return events.dangerousDecisions.shift()??1},
    showSaveDialog:async(_win,options)=>({canceled:false,filePath:options.title?.includes('captura')?events.shotPath:options.title?.includes('colección')?events.sessionExportPath:options.title?.includes('PDF')?events.pdfPath:events.exportPath}),
    showOpenDialog:async(_win,options)=>({canceled:false,filePaths:[options.title?.includes('colección')?events.sessionImportPath:events.importPath]})},
  shell:{openPath:async value=>{events.opened.push(value);return ''},showItemInFolder:value=>events.opened.push(value)},
  clipboard:{writeText(value){events.copied=value},readText(){return events.copied},clear(){events.copied=''}},
  nativeImage:{createFromBuffer:raw=>({toPNG:()=>raw,getSize:()=>({width:200,height:120}),crop:()=>({toPNG:()=>FAKE_PNG})})},
  safeStorage:{isEncryptionAvailable:()=>true,getSelectedStorageBackend:()=> 'gnome_libsecret',encryptString:value=>Buffer.from(value.split('').reverse().join(''),'utf8'),decryptString:buffer=>Buffer.from(buffer).toString('utf8').split('').reverse().join('')},
  Menu:{buildFromTemplate:items=>({popup(){events.contextMenu=items}})}
};
const source=fs.readFileSync(path.join(root,'main.cjs'),'utf8');
vm.runInNewContext(source,{
  require:name=>name==='electron'?electron:name==='./profile-store.cjs'?require(path.join(root,'profile-store.cjs')):name==='./bookmarks-io.cjs'?require(path.join(root,'bookmarks-io.cjs')):name==='./popup-policy.cjs'?require(path.join(root,'popup-policy.cjs')):name==='./security-policy.cjs'?require(path.join(root,'security-policy.cjs')):name==='./diagnostics.cjs'?require(path.join(root,'diagnostics.cjs')):name==='./crash-recovery.cjs'?require(path.join(root,'crash-recovery.cjs')):name==='./audio-state.cjs'?require(path.join(root,'audio-state.cjs')):name==='./download-safety.cjs'?require(path.join(root,'download-safety.cjs')):name==='./session-io.cjs'?require(path.join(root,'session-io.cjs')):name.startsWith('./')?require(path.join(root,name)):require(name),
  __dirname:root,URL,Date,Math,Number,JSON,Object,Set,Map,String,Boolean,console,process,Buffer,
  setTimeout,clearTimeout,setImmediate,setInterval,clearInterval
},{filename:'main.cjs'});
const pause=()=>new Promise(resolve=>setImmediate(resolve));
function event(url){return {url,cancelled:false,preventDefault(){this.cancelled=true}}}
async function main(){
  await pause();
  const win=events.windows.at(-1);assert(win);assert(events.registered);
  win.webContents.emit('did-finish-load');
  await pause();
  const invoke=(a,v)=>events.registered({sender:win.webContents,senderFrame:win.webContents.mainFrame},a,v);
  const about=await invoke('about');assert.equal(about.version,require('../package.json').version);
  let s=await invoke('state');
  assert.equal(s.tabs.length,1);assert.equal(s.tabs[0].url,'gravity://home');
  assert.equal(s.settings.blockTrackers,true,'Escudos activos en perfiles nuevos');
  assert.equal(s.settings.blockThirdPartyCookies,true,'Bloquear cookies de terceros en perfiles nuevos');
  assert.equal(s.settings.autoUpdateFilterLists,true,'Filtros HTTPS renovables por defecto');
  assert.equal(s.settings.autoSleepTabs,false,'ahorro automático de memoria debe comenzar apagado');
  assert.equal(await invoke('settings',{key:'autoSleepTabs',value:true}),true);
  assert.equal((await invoke('state')).settings.autoSleepTabs,true,'activación solo mediante orden del usuario');
  const measured=await invoke('diagnostics');
  assert.equal(measured.automaticSuspension,true);
  assert.equal(Number.isFinite(measured.processMemoryMB),true);
  await invoke('settings',{key:'autoSleepTabs',value:false});
  assert.equal((await invoke('state')).settings.autoSleepTabs,false,'ajuste opcional puede desactivarse');

  await assert.rejects(invoke('navigate','https://usuario:CLAVE-secreta@example.com/'),/no se admiten credenciales/,'jamás enviar contraseñas URL al buscador');
  await assert.rejects(invoke('navigate','file:///C:/Users/secret.txt'),/no está permitido/,'no buscar rutas locales');
  await invoke('navigate','gatitos');
  s=await invoke('state');
  assert.equal(s.tabs[0].url,'https://www.google.com/search?q=gatitos');
  let wc=events.views.at(-1).webContents;
  assert.equal(wc.loads.length,1);
  // El evento de audio debe tolerar el objeto Electron y un evento sin segundo argumento.
  wc.emit('audio-state-changed',{audible:true});
  assert.equal((await invoke('state')).tabs.find(t=>t.id===s.active).audible,true);
  wc.emit('audio-state-changed',undefined);
  assert.equal((await invoke('state')).tabs.find(t=>t.id===s.active).audible,true,'argumento ausente no revienta ni borra el último estado');
  wc.emit('audio-state-changed',{audible:false});
  assert.equal((await invoke('state')).tabs.find(t=>t.id===s.active).audible,false);
  await pause();
  const stateBefore=events.stateSent;
  for(let i=0;i<25;i++)wc.emit('page-title-updated',{},'Sitio de prueba '+i);
  await pause();
  assert.equal(events.stateSent-stateBefore,1,'25 cambios de título => 1 envío de estado IPC agrupado');
  await invoke('navigate','gatitos');assert.equal(wc.loads.length,1,'sin doble búsqueda accidental');
  await invoke('navigate','YouTube');
  assert.equal((await invoke('state')).tabs[0].url,'https://www.youtube.com/','Acceso directo a sitio reconocido sin motor intermedio');
  await invoke('navigate','gatitos');
  assert.equal((await invoke('shieldsStatus')).enabled,true,'Escudos activos por defecto en perfiles nuevos');
  await invoke('navigate','españa.es');
  assert.equal((await invoke('state')).tabs[0].url,'https://xn--espaa-rta.es/','dominio internacionalizado reconocido');
  await invoke('navigate','gatitos');
  let e=event('https://example.com');wc.emit('will-navigate',e);assert.equal(e.cancelled,false);
  e=event('file:///etc/passwd');wc.emit('will-redirect',e);assert.equal(e.cancelled,true);
  e=event();wc.emit('will-navigate',e,'javascript:alert(1)');assert.equal(e.cancelled,true);
  assert.equal(wc.popup({url:'https://otro.com/',features:'',disposition:'foreground-tab'}).action,'deny');
  await pause();s=await invoke('state');assert.equal(s.tabs.length,2,'enlace nuevo abre otra pestaña');
  assert.equal(s.tabs[1].url,'https://otro.com/');
  assert.equal(wc.popup({url:'https://login.com',disposition:'new-window',features:'width=430,height=540'}).action,'allow','OAuth popup permitido en entorno aislado');
  // Electron envía did-create-window tras autorizar. La reserva se libera al cerrar.
  const oauthPopup=new BrowserWindow({});
  wc.emit('did-create-window',oauthPopup);
  assert.equal(oauthPopup.webContents.popup({url:'file:///tmp/malicious',disposition:'new-window'}).action,'deny','popup hijo rechaza URL locales');
  const oauth2=new BrowserWindow({});
  assert.equal(wc.popup({url:'https://auth2.example/',disposition:'new-window',features:'width=450,height=600'}).action,'allow');
  wc.emit('did-create-window',oauth2);
  assert.equal(wc.popup({url:'https://spam.example/',disposition:'new-window',features:'width=450,height=600'}).action,'deny','máximo dos ventanas simultáneas por pestaña');
  oauthPopup.close();oauth2.close();
  await invoke('select',s.tabs[0].id);
  await invoke('bookmark');s=await invoke('state');assert.equal(s.bookmarks.length,1);
  await invoke('bookmark');s=await invoke('state');assert.equal(s.bookmarks.length,0,'favorito alternable');
  await invoke('bookmark');
  const exported=await invoke('exportBookmarks');assert.equal(exported.exported,1);
  assert(fs.readFileSync(events.exportPath,'utf8').includes('NETSCAPE-Bookmark-file-1'),'archivo exportable HTML');
  events.importPath=path.join(scratch,'importacion.html');
  fs.writeFileSync(events.importPath,'<DL><A HREF="https://valid.example/">Sitio guardado</A><A HREF="javascript:alert(1)">NO</A></DL>');
  const imported=await invoke('importBookmarks');assert.equal(imported.imported,1);
  s=await invoke('state');assert.equal(s.bookmarks.length,2);
  assert(!s.bookmarks.some(x=>x.url.includes('javascript:')),'nunca importa esquemas ejecutables');
  const again=await invoke('importBookmarks');assert.equal(again.imported,0,'deduplicación estable');
  // La auditoría anterior demostraba pérdida de favoritos por encima de 1000.
  fs.writeFileSync(events.importPath,'<DL>'+Array.from({length:1004},(_,i)=>`<DT><A HREF="https://migracion-${i}.example/">Favorito ${i}</A>`).join('')+'</DL>');
  const batch=await invoke('importBookmarks');assert.equal(batch.imported,1004,'se importan más de 1000 sin recortes');
  const preserved=(await invoke('state')).bookmarks.length;
  assert.equal(preserved,1006);
  const exportMany=await invoke('exportBookmarks');assert.equal(exportMany.exported,preserved,'exportación exacta sin recortar a 1000');
  assert.equal(require(path.join(root,'bookmarks-io.cjs')).parseBookmarksHTML(fs.readFileSync(events.exportPath,'utf8')).length,preserved);
  await invoke('settings',{key:'searchEngine',value:'duckduckgo'});
  await invoke('navigate','https://example.com');await invoke('navigate','perritos');
  s=await invoke('state');assert(s.tabs[0].url.startsWith('https://duckduckgo.com/?q=perritos'));
  await invoke('settings',{key:'blockTrackers',value:true});
  const persistent=events.sessions.get('persist:gravity-directo');
  // Comprobación integrada del cuadro molesto de YouTube: no pedir consentimiento para pantalla completa normal.
  const fullscreenWC={getURL:()=> 'https://www.youtube.com/watch?v=video',isDestroyed:()=>false};
  const promptsBeforeFullscreen=events.permissions.length;
  let fullscreenDecision=null;
  await persistent.request(fullscreenWC,'fullscreen',v=>{fullscreenDecision=v},{requestingUrl:'https://www.youtube.com/watch?v=video',isMainFrame:true,userGesture:true});
  assert.equal(fullscreenDecision,true,'fullscreen de marco principal seguro aprobado sin diálogo');
  assert.equal(events.permissions.length,promptsBeforeFullscreen,'fullscreen no debe abrir aviso');
  assert.equal(persistent.check(fullscreenWC,'fullscreen','https://www.youtube.com',{requestingUrl:'https://www.youtube.com/watch?v=video'}),true);
  await persistent.request(fullscreenWC,'fullscreen',v=>{fullscreenDecision=v},{requestingUrl:'https://atacante.example',isMainFrame:false});
  assert.equal(fullscreenDecision,false,'iframe externo no obtiene fullscreen silencioso');
  assert.equal(events.permissions.length,promptsBeforeFullscreen,'tampoco abrir aviso a iframe rechazado');
  await persistent.request(fullscreenWC,'media',v=>{fullscreenDecision=v},{requestingUrl:'https://www.youtube.com/watch?v=video'});
  assert.equal(events.permissions.length,promptsBeforeFullscreen+1,'permiso sensible de media sí conserva confirmación');
  const priorURL=wc.url;wc.url='https://www.youtube.com/watch?v=test';
  wc.emit('dom-ready');await pause();
  assert.equal(wc.youtubeKeepListeningInstalled,true,'inserción selectiva en YouTube watch');
  wc.url=priorURL;

  const trackFilter=details=>new Promise(resolve=>persistent.filter(details,resolve));
  const requestFilter=details=>new Promise(resolve=>persistent.reqFilter(details,resolve));
  const responseFilter=details=>new Promise(resolve=>persistent.resFilter(details,resolve));
  let cookieHeaders=await requestFilter({url:'https://tracker.tracing.example/pixel',resourceType:'image',webContentsId:wc.id,requestHeaders:{Cookie:'PRIVATE_TOKEN=hidden','user-agent':'test'}});
  assert.equal(cookieHeaders.requestHeaders.Cookie,undefined,'Bloquear cookie de petición ajena al sitio');
  assert.equal(cookieHeaders.requestHeaders['Sec-GPC'],'1');
  const thirdPartyResponse=await responseFilter({url:'https://tracker.tracing.example/pixel',resourceType:'image',webContentsId:wc.id,responseHeaders:{'Set-Cookie':['sid=spying'],'Content-Type':['image/gif']}});
  assert.equal(thirdPartyResponse.responseHeaders['Set-Cookie'],undefined,'Bloquear cookie de respuesta ajena al sitio');
  let filter=await trackFilter({url:'https://www.google-analytics.com/analytics.js',resourceType:'script',webContentsId:wc.id});
  assert.equal(filter.cancel,true,'filtro opcional activo');
  filter=await trackFilter({url:'https://youtube.com/',resourceType:'mainFrame',webContentsId:wc.id});
  assert.equal(filter.cancel,false,'nunca bloquear navegación principal');
  await invoke('settings',{key:'trackerSite',value:true});
  filter=await trackFilter({url:'https://www.google-analytics.com/analytics.js',resourceType:'script',webContentsId:wc.id});
  assert.equal(filter.cancel,false,'excepción por sitio');
  assert.equal((await invoke('suggest','perri')).length>0,true,'sugerencias locales');
  await invoke('newPrivate');s=await invoke('state');
  const privateTab=s.tabs.find(t=>t.private);assert(privateTab,'pestaña privada');
  await invoke('navigate','https://private.example/');const privateView=events.views.at(-1);
  s=await invoke('state');assert.equal(s.history.some(x=>x.url==='https://private.example/'),false,'privado no crea historial');
  await assert.rejects(invoke('settings',{key:'trackerSite',value:true}),/pestañas privadas/,'evita filtración del sitio privado a excepciones persistentes');
  assert.equal(privateView.options.webPreferences.partition.startsWith('gravity-private-'),true);
  await invoke('close',privateTab.id);
  await invoke('newPrivate');await invoke('navigate','https://second.example/');assert.notEqual(events.views.at(-1)?.options.webPreferences.partition,privateView.options.webPreferences.partition,'partición temporal nueva tras cerrar sesión privada');
  const secondPrivate=(await invoke('state')).tabs.find(t=>t.private);await invoke('close',secondPrivate.id);
  // Sesiones retiradas: sin permisos, filtros ni listeners retenidos por Gravity.
  for(let cycle=0;cycle<26;cycle++){
    await invoke('newPrivate');await invoke('navigate',`https://priv-${cycle}.example/`);
    const partition=events.views.at(-1).options.webPreferences.partition;
    const privateWC=events.sessions.get(partition);
    const privateId=(await invoke('state')).tabs.find(t=>t.private).id;
    await invoke('close',privateId);await pause();
    assert.equal(privateWC.listenerCount('will-download'),0,'descargas desacopladas al cerrar privado');
    assert.equal(privateWC.request,null,'permiso privado retirado');
    assert.equal(privateWC.check,null,'verificación de permisos retirada');
    assert.equal(privateWC.filter,null,'filtro privado retirado');
    assert.equal(privateWC.reqFilter,null,'filtro de cookies de petición retirado');
    assert.equal(privateWC.resFilter,null,'filtro de cookies de respuesta retirado');
    assert.equal(privateWC.storageCleared,true,'almacenamiento temporal limpiado');
  }
  const requester=wc;let response=null;
  await persistent.request(requester,'media',v=>response=v,{requestingUrl:'https://frame.example/a'});
  assert.equal(response,true,'permiso solicitado y autorizado');
  assert.equal(persistent.check(requester,'media','https://frame.example/'),true);
  assert.equal(persistent.check(requester,'media','https://unrelated.example'),false);
  response=null;await persistent.request(requester,'camera',v=>response=v,{requestingUrl:'https://frame.example'});
  assert.equal(response,false,'permiso desconocido denegado');
  await invoke('clearPermissions');assert.equal(persistent.check(requester,'media','https://frame.example/'),false);
  const deny=()=>events.registered({sender:requester,senderFrame:win.webContents.mainFrame},'state');
  await assert.rejects(deny,'remoto sin acceso a IPC');
  await invoke('select',(await invoke('state')).tabs[0].id);
  const item=new Download('test.txt');
  persistent.emit('will-download',{},item,wc);
  s=await invoke('state');assert.equal(s.downloads.length,1);assert(item.path.startsWith(scratch));
  item.bytes=500;item.emit('updated',{},'progressing');
  await invoke('downloadAction',{action:'pause',id:s.downloads[0].id});assert.equal(item.paused,true);
  await invoke('downloadAction',{action:'resume',id:s.downloads[0].id});assert.equal(item.paused,false);
  fs.writeFileSync(item.path,'data');item.bytes=1000;item.emit('done',{},'completed');
  await invoke('downloadAction',{action:'folder',id:s.downloads[0].id});assert(events.opened.includes(item.path));
  // Un archivo ejecutable no debe comenzar a descargarse si el usuario lo cancela.
  events.dangerousDecisions.push(0);
  const rejected=new Download('informe.pdf.exe');
  const downloadsBefore=(await invoke('state')).downloads.length;
  persistent.emit('will-download',{},rejected,wc);
  assert.equal((await invoke('state')).downloads.length,downloadsBefore,'descarga peligrosa rechazada no entra en el historial');
  // Abrir archivos ejecutables debe requerir una advertencia explícita.
  const executable=new Download('programa.exe');
  persistent.emit('will-download',{},executable,wc);
  fs.writeFileSync(executable.path,'executable-test');executable.emit('done',{},'completed');
  const execId=(await invoke('state')).downloads.find(d=>d.name==='programa.exe').id;
  const promptsBefore=events.permissions.length;
  await invoke('downloadAction',{action:'open',id:execId});await pause();
  assert.equal(events.permissions.length,promptsBefore+1,'advertencia antes de abrir ejecutables');
  assert(events.opened.includes(executable.path));
  await invoke('settings',{key:'restoreTabs',value:true});
  const last=await invoke('state');assert(last.tabs.length>=2);
  await invoke('reorder',{id:last.tabs[0].id,to:last.tabs.length-1});
  await invoke('restoreClosed');
  await invoke('find',{query:'hola',next:false});
  s=await invoke('state');assert.equal(s.tabs.find(t=>t.id===s.active).url.startsWith('http'),true);
  const repeatedURL=s.tabs[0].url;
  await invoke('new');await invoke('navigate',repeatedURL);
  s=await invoke('state');assert(s.tabs.filter(t=>t.url===repeatedURL).length>=2,'duplicados conservados deliberadamente');
  // Liberación de memoria: proteger pestañas con descargas aún activas.
  const originalActive=(await invoke('state')).active;
  await invoke('new');await invoke('navigate','https://descarga-en-curso.example/');
  const downloadingTab=(await invoke('state')).active;
  const busyWC=events.views.at(-1).webContents;
  const liveDownload=new Download('archivo-en-curso.bin');
  persistent.emit('will-download',{},liveDownload,busyWC);
  await invoke('select',originalActive);
  const beforeSleep=await invoke('state');
  const possible=beforeSleep.tabs.filter(t=>t.id!==beforeSleep.active&&t.id!==downloadingTab&&t.url.startsWith('http')&&!t.loading&&!t.audible&&!t.private);
  const slept=await invoke('sleepInactive');
  assert.equal(slept.suspended,possible.length,'reposo solo de pestañas aptas');
  assert.equal((await invoke('state')).tabs.find(t=>t.id===downloadingTab).error,'','descarga no suspende pestaña');
  assert.equal(busyWC.alive,true,'la descarga mantiene su proceso');
  liveDownload.cancel();
  if(possible.length){
    const target=possible[0],viewsBefore=events.views.length;
    await invoke('select',target.id);
    assert(events.views.length>viewsBefore,'al seleccionar pestaña dormida se carga de nuevo');
    assert.equal((await invoke('state')).active,target.id);
  }
  // Fallo de un proceso web y recuperación mediante el botón Reintentar.
  await invoke('navigate','https://recuperacion.example/');
  const failedWC=events.views.find(v=>v.webContents.url==='https://recuperacion.example/')?.webContents;
  assert(failedWC,'existe WebContents del sitio de recuperación');
  const viewsBeforeCrash=events.views.length;
  failedWC.emit('render-process-gone',{}, {reason:'oom'});
  const crashedState=await invoke('state');
  assert.match(crashedState.tabs.find(t=>t.id===crashedState.active).error,/cerró inesperadamente/);
  await invoke('reload');
  assert.equal(events.views.length,viewsBeforeCrash+1,'se crea nuevo WebContents después de crash');
  const recoveredState=await invoke('state');
  assert.equal(recoveredState.tabs.find(t=>t.id===recoveredState.active).error,'','la página se puede reintentar');
  const diag=await invoke('diagnostics');
  assert.equal(diag.tabCount,(await invoke('state')).tabs.length);
  assert.equal(diag.processMemoryMB,35,'medición en MB a partir de métricas Electron');
  assert(diag.liveTabs>=1);
  // Mejoras exclusivamente aditivas 0.8.1: sin tocar la portada ni las funciones anteriores.
  const tabsBeforeExtra=(await invoke('state')).tabs.length;
  assert.equal(await invoke('duplicateTab'),true);
  assert.equal((await invoke('state')).tabs.length,tabsBeforeExtra+1,'duplicar añade pestaña sin reemplazar');
  let extraState=await invoke('state');
  const currentURL=extraState.tabs.find(t=>t.id===extraState.active).url;
  assert.equal(await invoke('copyTabURL'),true);
  assert.equal(events.copied,currentURL,'copiar URL no modifica la navegación');
  const exportedTabs=await invoke('exportTabSet');
  assert(exportedTabs.exported>=2,'colección exportada sin pestañas privadas');
  const sessionJSON=JSON.parse(fs.readFileSync(events.sessionExportPath,'utf8'));
  assert.equal(sessionJSON.urls.length,exportedTabs.exported,'el archivo contiene todas las pestañas exportadas');
  assert(!sessionJSON.urls.some(url=>url.includes('priv-')||url.includes('private.example')),'ninguna pestaña privada en el archivo');
  const importedTabs=await invoke('importTabSet');
  assert.equal(importedTabs.imported,exportedTabs.exported,'conjunto de pestañas importado sin recorte');
  const afterImportState=await invoke('state');
  assert.equal(afterImportState.tabs.length,tabsBeforeExtra+1+importedTabs.imported,'importar añade sin reemplazar');
  assert.equal(afterImportState.tabs[0].id,extraState.tabs[0].id,'primera pestaña previa intacta');
  // Simular fin de carga en Chromium antes de imprimir a PDF.
  const printTabId=afterImportState.active;
  const targetView=events.views.at(-1);
  targetView.webContents.emit('did-stop-loading');
  const pdfResult=await invoke('savePagePDF');
  assert.equal(pdfResult.saved,true,'PDF guardado desde la página activa');
  assert(fs.readFileSync(events.pdfPath).subarray(0,5).equals(Buffer.from('%PDF-')),'archivo resultante PDF válido');
  assert.equal(targetView.webContents.pdfOptions.printBackground,true);
  // Acciones 0.9.0 integradas al comando REAL, sin alterar pestañas existentes.
  await invoke('createTabGroup','Trabajo');
  assert((await invoke('state')).tabGroups.includes('Trabajo'),'grupo persistente');
  await invoke('setTabGroup','Trabajo');
  assert.equal((await invoke('state')).tabs.find(t=>t.id===printTabId).group,'Trabajo');
  assert.equal(await invoke('togglePin'),true);
  let pinnedState=await invoke('state');
  assert.equal(pinnedState.tabs[0].id,printTabId,'pestaña fijada al inicio');
  await invoke('close',printTabId);
  assert((await invoke('state')).tabs.some(t=>t.id===printTabId),'pestaña fijada no se cierra por error');
  await invoke('reorder',{id:printTabId,to:pinnedState.tabs.length-1});
  assert.equal((await invoke('state')).tabs[0].id,printTabId,'arrastrar no mueve fijadas a la zona normal');
  assert.equal(await invoke('togglePin'),false);
  const made=await invoke('profileCreate','Usuario 2');
  assert.equal((await invoke('profilesList')).profiles.length,2);
  assert.equal(require(path.join(root,'profiles.cjs')).resolve(legacyDir,made.id).id,made.id);
  assert(!fs.existsSync(path.join(legacyDir,'profiles',made.id,'gravity-profile.json')),'nuevo perfil no recibe historial ajeno');
  const secret=await invoke('vaultAdd',{username:'yo',password:'SuperSecreto-09'});
  assert(secret.id,'credencial añadida');
  const vaultState=await invoke('vaultList');
  assert(vaultState.entries.some(v=>v.id===secret.id),'se listan metadatos pero no secretos');
  const vaultFile=fs.readFileSync(path.join(legacyDir,'gravity-credentials.v1.json'),'utf8');
  assert(!vaultFile.includes('SuperSecreto-09'),'contraseña no figura en disco sin cifrar');
  assert.equal(await invoke('vaultCopy',secret.id),true);
  assert.equal(events.copied,'SuperSecreto-09','copia bajo orden explícita');
  assert.equal(await invoke('vaultRemove',secret.id),true);
  assert.equal((await invoke('vaultList')).entries.length,0);
  const visible=await invoke('screenshot','visible');assert(visible.saved,'captura visible en PNG');
  assert(fs.readFileSync(events.shotPath).subarray(0,8).equals(FAKE_PNG.subarray(0,8)));
  const full=await invoke('screenshot','full');assert(full.saved,'captura completa por protocolo de Chromium');
  const selected=await invoke('screenshot','region');assert(selected.opened,'editor local de recorte');
  await pause();
  const crop=events.windows.at(-1);assert.equal(crop.html,'app/crop.html');
  await assert.rejects(events.cropSave({sender:win.webContents,senderFrame:win.webContents.mainFrame},{x:1,y:1,width:20,height:20}),/no autorizado/);
  const cropSaved=await events.cropSave({sender:crop.webContents,senderFrame:crop.webContents.mainFrame},{x:4,y:4,width:30,height:30});
  assert(cropSaved.saved,'recorte PNG protegido por IPC');
  const reader=await invoke('readerMode');assert(reader.opened,'lector aislado, no rediseña portada');
  await pause();assert.equal(events.windows.at(-1).html,'app/reader.html');
  const translation=await invoke('translatePage','es');
  assert(translation.opened,'traducción solo con consentimiento');
  assert((await invoke('state')).tabs.some(t=>t.url.startsWith('https://translate.google.com/translate?')));
  await invoke('newPrivate');
  await assert.rejects(invoke('vaultAdd',{username:'x',password:'y'}),/pestaña normal/,'no guarda contraseñas desde privado');
  await assert.rejects(invoke('translatePage','es'),/pestañas normales/,'no filtra enlaces privados al traductor');
  await invoke('close',(await invoke('state')).active);
  assert.equal(await invoke('deleteTabGroup','Trabajo'),true);
  assert(!(await invoke('state')).tabGroups.includes('Trabajo'));
  const allBefore=(await invoke('state')).tabs.map(t=>t.id);
  assert.equal(await invoke('searchUniversal','astronomía'),true);
  const allSearch=(await invoke('state')).tabs;
  assert.equal(allSearch.length,allBefore.length+3,'Multibuscador añade tres pestañas sin quitar las anteriores');
  const three=allSearch.filter(t=>!allBefore.includes(t.id));
  assert(three.some(t=>t.url.startsWith('https://duckduckgo.com')));
  assert(three.some(t=>t.url.startsWith('https://www.google.com/search')));
  assert(three.some(t=>t.url.startsWith('https://www.bing.com/search')));
  for(const tab of three)await invoke('close',tab.id);
  assert.equal((await invoke('state')).tabs.length,allBefore.length);
  console.log('GRAVITY 0.9 y Escudos 1.1: funciones previas, multibuscador y cookies locales OK.');
  // Cerrar Gravity durante descargas exige confirmación y permite cancelar el cierre.
  const ongoing=new Download('archivo-grande.zip');
  persistent.emit('will-download',{},ongoing,wc);
  events.closeDecisions.push(0,1);
  win.close();await pause();
  assert.equal(win.dead,false,'el usuario puede mantener abierto Gravity mientras descarga');
  win.close();await pause();
  assert.equal(win.dead,true,'Gravity permite cerrar tras confirmar');
  assert.equal(paths.userData,legacyDir,'El empaquetado conserva el directorio histórico del perfil');
  assert.equal(fs.existsSync(path.join(legacyDir,'gravity-run-marker.json')),false,'cierre limpio retira marca');
  const logsDir=path.join(legacyDir,'diagnostico');
  assert(fs.existsSync(logsDir));
  const logs=fs.readdirSync(logsDir).filter(f=>f.endsWith('.jsonl')).map(f=>fs.readFileSync(path.join(logsDir,f),'utf8')).join('');
  assert(logs.includes('RENDERER_CRASH'),'diagnóstico de crash preservado');
  assert(!logs.includes('recuperacion.example'),'no URLs en log');
  const profilePath=path.join(legacyDir,'gravity-profile.json');
  const written=JSON.parse(fs.readFileSync(profilePath,'utf8'));
  assert(written.settings.restoreTabs&&written.settings.blockTrackers);
  assert(written.restore.length>=2,'restaurar varias pestañas normales');
  assert(!written.restore.some(x=>x.url==='https://private.example/'),'sin datos de pestañas privadas');
  assert(written.downloads.some(x=>x.name==='test.txt'&&x.path===item.path),'rutas de descargas normales guardadas');
  assert(fs.existsSync(profilePath));
  await new Promise(resolve=>setTimeout(resolve,550));
  const afterClose=JSON.parse(fs.readFileSync(profilePath,'utf8'));
  assert.deepEqual(afterClose.restore,written.restore,'el cierre no borra pestañas por guardados diferidos');
  // Segunda apertura: comprueba migración, orden, pestaña activa y carga diferida.
  const initialViewCount=events.views.length;
  vm.runInNewContext(source,{
    require:name=>name==='electron'?electron:name==='./profile-store.cjs'?require(path.join(root,'profile-store.cjs')):name==='./bookmarks-io.cjs'?require(path.join(root,'bookmarks-io.cjs')):name==='./popup-policy.cjs'?require(path.join(root,'popup-policy.cjs')):name==='./security-policy.cjs'?require(path.join(root,'security-policy.cjs')):name==='./diagnostics.cjs'?require(path.join(root,'diagnostics.cjs')):name==='./crash-recovery.cjs'?require(path.join(root,'crash-recovery.cjs')):name==='./audio-state.cjs'?require(path.join(root,'audio-state.cjs')):name==='./download-safety.cjs'?require(path.join(root,'download-safety.cjs')):name==='./session-io.cjs'?require(path.join(root,'session-io.cjs')):name.startsWith('./')?require(path.join(root,name)):require(name),
    __dirname:root,URL,Date,Math,Number,JSON,Object,Set,Map,String,Boolean,console,process,Buffer,
    setTimeout,clearTimeout,setImmediate,setInterval,clearInterval
  },{filename:'main-reopen.cjs'});
  await pause();
  const reopened=events.windows.at(-1);reopened.webContents.emit('did-finish-load');
  await pause();
  const newInvoke=(a,v)=>events.registered({sender:reopened.webContents,senderFrame:reopened.webContents.mainFrame},a,v);
  const restored=await newInvoke('state');
  assert.equal(restored.tabs.length,written.restore.length);
  assert.equal(JSON.stringify(restored.tabs.map(t=>t.url)),JSON.stringify(written.restore.map(t=>t.url)),'mismo orden, incluidos URL duplicados');
  assert.equal(restored.active,restored.tabs[Math.min(written.restoreActive,restored.tabs.length-1)].id,'pestaña activa restaurada');
  assert(events.views.length-initialViewCount<=1,'solo una pestaña de red cargada al arrancar (ahorro RAM)');
  assert(fs.existsSync(profilePath+'.backup-before-pro'),'copia del perfil anterior guardada');
  assert(restored.downloads.some(d=>d.status==='completed'&&d.name==='test.txt'));
  assert.equal(restored.bookmarks.length,preserved,'los 1006 favoritos sobreviven reinicio sin pérdida');
  // Prueba de estrés de sesión: 30 pestañas, el máximo permitido, no deben truncarse a 20.
  for(let i=restored.tabs.length;i<30;i++)await newInvoke('new');
  const maxed=await newInvoke('state');assert.equal(maxed.tabs.length,30);
  await newInvoke('new');assert.equal((await newInvoke('state')).tabs.length,30,'límite de pestañas respetado');
  events.sessionImportPath=events.sessionExportPath;
  await assert.rejects(newInvoke('importTabSet'),/Cierra algunas/, 'rechazar colección completa si no caben pestañas');
  assert.equal((await newInvoke('state')).tabs.length,30,'rechazo no cierra ni altera ninguna pestaña');
  // Atajos numéricos: Ctrl+1 y Ctrl+9 seleccionan la primera y la última.
  const keyEvent=()=>({preventDefault(){this.cancelled=true}});
  let eKey=keyEvent();reopened.webContents.emit('before-input-event',eKey,{type:'keyDown',key:'1',control:true,shift:false});
  assert.equal((await newInvoke('state')).active,maxed.tabs[0].id,'Ctrl+1 primera pestaña');
  eKey=keyEvent();reopened.webContents.emit('before-input-event',eKey,{type:'keyDown',key:'9',control:true,shift:false});
  assert.equal((await newInvoke('state')).active,maxed.tabs[29].id,'Ctrl+9 última pestaña');
  reopened.close();
  const saved30=JSON.parse(fs.readFileSync(profilePath,'utf8'));
  assert.equal(saved30.restore.length,30,'se guardan las treinta pestañas');
  vm.runInNewContext(source,{
    require:name=>name==='electron'?electron:name==='./profile-store.cjs'?require(path.join(root,'profile-store.cjs')):name==='./bookmarks-io.cjs'?require(path.join(root,'bookmarks-io.cjs')):name==='./popup-policy.cjs'?require(path.join(root,'popup-policy.cjs')):name==='./security-policy.cjs'?require(path.join(root,'security-policy.cjs')):name==='./diagnostics.cjs'?require(path.join(root,'diagnostics.cjs')):name==='./crash-recovery.cjs'?require(path.join(root,'crash-recovery.cjs')):name==='./audio-state.cjs'?require(path.join(root,'audio-state.cjs')):name==='./download-safety.cjs'?require(path.join(root,'download-safety.cjs')):name==='./session-io.cjs'?require(path.join(root,'session-io.cjs')):name.startsWith('./')?require(path.join(root,name)):require(name),
    __dirname:root,URL,Date,Math,Number,JSON,Object,Set,Map,String,Boolean,console,process,Buffer,
    setTimeout,clearTimeout,setImmediate,setInterval,clearInterval
  },{filename:'main-reopen-30.cjs'});
  await pause();const third=events.windows.at(-1);third.webContents.emit('did-finish-load');await pause();
  const state30=await events.registered({sender:third.webContents,senderFrame:third.webContents.mainFrame},'state');
  assert.equal(state30.tabs.length,30,'las 30 pestañas se restauran, sin pérdida silenciosa');
  third.close();
  console.log(`GRAVITY PRO: pruebas de regresión ampliadas. Navegación, seguridad, sesiones, restauración diferida y descargas OK.`);
}
main().catch(error=>{console.error(error);process.exitCode=1}).finally(()=>{if(process.exitCode===1)console.error('Revisar prueba antes de distribuir.')});
