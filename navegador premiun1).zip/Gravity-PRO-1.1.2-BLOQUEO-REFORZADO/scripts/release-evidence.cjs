'use strict';
// Califica únicamente la evidencia obtenida con Electron REAL en Windows.
// Ninguna simulación npm test, captura estática o respuesta HTTP acredita un release.
const fs=require('node:fs'),path=require('node:path');
const REQUIRED_SITES=new Set(['YouTube','Gmail','WhatsApp Web','Google Meet','Google Docs']);
const MAX_AGE_MS=30*24*60*60*1000;
function loadReports(folder,clock=Date.now()){
  if(!fs.existsSync(folder))return [];
  const output=[];
  for(const name of fs.readdirSync(folder)){
    if(!/^gravity-(?:pruebas-nativas|sitios)-.*\.json$/.test(name))continue;
    try{
      const filename=path.join(folder,name),stats=fs.statSync(filename);
      if(!stats.isFile()||stats.size>256*1024||stats.size<30)continue;
      const value=JSON.parse(fs.readFileSync(filename,'utf8'));
      const when=Date.parse(value.finishedAt||value.date||value.startedAt||'');
      if(!Number.isFinite(when)||when>clock+60000||clock-when>MAX_AGE_MS)continue;
      output.push({file:name,value,when});
    }catch{}
  }
  return output.sort((a,b)=>b.when-a.when);
}
function evaluate(reports){
  const normal=reports.find(r=>r.file.startsWith('gravity-pruebas-nativas-')&&
    r.value.stress30===false&&r.value.checks?.pass===true&&r.value.checks?.syntheticTabsLoaded===10);
  const stress=reports.find(r=>r.file.startsWith('gravity-pruebas-nativas-')&&
    r.value.stress30===true&&r.value.checks?.pass===true&&r.value.checks?.syntheticTabsLoaded===30);
  const site=reports.find(r=>r.file.startsWith('gravity-sitios-')&&Array.isArray(r.value.results));
  const failures=[],advice=[];
  if(!normal)failures.push('Falta informe nativo exitoso con 10 pestañas (Electron real).');
  if(!stress)failures.push('Falta informe nativo exitoso con 30 pestañas (Electron real).');
  if(!site)failures.push('Falta un informe reciente de sitios web públicos.');
  else{
    const results=new Map(site.value.results.map(entry=>[entry.site,entry.result]));
    for(const name of REQUIRED_SITES){
      if(!results.has(name))failures.push(`El informe de sitios no incluye ${name}.`);
      else if(results.get(name)!=='CARGA_HTTPS')failures.push(`La carga básica de ${name} falló (${results.get(name)}).`);
    }
    advice.push('La carga HTTP exitosa NO comprueba inicio de sesión, DRM, reproducción o llamadas.');
  }
  const samples=[...(normal?.value.metrics||[]),...(stress?.value.metrics||[])];
  if(samples.length<3)failures.push('Faltan métricas comparables de memoria/CPU con Electron real.');
  else if(samples.some(x=>!Number.isFinite(x.memoryMB)||x.memoryMB<0))
    failures.push('El informe no contiene mediciones válidas de RAM.');
  advice.push('Validar manualmente cámara, micrófono, actualización, perfil y Authenticode en Windows 10/11.');
  return {readyForManualReview:failures.length===0,failures,advice,
    sources:{native10:normal?.file||null,native30:stress?.file||null,sites:site?.file||null}};
}
module.exports={loadReports,evaluate,MAX_AGE_MS,REQUIRED_SITES};
