'use strict';
const assert=require('node:assert/strict');
const vm=require('node:vm');
const {YOUTUBE_CONTINUITY_SCRIPT,isYouTubeWatchUrl,installYouTubeContinuity}=require('../youtube-continuity.cjs');
async function run(){
  for(const url of ['https://www.youtube.com/watch?v=abc','https://music.youtube.com/watch?v=x'])assert(isYouTubeWatchUrl(url));
  for(const url of ['https://youtube.evil.org/watch','http://youtube.com/watch?v=1','https://www.youtube.com/','https://youtube.com.evil.test/watch','javascript:watch'])assert.equal(isYouTubeWatchUrl(url),false);
  let isolated=0,mainworld=0;
  assert.equal(await installYouTubeContinuity({isDestroyed:()=>false,executeJavaScriptInIsolatedWorld:async(id,scripts,userGesture)=>{assert.equal(id,1001);assert(Array.isArray(scripts));assert.equal(userGesture,false);isolated++;}},'https://www.youtube.com/watch?v=1'),true);
  await installYouTubeContinuity({executeJavaScript:async()=>mainworld++},'https://youtube.com/watch?v=2');
  assert.equal(isolated,1);assert.equal(mainworld,1);
  assert.equal(await installYouTubeContinuity({executeJavaScript:async()=>{throw Error('fallo')}},'https://youtube.com/watch?v=2'),false,'no propagar fallo a Electron');
  assert.equal(await installYouTubeContinuity({executeJavaScript:async()=>mainworld++},'https://evil.example/watch'),false);
  assert.equal(mainworld,1);
  // Ejecutar el script real en un DOM simulado, sin red ni datos de usuarios.
  const dialogs=[],timers=[],intervals=[];
  let clicks=0;
  const button={disabled:false,getClientRects:()=>[1],click:()=>clicks++};
  const makeDialog=text=>({textContent:text,getClientRects:()=>[1],querySelector:selector=>selector==='#message'?{textContent:text}:button});
  const document={documentElement:{},querySelectorAll:()=>dialogs};
  let observer;
  class MutationObserver{constructor(fn){observer=fn}observe(root,opts){assert(root);assert(opts.subtree)}}
  const context={document,window:{},MutationObserver,setTimeout:fn=>{timers.push(fn)},setInterval:fn=>{intervals.push(fn)}};
  assert.equal(vm.runInNewContext(YOUTUBE_CONTINUITY_SCRIPT,context),true);
  function flush(){for(const fn of timers.splice(0))fn()}
  dialogs.push(makeDialog('Confirmación: ¿Quieres eliminar tu lista de reproducción?'));
  flush();assert.equal(clicks,0,'no se confirman diálogos generales');
  dialogs.splice(0);dialogs.push(makeDialog('El video está en pausa. ¿Quieres seguir mirándolo?'));
  observer();flush();assert.equal(clicks,1,'el aviso real de YouTube se confirma');
  dialogs.splice(0);dialogs.push(makeDialog('Video paused. Continue watching?'));
  intervals[0]();assert.equal(clicks,2,'también reconoce aviso inglés');
  dialogs.splice(0);dialogs.push(makeDialog('¿Aceptar cookies para continuar?'));
  observer();flush();assert.equal(clicks,2,'nunca clica cookies o CAPTCHA');
  assert.equal(vm.runInNewContext(YOUTUBE_CONTINUITY_SCRIPT,context),false,'observador instalado sólo una vez');
  assert.equal(intervals.length,1,'no duplicar temporizadores');
  console.log('Gravity 1.1.1: YouTube confirma sólo aviso de inactividad sin tocar pausas, cookies ni CAPTCHA PASS');
}
run().catch(error=>{console.error(error);process.exitCode=1});
