'use strict';
const fs=require('node:fs');const path=require('node:path');const assert=require('node:assert/strict');
const content=fs.readFileSync(path.join(__dirname,'site-matrix.cjs'),'utf8');
for(const host of ['www.youtube.com','mail.google.com','web.whatsapp.com','meet.google.com','docs.google.com']){
  assert(content.includes(host),`Falta caso ${host}`);
}
assert(content.includes('setPermissionRequestHandler((_wc,_permission,reply)=>reply(false))'));
assert(content.includes('show:false'));
assert(content.includes('--consent-network'));
assert(!content.includes('persist:gravity-directo'));
assert(fs.existsSync(path.join(__dirname,'native-ui-smoke.cjs')),'autodiagnóstico nativo');
for(const file of ['native-regression.cjs','media-check.cjs'])assert(fs.existsSync(path.join(__dirname,file)),`Falta prueba nativa ${file}`);
const regression=fs.readFileSync(path.join(__dirname,'native-regression.cjs'),'utf8');
assert(regression.includes('mkdtempSync'),'La prueba nativa debe tener perfil temporal');
assert(regression.includes('setPermissionRequestHandler'),'Las pruebas externas deben denegar permisos');
assert(regression.includes('127.0.0.1'),'La prueba nativa debe cargar solo recursos locales');
console.log('GRAVITY nativo: matriz de servicios, aislamiento y consentimiento listos (no ejecutado).');
