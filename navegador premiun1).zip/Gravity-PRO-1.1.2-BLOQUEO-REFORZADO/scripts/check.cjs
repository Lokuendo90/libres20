'use strict';
const fs=require('node:fs'),cp=require('node:child_process'),path=require('node:path');
const root=path.join(__dirname,'..');
for(const file of ['main.cjs','preload.cjs','profile-store.cjs','bookmarks-io.cjs','popup-policy.cjs','security-policy.cjs','diagnostics.cjs','crash-recovery.cjs','audio-state.cjs','download-safety.cjs','session-io.cjs','pro-tab-state.cjs','profiles.cjs','credential-vault.cjs','page-tools.cjs','tab-efficiency.cjs','permission-hardening.cjs','release-channel.cjs','update-service.cjs','crop-preload.cjs','privacy-shields.cjs','smart-search.cjs','defender-scan.cjs','site-risk.cjs','ad-cosmetics.cjs','fullscreen-policy.cjs','youtube-continuity.cjs','filter-refresh.cjs','abp-extended.cjs','youtube-ad-handler.cjs','scripts/test-adblock-advanced.cjs','scripts/test-youtube-ad-handler.cjs','scripts/native-adblock-smoke.cjs','scripts/test-filter-refresh.cjs','scripts/test-youtube-continuity.cjs','scripts/test-fullscreen.cjs','scripts/test-shields.cjs','scripts/test-smart-search.cjs','scripts/test-site-risk.cjs','scripts/test-defender.cjs','app/reader.js','app/crop.js','scripts/test-pro-features.cjs','scripts/test-hardening.cjs','scripts/test-updater.cjs','scripts/test-release-evidence.cjs','scripts/test-data-integrity.cjs','scripts/test-protection.cjs',
  'scripts/release-evidence.cjs','scripts/evaluate-release-evidence.cjs','scripts/preflight.cjs','scripts/build-release.cjs','scripts/test-session-io.cjs','app/ui.js','app/motion.js','scripts/test-smoke.cjs','scripts/test-profile.cjs','scripts/test-bookmarks.cjs','scripts/test-visual.cjs','scripts/test-popup.cjs','scripts/test-security.cjs','scripts/test-diagnostics.cjs','scripts/test-recovery.cjs','scripts/test-native-config.cjs','scripts/test-audio-state.cjs','scripts/test-download-safety.cjs','scripts/test-release-policy.cjs','scripts/native-ui-smoke.cjs','scripts/native-regression.cjs','scripts/media-check.cjs','scripts/site-matrix.cjs','scripts/verify-integrity.cjs','scripts/release-guard.cjs']){
  cp.execFileSync(process.execPath,['--check',path.join(root,file)],{stdio:'inherit'});
}
for(const file of ['landscape.jpg','moon.jpg','clouds.jpg','lava-mask.png','gravity.svg','gravity.png','youtube.svg','google.svg','facebook.svg','instagram.svg','gmail.svg','netflix.svg','amazon-a.svg']){
  if(!fs.existsSync(path.join(root,'app/assets',file)))throw Error('Falta '+file);
}
const html=fs.readFileSync(path.join(root,'app/index.html'),'utf8');
for(const id of ['tabs','searchForm','addressForm','siteHint','findbar','findQuery','findCount','suggestions','panel','downloadItems']){
  if(id==='downloadItems')continue; // El panel lo crea ui.js al abrir Descargas.
  if(!html.includes(`id="${id}"`))throw Error('Falta elemento '+id);
}
const packageJSON=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
if(packageJSON.devDependencies.electron==='latest')throw Error('Electron no debe quedar en latest');
if(!/(?:beta|rc)/.test(packageJSON.version)&&process.env.GRAVITY_RELEASE_BUILD!=='1')throw Error('La versión estable exige un release aprobado y firmado');
if(!fs.existsSync(path.join(root,'build/gravity.ico')))throw Error('Falta icono para el instalador');
const {validatePublishSettings}=require('../release-channel.cjs');
if(!validatePublishSettings(packageJSON.build?.publish,require('../release-channel.json')))throw Error('El canal debe coincidir con el feed configurado');
console.log('Gravity PRO: sintaxis, interfaz, recursos y versión fija de Electron: OK.');
