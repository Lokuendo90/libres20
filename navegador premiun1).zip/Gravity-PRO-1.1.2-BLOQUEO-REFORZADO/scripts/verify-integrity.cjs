'use strict';
// Verifica que la copia extraída mantiene los bytes que el proyecto entregó.
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
const manifest=path.join(root,'SHA256SUMS.txt');
if(!fs.existsSync(manifest))throw Error('No se encontró SHA256SUMS.txt');
let verified=0;
for(const line of fs.readFileSync(manifest,'utf8').split(/\r?\n/)){
  if(!line.trim())continue;
  const match=/^([a-f0-9]{64})  (.+)$/.exec(line);
  if(!match)throw Error('Manifest SHA256SUMS inválido');
  const relative=match[2].replace(/\\/g,'/');
  if(relative.startsWith('/')||relative.split('/').includes('..'))throw Error('Ruta peligrosa en manifiesto');
  const filename=path.resolve(root,relative);
  if(!filename.startsWith(root+path.sep)||!fs.statSync(filename).isFile())throw Error('Archivo ausente: '+relative);
  const actual=crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex');
  if(actual!==match[1])throw Error('Archivo alterado: '+relative);
  verified++;
}
if(verified<20)throw Error('Manifiesto incompleto');
console.log(`Gravity: ${verified} archivos verificados por SHA-256.`);
