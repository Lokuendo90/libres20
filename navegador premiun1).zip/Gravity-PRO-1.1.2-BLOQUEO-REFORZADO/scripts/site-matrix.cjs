'use strict';
// Prueba VOLUNTARIA de PORTADAS públicas con Electron real. Sin autenticación ni cámara.
// No se utiliza la carpeta gravity-directo ni cookies del navegador del usuario.
if(!process.argv.includes('--consent-network')){
  console.error('Este test abre sitios públicos en Internet. Para realizarlo: npm run native:sites');
  process.exit(2);
}
const {app,BrowserWindow,session}=require('electron');
const {randomUUID}=require('node:crypto');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const TEST_SITES=Object.freeze([
  ['Ejemplo HTTPS','https://example.com/'],
  ['Wikipedia','https://www.wikipedia.org/'],
  ['YouTube','https://www.youtube.com/'],
  ['Gmail','https://mail.google.com/'],
  ['WhatsApp Web','https://web.whatsapp.com/'],
  ['Google Meet','https://meet.google.com/'],
  ['Google Docs','https://docs.google.com/']
]);
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'gravity-public-sites-'));
app.setPath('userData',temp);
const results=[];
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function run(){
  await app.whenReady();
  const part=`gravity-compat-${randomUUID()}`;
  const isolated=session.fromPartition(part);
  isolated.setPermissionRequestHandler((_wc,_permission,reply)=>reply(false));
  isolated.setPermissionCheckHandler(()=>false);
  isolated.setDevicePermissionHandler?.(()=>false);
  const win=new BrowserWindow({show:false,width:1200,height:800,
    webPreferences:{partition:part,nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,webviewTag:false}});
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  try{
    for(const [site,url] of TEST_SITES){
      let failure='',crashed=false,reason='';const wc=win.webContents;
      const failed=(_e,code,_msg,_url,mainFrame)=>{if(mainFrame&&code!==-3)failure=String(code)};
      const gone=(_e,details)=>{crashed=true;reason=details?.reason||'unknown'};
      wc.on('did-fail-load',failed);wc.on('render-process-gone',gone);
      try{
        const finish=await Promise.race([
          wc.loadURL(url).then(()=> 'loaded',()=> 'rejected'),
          wait(20000).then(()=> 'timeout')
        ]);
        if(finish==='timeout')wc.stop();
        let protocol='',redirected=false;
        try{const final=new URL(wc.getURL());protocol=final.protocol;redirected=final.hostname!==new URL(url).hostname}catch{}
        const result=crashed?'FALLO_RENDERER':finish==='timeout'?'TIMEOUT':failure?'ERROR_'+failure:protocol==='https:'?'CARGA_HTTPS':'REVISAR';
        results.push({site,result,redirected,processFailure:crashed?reason:undefined});
      }catch{results.push({site,result:'ERROR_LOCAL',redirected:false})}
      finally{wc.removeListener('did-fail-load',failed);wc.removeListener('render-process-gone',gone)}
      console.log(site+': '+results.at(-1).result);
    }
  }finally{
    try{win.destroy()}catch{}
    try{await isolated.clearStorageData();await isolated.clearCache()}catch{}
  }
}
function report(){
  const folder=path.join(app.getPath('documents'),'Gravity-Diagnosticos');fs.mkdirSync(folder,{recursive:true});
  const name=`gravity-sitios-${new Date().toISOString().replace(/[:.]/g,'-')}.json`;
  const file=path.join(folder,name);
  fs.writeFileSync(file,JSON.stringify({version:app.getVersion(),date:new Date().toISOString(),
    kind:'SOLO carga pública sin cuentas, DRM, reproduccion de video ni videollamada',results},null,2)+'\n',{mode:0o600});
  console.log('Reporte de portadas (SIN URLs de navegación):',file);
}
app.whenReady().then(async()=>{
  try{await run()}catch(e){console.error('GRAVITY PRUEBA SITIOS: ERROR',e?.message||e);process.exitCode=1}
  finally{try{report()}catch(e){console.error('No se pudo guardar reporte:',e?.message||e)}
    try{fs.rmSync(temp,{recursive:true,force:true})}catch{}app.quit()}
}).catch(e=>{console.error('Fallo Electron:',e.message);process.exitCode=1;app.quit()});
