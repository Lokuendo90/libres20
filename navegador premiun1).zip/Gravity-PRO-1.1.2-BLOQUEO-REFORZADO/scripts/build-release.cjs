'use strict';
// Único camino para una versión ESTABLE firmada: sin publicar ni subir archivos.
const {execFileSync}=require('node:child_process'),path=require('node:path');
const root=path.resolve(__dirname,'..');
if(process.platform!=='win32'){
  console.error('El release firmado debe compilarse y verificarse en Windows.');process.exit(1);
}
const env={...process.env,GRAVITY_RELEASE_BUILD:'1'};
function run(bin,args){
  console.log('Gravity release:',bin,args.join(' '));
  execFileSync(bin,args,{cwd:root,env,stdio:'inherit',shell:false});
}
try{
  run(process.execPath,['scripts/release-guard.cjs']);
  run(process.execPath,['scripts/preflight.cjs']);
  run('npm.cmd',['ci','--no-audit','--no-fund']);
  run('npm.cmd',['audit','--omit=dev','--audit-level=high']);
  run('npm.cmd',['test']);
  run('npm.cmd',['run','native:ui']);
  run('npm.cmd',['run','native:regression']);
  run('npm.cmd',['run','native:regression:30']);
  run('npx.cmd',['--no-install','electron-builder','--win','nsis','--x64','--publish','never']);
  run('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-File','scripts/verify-installer-signature.ps1']);
  console.log('GRAVITY RELEASE: instalador firmado localmente. No se ha publicado en Internet.');
}catch(error){console.error('GRAVITY RELEASE BLOQUEADO:',error.message);process.exitCode=1}
