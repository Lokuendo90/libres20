'use strict';
// Bloquea cambios no autorizados en la identidad visual existente.
const {createHash}=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const baseline=require('../VISUAL-BASELINE.json');
const mismatches=[];
for(const [relative,expected] of Object.entries(baseline.files)){
  const name=path.join(root,relative);
  const actual=fs.existsSync(name)?createHash('sha256').update(fs.readFileSync(name)).digest('hex'):'ARCHIVO AUSENTE';
  if(actual!==expected)mismatches.push(`${relative}: ${actual}`);
}
if(mismatches.length)throw new Error('La identidad visual difiere de la base aprobada:\n'+mismatches.join('\n'));
console.log(`Gravity: ${Object.keys(baseline.files).length} recursos visuales idénticos a la referencia aprobada (${baseline.baseVersion}).`);
