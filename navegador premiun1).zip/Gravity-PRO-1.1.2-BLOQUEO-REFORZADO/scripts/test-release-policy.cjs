'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {execFileSync}=require('node:child_process');
const root=path.join(__dirname,'..');
const pkg=require('../package.json');
assert.equal(pkg.main,'main.cjs');
const prerelease=/(?:beta|rc)/.test(pkg.version);
assert(prerelease||process.env.GRAVITY_RELEASE_BUILD==='1','no lanzar versión estable fuera del proceso de firma');
assert.equal(pkg.build?.asar,true);
const {validatePublishSettings,validateChannel}=require('../release-channel.cjs');
const channel=require('../release-channel.json');
assert(validatePublishSettings(pkg.build?.publish,channel),'el feed del instalador debe coincidir con el canal HTTPS');
if(prerelease)assert.deepEqual(pkg.build?.publish,[],'la beta nunca se publica');
else assert(validateChannel(channel,{platform:'win32',isPackaged:true,builderPublisher:pkg.build.win.publisherName}).ready,'La versión estable exige un feed HTTPS oficial y un editor firmado');
for(const file of ['audio-state.cjs','download-safety.cjs','security-policy.cjs','profile-store.cjs','diagnostics.cjs','session-io.cjs','pro-tab-state.cjs','profiles.cjs','credential-vault.cjs','page-tools.cjs','crop-preload.cjs','tab-efficiency.cjs','permission-hardening.cjs','update-service.cjs','release-channel.cjs','release-channel.json','privacy-shields.cjs','smart-search.cjs','defender-scan.cjs','site-risk.cjs','ad-cosmetics.cjs'])
  assert(pkg.build.files.includes(file),`El instalador debe incluir ${file}`);
assert(pkg.scripts['pack:win:beta'].includes('--publish never'));
assert.equal(pkg.dependencies['electron-updater'],'6.8.10','Dependencia de actualizaciones fijada');
assert.equal(require('../release-channel.json').enabled,false,'Nunca distribuir canal desconocido');
assert(pkg.scripts['release:win'].includes('build-release.cjs'));
assert(fs.readFileSync(path.join(root,'scripts/build-release.cjs'),'utf8').includes('release-guard.cjs'));
assert(fs.existsSync(path.join(root,'scripts/native-ui-smoke.cjs')));
assert(fs.existsSync(path.join(root,'COMPROBAR-GRAVITY-NATIVO-WINDOWS.bat')));
const ui=fs.readFileSync(path.join(root,'app/index.html'),'utf8');
assert(/Content-Security-Policy/.test(ui),'CSP de la interfaz local obligatorio');
assert(!/https?:\/\/[^\s"']+\.js/.test(ui),'no scripts remotos en interfaz local');
let blocked=false;
try{execFileSync(process.execPath,[path.join(root,'scripts/release-guard.cjs')],{stdio:'pipe',env:{...process.env,GRAVITY_WINDOWS_TESTS_APPROVED:'',GRAVITY_PUBLISHER_APPROVED:'',WIN_CSC_LINK:'',WIN_CSC_KEY_PASSWORD:''}})}
catch(e){blocked=e.status!==0}
assert(blocked,'La publicación pública debe permanecer bloqueada');
console.log('GRAVITY release: paquete completo, CSP local, firma y bloqueo de publicación: OK.');
