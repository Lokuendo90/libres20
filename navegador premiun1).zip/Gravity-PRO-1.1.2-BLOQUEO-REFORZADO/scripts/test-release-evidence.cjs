'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {evaluate,loadReports}=require('./release-evidence.cjs');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'gravity-evidence-test-'));
try{
  assert.equal(evaluate([]).readyForManualReview,false,'Sin informes reales, no hay publicación');
  const when=new Date().toISOString();
  const metrics=[{memoryMB:200,cpuPercent:2},{memoryMB:290,cpuPercent:6}];
  const native=(stress30,n)=>({finishedAt:when,stress30,checks:{pass:true,syntheticTabsLoaded:n},metrics});
  fs.writeFileSync(path.join(dir,'gravity-pruebas-nativas-10.json'),JSON.stringify(native(false,10)));
  fs.writeFileSync(path.join(dir,'gravity-pruebas-nativas-30.json'),JSON.stringify(native(true,30)));
  fs.writeFileSync(path.join(dir,'gravity-sitios-1.json'),JSON.stringify({date:when,
    results:['YouTube','Gmail','WhatsApp Web','Google Meet','Google Docs'].map(site=>({site,result:'CARGA_HTTPS'}))}));
  let decision=evaluate(loadReports(dir));assert.equal(decision.readyForManualReview,true);
  assert(decision.advice.some(x=>x.includes('NO comprueba')),'No confundir carga de portada con servicios completos');
  fs.writeFileSync(path.join(dir,'gravity-sitios-1.json'),JSON.stringify({date:when,results:[{site:'Gmail',result:'TIMEOUT'}]}));
  decision=evaluate(loadReports(dir));assert.equal(decision.readyForManualReview,false);
  fs.writeFileSync(path.join(dir,'gravity-sitios-old.json'),JSON.stringify({date:'2020-01-01',results:[]}));
  assert.equal(loadReports(dir).length,3,'Omitir informes caducados');
  console.log('GRAVITY RC evidencias: faltantes, caducidad, métricas y sitios comprobados.');
}finally{fs.rmSync(dir,{recursive:true,force:true})}
