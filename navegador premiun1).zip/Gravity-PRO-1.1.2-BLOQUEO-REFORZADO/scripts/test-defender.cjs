'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {scanDownloadedFile}=require('../defender-scan.cjs');
(async()=>{
  assert.equal((await scanDownloadedFile('/nonexistent')).status,'unavailable');
  const tmp=path.join(os.tmpdir(),'gravity-scan-test-'+process.pid+'.txt');fs.writeFileSync(tmp,'contenido inocuo de prueba');
  try{
    const fake=(code)=>((_exe,args,_opts,callback)=>{assert.deepEqual(args.slice(0,3),['-Scan','-ScanType','3']);callback(code===null?null:{code})});
    const result=await scanDownloadedFile(tmp,{platform:'win32',exe:'C:\\Program Files\\Windows Defender\\MpCmdRun.exe',execute:fake(null)});
    assert.equal(result.status,'review','Código 0 NO equivale a archivo seguro: puede haberse remediado malware');
    const flagged=await scanDownloadedFile(tmp,{platform:'win32',exe:'Defender.exe',execute:fake(2)});
    assert.equal(flagged.status,'alert','Código 2 puede ser detección o error');
  }finally{fs.unlinkSync(tmp)}
  console.log('GRAVITY Defender: estados conservadores, sin falsas garantías antivirus PASS.');
})().catch(e=>{console.error(e);process.exitCode=1});
