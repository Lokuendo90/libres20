'use strict';
const assert=require('node:assert/strict');
const {createSessionDocument,parseSessionDocument,MAX_SESSION_BYTES}=require('../session-io.cjs');
const original=[{id:'1',url:'https://docs.example/a?x=1',private:false},
  {id:'2',url:'https://privado.example/no-exportar',private:true},
  {id:'3',url:'https://docs.example/a?x=1',private:false},
  {id:'4',url:'gravity://home',private:false},
  {id:'5',url:'https://user:pass@bad.example/',private:false}];
const document=createSessionDocument(original,'3');
assert.equal(document.count,3);
assert.equal(document.excluded,2);
assert(!document.content.includes('privado.example'));
assert(!document.content.includes('bad.example'));
const imported=parseSessionDocument(document.content);
assert.deepEqual(imported.urls,['https://docs.example/a?x=1','https://docs.example/a?x=1','gravity://home']);
assert.equal(imported.activeIndex,1);
for(const malicious of ['javascript:alert(1)','file:///etc/passwd','data:text/html,bad',
  'https://name:pass@example.com','http://\nexample.com']){
  const data=JSON.parse(document.content);data.urls[0]=malicious;
  assert.throws(()=>parseSessionDocument(JSON.stringify(data)),/inseguras|inválidas/);
}
assert.throws(()=>parseSessionDocument('{bad'),/JSON válido/);
assert.throws(()=>parseSessionDocument(JSON.stringify({format:'otro',version:1,urls:['https://example.com'],activeIndex:0})),/compatible/);
assert.throws(()=>parseSessionDocument(JSON.stringify({format:'gravity-tabs',version:99,urls:['https://example.com'],activeIndex:0})),/compatible/);
assert.throws(()=>parseSessionDocument(JSON.stringify({format:'gravity-tabs',version:1,urls:Array(31).fill('https://example.com'),activeIndex:0})),/de 1 a 30/);
assert.throws(()=>parseSessionDocument(' '.repeat(MAX_SESSION_BYTES+1)),/grande/);
assert.throws(()=>createSessionDocument([{id:'1',url:'https://private.example/',private:true}],'1'),/No hay pestañas/);
const many=createSessionDocument(Array.from({length:30},(_,i)=>({id:String(i),url:'https://example.com/'+i,private:false})),'29');
assert.equal(parseSessionDocument(many.content).urls.length,30);
console.log('Gravity: colección opcional de pestañas, privacidad, duplicados, topes y validaciones OK.');
