# Comprobación POSTERIOR a la compilación. No firma el archivo.
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$pkg = Get-Content (Join-Path $root 'package.json') -Raw | ConvertFrom-Json
$file = Join-Path $root ("dist/Gravity-Setup-" + $pkg.version + "-x64.exe")
if (-not (Test-Path -LiteralPath $file)) { throw "No existe el instalador esperado: $file" }
$signature = Get-AuthenticodeSignature -LiteralPath $file
if ($signature.Status -ne 'Valid' -or -not $signature.SignerCertificate) {
  throw "El instalador NO tiene firma Authenticode válida: $($signature.Status). No publicar."
}
if (-not $env:GRAVITY_EXPECTED_SIGNER) { throw "Falta GRAVITY_EXPECTED_SIGNER: no se puede aprobar la firma sin comparar el editor." }
if ($env:GRAVITY_EXPECTED_SIGNER) {
  if ($signature.SignerCertificate.Subject -ne $env:GRAVITY_EXPECTED_SIGNER) {
    throw "El firmante no coincide con GRAVITY_EXPECTED_SIGNER. No publicar."
  }
}
$hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $file).Hash
Write-Host "Firma válida: $($signature.SignerCertificate.Subject)"
Write-Host "SHA-256: $hash"
Write-Host "Recuerda: la firma válida no equivale a pruebas de seguridad ni de compatibilidad."
