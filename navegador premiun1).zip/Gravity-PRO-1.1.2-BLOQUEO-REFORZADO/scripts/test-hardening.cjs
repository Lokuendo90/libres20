'use strict';
const assert=require('node:assert/strict');
const {eligible,protectedHost,safeToSuspend,SAFE_TO_SUSPEND_SCRIPT,sampleProcessMetrics,INACTIVITY_MS,MAX_PER_SWEEP}=require('../tab-efficiency.cjs');
const {requestPermissionContext,checkPermissionContext}=require('../permission-hardening.cjs');
const {EVENTS,sanitizedMetadata}=require('../diagnostics.cjs');
async function run(){
  const wc={id:42,isDestroyed:()=>false,isCurrentlyAudible:()=>false,executeJavaScript:async()=>true};
  const t={id:'b',url:'https://www.wikipedia.org/wiki/Historia',view:{webContents:wc},lastActivatedAt:1000};
  const old=1000+INACTIVITY_MS+1000;
  assert.equal(eligible(t,'a',new Set(),old),true);
  for(const key of ['private','pinned','lazy','loading','audible','error','viewCorrupted']){
    const bad={...t,[key]:key==='error'?'Error':true};
    assert.equal(eligible(bad,'a',new Set(),old),false,key+' debe bloquear suspensión');
  }
  assert.equal(eligible(t,'b',new Set(),old),false,'nunca pestaña activa');
  assert.equal(eligible(t,'a',new Set([42]),old),false,'nunca descarga activa');
  assert.equal(eligible(t,'a',new Set(),INACTIVITY_MS),false,'30 min completos');
  assert.equal(eligible({...t,url:'https://meet.google.com/abc'},'a',new Set(),old),false);
  assert.equal(eligible({...t,url:'https://subdomain.youtube.com'},'a',new Set(),old),false);
  assert.equal(protectedHost('https://safewhatsapp.com/'),false,'no coincidencias parciales');
  assert.equal(MAX_PER_SWEEP,2);
  assert(SAFE_TO_SUSPEND_SCRIPT.includes('input,textarea,select'));
  assert(SAFE_TO_SUSPEND_SCRIPT.includes('video,audio,canvas,iframe'));
  assert.equal(await safeToSuspend(wc),true);
  assert.equal(await safeToSuspend({...wc,executeJavaScript:async()=>false}),false);
  assert.equal(await safeToSuspend({...wc,executeJavaScript:async()=>{throw Error('blocked')}}),false);
  const metrics=sampleProcessMetrics([{memory:{workingSetSize:10240},cpu:{percentCPUUsage:0.5}},{memory:{workingSetSize:2048},cpu:{percentCPUUsage:1.25}}]);
  assert.deepEqual(metrics,{memoryMB:12,cpuPercent:1.8,processes:2});
  assert.deepEqual(sampleProcessMetrics([]),{memoryMB:null,cpuPercent:null,processes:0});
  assert.equal(requestPermissionContext('https://meet.google.com/','media').allowed,true);
  assert.equal(requestPermissionContext('https://meet.google.com/','media',{requestingUrl:'https://meet.google.com/call',securityOrigin:'https://meet.google.com'}).allowed,true);
  assert.equal(requestPermissionContext('https://meet.google.com/','media',{requestingUrl:'https://evil.example',securityOrigin:'https://meet.google.com'}).allowed,false);
  assert.equal(requestPermissionContext('https://meet.google.com/','media',{requestingUrl:'file:///etc/passwd'}).allowed,false);
  assert.equal(requestPermissionContext('https://evil.example','media',{requestingUrl:'http://evil.example'}).allowed,false);
  assert.equal(checkPermissionContext('https://meet.google.com','media',{requestingUrl:'https://meet.google.com/meeting'}).allowed,true);
  assert.equal(checkPermissionContext('https://meet.google.com','media',{requestingUrl:'https://evil.example'}).allowed,false);
  assert.equal(checkPermissionContext('https://evil.example','usb').allowed,false);
  assert(EVENTS.has('CHILD_PROCESS_FAILURE'));
  assert(EVENTS.has('AUTO_MEMORY_SAVED'));
  assert.deepEqual(sanitizedMetadata({url:'https://private.example/',password:'DO_NOT_LOG',count:2,reason:'crashed'}),{count:2,reason:'crashed'});
  console.log('GRAVITY 0.9.5: protección de procesos, ahorro opt-in, privacidad y mediciones PASS');
}
run().catch(e=>{console.error(e);process.exitCode=1});
