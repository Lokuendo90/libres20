'use strict';
const assert=require('node:assert/strict');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');
const {parseList,createShields,readRules,saveRules,downloadLists}=require('../privacy-shields.cjs');
const {parseAdvancedRule,parseCosmeticRule,compileExtendedRules}=require('../abp-extended.cjs');
(async()=>{
  const source=[
    '! Suscripción de filtros ilustrativa, sin datos externos',
    '||ads.example/serve/*$script,third-party',
    '||ads.example/banner/*$image,domain=shop.example',
    '||ads.example/video/*$media',
    '@@||ads.example/serve/*$script,domain=trusted.example',
    '/advertising/widget/*$xmlhttprequest,third-party',
    '||tracker.example^',
    '##.sponsored-box',
    'shop.example##[data-test="advertisement"]',
    'shop.example#@#.sponsored-box',
    '||ignored.example^$redirect=void',
    'shop.example##body',
    '##[class="ad"]:style(display:none)',
  ].join('\n');
  const rules=parseList(source);
  assert(rules.length>=9&&rules.some(r=>r.kind==='pattern')&&rules.some(r=>r.kind==='cosmetic'));
  assert(!rules.some(r=>r.domain==='ignored.example'),'unsupported redirect must not broaden blocking');
  assert(!rules.some(r=>r.selector==='body'),'never hide body');
  let blocked=0;const sh=createShields({rules,onBlocked:()=>blocked++});
  function blockedAt(url,type,site){return sh.shouldBlock({url,resourceType:type},site)}
  assert(blockedAt('https://ads.example/serve/display.js','script','https://store.other'), 'network path blocked');
  assert(!blockedAt('https://ads.example/serve/display.js','script','https://trusted.example/'), 'domain-specific allow');
  assert(!blockedAt('https://ads.example/serve/display.js','image','https://store.other/'), 'resource type restriction');
  assert(blockedAt('https://ads.example/banner/1.jpg','image','https://shop.example/'), 'site scoped rule');
  assert(!blockedAt('https://ads.example/banner/1.jpg','image','https://unrelated.example/'), 'site excludes site-scoped filter');
  assert(blockedAt('https://ads.example/video/a','media','https://other.test'),'path media rule');
  assert(blockedAt('https://cdn.other.net/advertising/widget/123','xhr','https://other.test'),'generic rule');
  assert(!blockedAt('https://cdn.other.net/advertising/widget/123','script','https://other.test'),'generic resource type');
  assert(blockedAt('https://www.youtube.com/pagead/interaction/','xhr','https://www.youtube.com/watch?v=ab'),'first party advertising endpoint blocked');
  assert(!blockedAt('https://rr2---sn.googlevideo.com/videoplayback?id=ok','media','https://www.youtube.com/watch?v=ab'),'NEVER block video content CDNs');
  assert(!blockedAt('https://www.youtube.com/youtubei/v1/player','xhr','https://www.youtube.com/watch?v=ab'),'video metadata is used for playback');
  assert(!blockedAt('https://www.youtube.com/watch?v=ab','mainFrame','https://other.test'),'page main frames must load');
  assert(sh.cosmeticCssFor('https://shop.example/').includes('data-test="advertisement"'));
  assert(!sh.cosmeticCssFor('https://shop.example/').includes('.sponsored-box{'));
  assert(sh.cosmeticCssFor('https://other.test/').includes('.sponsored-box{'));
  assert(!sh.cosmeticCssFor('https://other.test/').includes('data-test="advertisement"'));
  assert(sh.ruleStats().advanced>=6&&sh.ruleStats().cosmetic>=2);
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'gravity-ads-'));
  try{const target=path.join(dir,'rules.json');saveRules(target,rules);
    const restored=readRules(target);assert.deepEqual(restored,rules,'preserve cosmetic + network filters across restart');
    assert.equal(createShields({rules:restored}).shouldBlock({url:'https://ads.example/serve/code.js',resourceType:'script'},'https://other.net'),true);
  }finally{fs.rmSync(dir,{recursive:true,force:true});}
  assert.equal(parseAdvancedRule('||an.example^$unknown-flag'),null);
  assert.equal(parseCosmeticRule('example.com##:root'),null);
  assert.equal(parseCosmeticRule('example.com##body'),null);
  const many=[];for(let i=0;i<2500;i++)many.push(`||advertiser-${i}.example/path/*$image,third-party`);
  const indexed=compileExtendedRules(many.map(parseAdvancedRule));assert.equal(indexed.size,2500);
  const start=performance.now();for(let i=0;i<500;i++)indexed.evaluate(`https://shop.example/product/${i}.js`,'script',true,'https://shop.example');
  const ms=performance.now()-start;assert(ms<2500,`Request evaluation unexpectedly slow: ${ms.toFixed(1)}ms`);
  const example=Array.from({length:130},(_,i)=>`||ads-${i}.example/path/*$image`).join('\n')+'\n##.ad-label';
  const downloaded=await downloadLists(async()=>example);
  assert(downloaded.some(r=>r.kind==='cosmetic')&&downloaded.some(r=>r.kind==='pattern'));
  console.log(`GRAVITY 1.1.2 filtros de red/cosméticos, excepciones, origen y rendimiento: PASS (${ms.toFixed(1)} ms/500 consultas).`);
})().catch(e=>{console.error(e);process.exitCode=1});
