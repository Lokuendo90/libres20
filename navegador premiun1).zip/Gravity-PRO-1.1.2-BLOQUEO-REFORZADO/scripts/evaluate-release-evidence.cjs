'use strict';
const path=require('node:path'),os=require('node:os');
const {loadReports,evaluate}=require('./release-evidence.cjs');
const dir=process.env.GRAVITY_REPORT_DIR||path.join(os.homedir(),'Documents','Gravity-Diagnosticos');
const decision=evaluate(loadReports(dir));
console.log('GRAVITY RC - EVIDENCIAS NATIVAS DE WINDOWS');
console.log('Carpeta revisada:',dir);
console.log('Reportes:',JSON.stringify(decision.sources));
for(const issue of decision.failures)console.error('PENDIENTE:',issue);
for(const note of decision.advice)console.log('AVISO:',note);
if(!decision.readyForManualReview){console.error('NO APROBADO PARA PUBLICAR.');process.exitCode=1}
else console.log('Reportes técnicos disponibles. FALTA revisión manual, firma y auditoría de seguridad; no es certificación.');
