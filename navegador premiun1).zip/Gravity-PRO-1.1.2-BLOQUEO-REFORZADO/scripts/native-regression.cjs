'use strict';
// Prueba Nativa Electron contra sitio SINTÉTICO en 127.0.0.1, sin cuentas ni red externa.
// Perfil TEMPORAL. Salida numérica en Documentos/Gravity-Diagnosticos, sin URLs o contraseñas.
const {app,BrowserWindow,WebContentsView,session}=require('electron');
const http=require('node:http'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {randomUUID}=require('node:crypto');
const {sampleProcessMetrics}=require('../tab-efficiency.cjs');
const scratch=fs.mkdtempSync(path.join(os.tmpdir(),'gravity-native-095-'));
app.setPath('userData',scratch);
const extraStress=process.argv.includes('--stress-30');
const crashProbe=process.argv.includes('--crash-probe');
const MAX_VIEWS=extraStress?30:10;
let server=null, win=null;
const views=[];
const results={version:'1.0.0-rc.1',test:'web local, Electron real, perfil temporal',
  startedAt:new Date().toISOString(),stress30:extraStress,checks:{},metrics:[],errors:[],
  limitations:'No prueba sitios públicos, login, DRM, llamadas, multimedia remota ni seguridad del motor ante exploits.'};
function assert(check,message){if(!check)throw Error(message)}
const pause=ms=>new Promise(r=>setTimeout(r,ms));
function timeout(promise,ms,label){
  let timer;return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Timeout '+label)),ms)})]).finally(()=>clearTimeout(timer));
}
function startServer(){return new Promise((resolve,reject)=>{
  server=http.createServer((req,res)=>{
    res.setHeader('Cache-Control','no-store');
    res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('Content-Type','text/html; charset=utf-8');
    res.end('<!doctype html><title>Gravity Local Fixture</title><main><h1>Prueba nativa</h1><p>Sitio local sin datos privados</p></main>');
  }).once('error',reject).listen(0,'127.0.0.1',()=>resolve(server.address().port));
})}
function metric(label){
  let values={memoryMB:null,cpuPercent:null,processes:0};
  try{values=sampleProcessMetrics(app.getAppMetrics?.()||[])}catch{}
  results.metrics.push({sample:label,views:views.length,...values});
  console.log('MUESTRA',label,JSON.stringify(values));
}
function addView(partition){
  const v=new WebContentsView({webPreferences:{partition,nodeIntegration:false,contextIsolation:true,sandbox:true,
    webSecurity:true,webviewTag:false,backgroundThrottling:true}});
  win.contentView.addChildView(v);v.setBounds({x:0,y:106,width:1200,height:694});v.setVisible(false);
  v.webContents.setWindowOpenHandler(()=>{results.checks.popupDenied=(results.checks.popupDenied||0)+1;return {action:'deny'}});
  views.push(v);return v;
}
async function run(){
  await app.whenReady();
  const port=await startServer();const target=`http://127.0.0.1:${port}/`;
  const partition='gravity-native-test-'+randomUUID();
  const ses=session.fromPartition(partition);
  ses.setPermissionCheckHandler(()=>false);
  ses.setPermissionRequestHandler((_wc,_permission,done)=>done(false));
  ses.setDevicePermissionHandler?.(()=>false);
  win=new BrowserWindow({show:false,width:1200,height:800,webPreferences:{
    nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,webviewTag:false}});
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  await timeout(win.loadFile(path.join(__dirname,'../app/index.html')),20000,'interfaz');
  const ui=await win.webContents.executeJavaScript(`({
    hasAddress:!!document.getElementById('address'),hasPlanet:!!document.getElementById('scene'),
    node:typeof require!=='undefined'||typeof process!=='undefined'
  })`);
  assert(ui.hasAddress&&ui.hasPlanet&&!ui.node,'Interfaz Gravity/aislamiento local incorrectos');
  results.checks.interfaceIsolated=true;
  metric('inicio');
  const first=addView(partition);
  await timeout(first.webContents.loadURL(target),20000,'primer sitio local');
  const isolated=await first.webContents.executeJavaScript(`({node:typeof require!=='undefined'||typeof process!=='undefined',bridge:typeof window.gravity!=='undefined',title:document.title})`);
  assert(!isolated.node&&!isolated.bridge&&isolated.title==='Gravity Local Fixture','Sitio remoto accedió a Node o puente interno');
  results.checks.remoteRendererIsolated=true;
  // El navegador debe rechazar acceso a los permisos no concedidos.
  const denied=await first.webContents.executeJavaScript(`navigator.permissions?.query({name:'geolocation'}).then(v=>v.state).catch(()=> 'denied')`);
  assert(denied==='denied'||denied==='prompt','Permiso inesperado: '+denied);
  results.checks.permissionsRestricted=true;
  // Verificar la recuperación de una URL fallida sin destruir la pestaña.
  let failed=false;
  const onFail=(_event,code,_detail,_url,mainFrame)=>{if(mainFrame&&code!==-3)failed=true};
  first.webContents.on('did-fail-load',onFail);
  await first.webContents.loadURL('http://127.0.0.1:1/gravity-test-inaccesible').catch(()=>{});
  assert(failed,'No se produjo el evento de red esperado');
  await timeout(first.webContents.loadURL(target),20000,'reintento local');
  assert(first.webContents.getTitle()==='Gravity Local Fixture','No se recuperó tras error de red');
  first.webContents.removeListener('did-fail-load',onFail);
  results.checks.recoveredFromNetworkFailure=true;
  metric('1-pestana');
  for(let i=views.length;i<MAX_VIEWS;i++){
    const view=addView(partition);
    await timeout(view.webContents.loadURL(target+'?synthetic='+i),20000,'pestaña sintética '+i);
  }
  await pause(300);
  metric(MAX_VIEWS+'-pestanas');
  results.checks.syntheticTabsLoaded=MAX_VIEWS;
  if(crashProbe){
    // Solo en proceso TEMPORAL y bajo bandera explícita.
    const part='gravity-native-crash-'+randomUUID();const suspect=addView(part);
    await timeout(suspect.webContents.loadURL(target),20000,'pestaña a bloquear');
    const gone=new Promise(resolve=>suspect.webContents.once('render-process-gone',(_e,details)=>resolve(details?.reason||'unknown')));
    assert(typeof suspect.webContents.forcefullyCrashRenderer==='function','La versión de Electron no admite la prueba de caída');
    suspect.webContents.forcefullyCrashRenderer();
    results.checks.crashReported=await timeout(gone,10000,'evento render-process-gone');
    try{suspect.webContents.close()}catch{}
    const next=addView('gravity-native-retry-'+randomUUID());
    await timeout(next.webContents.loadURL(target),20000,'recuperación tras caída');
    results.checks.rendererRecovered=true;
  }
  results.checks.pass=true;
}
function report(){
  const name='Gravity-Diagnosticos';
  const output=path.join(app.getPath('documents'),name);
  fs.mkdirSync(output,{recursive:true});
  const filename=`gravity-pruebas-nativas-${new Date().toISOString().replace(/[:.]/g,'-')}.json`;
  fs.writeFileSync(path.join(output,filename),JSON.stringify(results,null,2)+'\n',{mode:0o600});
  console.log('Reporte anónimo:',path.join(output,filename));
}
async function finish(){
  results.finishedAt=new Date().toISOString();
  try{report()}catch(e){console.error('No se pudo guardar reporte:',e.message)}
  for(const v of views){try{if(!v.webContents.isDestroyed())v.webContents.close()}catch{}}
  try{if(win&&!win.isDestroyed())win.destroy()}catch{}
  if(server)await new Promise(resolve=>server.close(resolve));
  try{fs.rmSync(scratch,{recursive:true,force:true})}catch{}
}
app.whenReady().then(async()=>{
  try{await run();console.log('GRAVITY ELECTRON NATIVO: PASS',JSON.stringify(results.checks))}
  catch(e){results.errors.push(String(e?.message||e));process.exitCode=1;console.error('GRAVITY ELECTRON NATIVO: FAIL',e.message)}
  finally{await finish();app.quit()}
}).catch(e=>{console.error(e);process.exitCode=1;app.quit()});
