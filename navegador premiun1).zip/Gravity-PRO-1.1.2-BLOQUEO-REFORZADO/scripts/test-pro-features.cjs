'use strict';
// Pruebas puras y aisladas: datos, perfiles, cifrado y herramientas nuevas.
const assert=require('node:assert/strict');
const path=require('node:path'),os=require('node:os'),fs=require('node:fs');
const {sortedPinned,clampReorder,cleanGroup,validateGroup,restoreMeta}=require('../pro-tab-state.cjs');
const profiles=require('../profiles.cjs');
const {vault,httpsOrigin}=require('../credential-vault.cjs');
const {translationLink,READER_SCRIPT,validateReader,cropRect}=require('../page-tools.cjs');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'gravity-09-'));
try{
  const tabs=[{id:'1',pinned:false},{id:'2',pinned:true},{id:'3',pinned:false},{id:'4',pinned:true}];
  assert.deepEqual(sortedPinned(tabs).map(x=>x.id),['2','4','1','3']);
  const arranged=sortedPinned(tabs);
  assert.equal(clampReorder(arranged,'3',0),true);
  assert.deepEqual(arranged.map(x=>x.id),['2','4','3','1'],'pestaña normal no invade fijadas');
  assert.equal(clampReorder(arranged,'2',3),true);
  assert.equal(arranged[1].id,'2','fijada no abandona región protegida');
  assert.equal(cleanGroup('  Mi    Proyecto   '),'Mi Proyecto');
  assert.throws(()=>cleanGroup('../'),/no permitido/);
  assert.equal(validateGroup('Trabajo',Array(11).fill('Otro')),'Trabajo');
  assert.throws(()=>validateGroup('Nuevo',Array.from({length:12},(_,i)=>''+i)),/Máximo/);
  assert.deepEqual(restoreMeta({pinned:true,group:'Trabajo'},['Trabajo']),{pinned:true,group:'Trabajo'});
  assert.deepEqual(restoreMeta({pinned:true,group:'Fantasma'},[]),{pinned:true,group:''});

  const root=path.join(temp,'gravity-directo');
  assert.deepEqual(profiles.available(root),[{id:'default',name:'Original (Gravity)'}]);
  const work=profiles.create(root,'Trabajo');const study=profiles.create(root,'Estudio');
  assert.equal(profiles.available(root).length,3);
  assert.notEqual(work.id,study.id);
  assert.equal(profiles.resolve(root,'default').userData,root);
  assert.equal(profiles.resolve(root,work.id).userData,path.join(root,'profiles',work.id));
  assert.equal(profiles.resolve(root,work.id).partition,`persist:gravity-profile-${work.id}`);
  assert.equal(profiles.selectedFromArgs(['.','--gravity-profile='+work.id],root).id,work.id);
  assert.deepEqual(profiles.relaunchArgs(['.','--gravity-profile='+work.id],'default'),['.']);
  assert.throws(()=>profiles.resolve(root,'../../secreto'),/inválido/);
  assert.throws(()=>profiles.create(root,'Trabajo'),/existe/);
  assert.throws(()=>profiles.create(root,'../perfiles'),/rutas/);
  assert.equal(fs.existsSync(path.join(root,'gravity-profile.json')),false,'ninguna acción sobre perfil original');

  // Sustituto determinista para simular safeStorage: cifrado real en Windows lo aporta DPAPI.
  const key=Buffer.from('0123456789abcdef0123456789abcdef');
  const crypto=require('node:crypto');
  const mock={isEncryptionAvailable:()=>true,getSelectedStorageBackend:()=> 'gnome_libsecret',
    encryptString:raw=>{const iv=crypto.randomBytes(12),cipher=crypto.createCipheriv('aes-256-gcm',key,iv);
      const content=Buffer.concat([cipher.update(raw,'utf8'),cipher.final()]);return Buffer.concat([iv,cipher.getAuthTag(),content]);},
    decryptString:encrypted=>{const iv=encrypted.subarray(0,12),tag=encrypted.subarray(12,28),payload=encrypted.subarray(28);
      const decipher=crypto.createDecipheriv('aes-256-gcm',key,iv);decipher.setAuthTag(tag);return Buffer.concat([decipher.update(payload),decipher.final()]).toString('utf8')}};
  const first=vault(path.join(root,'profiles',work.id),mock);
  const credential=first.add({origin:'https://example.com/login?token=secret',username:'persona',password:'clave-unica-no-escribir'});
  const disk=fs.readFileSync(path.join(root,'profiles',work.id,'gravity-credentials.v1.json'),'utf8');
  assert(!disk.includes('clave-unica-no-escribir'),'contraseña no debe persistir en texto plano');
  assert(!disk.includes('token=secret'),'guardar origen, nunca ruta ni tokens');
  assert.equal(first.list().entries[0].origin,'https://example.com');
  assert.equal(first.revealForClipboard(credential.id,'https://example.com/home'),'clave-unica-no-escribir');
  assert.throws(()=>first.revealForClipboard(credential.id,'https://otro.com/'),/no disponible/);
  assert.throws(()=>first.add({origin:'http://example.com',username:'x',password:'clave'}),/HTTPS/);
  assert.throws(()=>httpsOrigin('https://usuario:clave@example.com'),/HTTPS/);
  const disabled=vault(path.join(root,'profiles',study.id),{isEncryptionAvailable:()=>false});
  assert.equal(disabled.list().available,false);
  assert.throws(()=>disabled.add({origin:'https://example.com',username:'a',password:'x'}),/Cifrado/);
  assert.equal(first.remove(credential.id),true);
  assert.equal(first.list().entries.length,0);

  const url=translationLink('https://ejemplo.com/articulo?q=1','es');
  assert(url.startsWith('https://translate.google.com/translate?'));
  assert(url.includes(encodeURIComponent('https://ejemplo.com/articulo?q=1')));
  assert.throws(()=>translationLink('file:///etc/passwd'),/HTTP/);
  assert.throws(()=>translationLink('https://secret:pass@example.com'),/HTTP/);
  assert.throws(()=>translationLink('https://example.com','ru'),/permitido/);
  assert(READER_SCRIPT.includes('document.querySelector'), 'extracción se hace localmente');
  assert.equal(validateReader({title:'Ejemplo',paragraphs:[{kind:'text',value:'Un párrafo suficientemente largo y legible para modo lectura.'}]}).paragraphs.length,1);
  assert.throws(()=>validateReader({title:'Sin contenido',paragraphs:[]}),/legible/);
  assert.deepEqual(cropRect({x:2,y:3,width:30,height:40},200,100),{x:2,y:3,width:30,height:40});
  assert.throws(()=>cropRect({x:-2,y:3,width:30,height:40},200,100),/inválida/);
  assert.throws(()=>cropRect({x:20,y:80,width:30,height:40},200,100),/inválida/);
  console.log('GRAVITY 0.9.0: fijadas, grupos, perfiles, credenciales protegidas, traductor, lector y recortes OK.');
}finally{fs.rmSync(temp,{recursive:true,force:true})}
