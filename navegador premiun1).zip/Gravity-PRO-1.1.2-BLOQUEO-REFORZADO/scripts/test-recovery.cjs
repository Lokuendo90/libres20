'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {makeCrashMarker}=require('../crash-recovery.cjs');
const {readProfile,writeProfile}=require('../profile-store.cjs');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'gravity-recovery-test-'));
try{
  const marker=makeCrashMarker(dir);
  assert.equal(marker.begin(),false,'primera ejecución no indica choque');
  assert.equal(marker.exists(),true);
  const data=path.join(dir,'gravity-profile.json');
  writeProfile(data,{restore:[{url:'https://example.com/'}],restoreActive:0,bookmarks:[{title:'P',url:'https://example.com/'}]});
  // Simular interrupción: se conserva marcador (no se llama clean).
  const restarted=makeCrashMarker(dir);
  assert.equal(restarted.begin(),true,'el siguiente inicio detecta cierre inesperado');
  assert.equal(readProfile(data).value.restore[0].url,'https://example.com/');
  assert.equal(restarted.clean(),true);assert(!restarted.exists());
  assert.equal(makeCrashMarker(dir).begin(),false,'un cierre limpio no informa accidente');
  assert.equal(marker.clean(),true);
  assert(!fs.readFileSync(data,'utf8').includes('SECRET'));
  console.log('GRAVITY recuperación: marcador de cierre imprevisto y restauración local OK.');
}finally{fs.rmSync(dir,{recursive:true,force:true})}
