'use strict';
// Test de cámara/micrófono VOLUNTARIO y LOCAL. No graba, transmite ni almacena audio/vídeo.
if(!process.argv.includes('--consent-media')){
  console.error('Ejecuta este test solo por decisión propia con npm run native:media');process.exit(2);
}
const {app,BrowserWindow,session,dialog}=require('electron');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),http=require('node:http');
const {randomUUID}=require('node:crypto');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'gravity-camera-test-'));
app.setPath('userData',temp);
let server,win;
const html=`<!doctype html><html lang="es"><meta charset="UTF-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; media-src 'self' blob:; object-src 'none'; connect-src 'none'; form-action 'none'">
<title>Gravity - prueba privada de cámara y micrófono</title>
<style>body{font:16px system-ui,sans-serif;background:#181818;color:#eee;padding:32px;max-width:680px;margin:auto}button{padding:12px;margin:8px 4px;background:#444;color:white;border:0;border-radius:6px}video{width:100%;max-height:290px;background:#000}p{line-height:1.6}</style>
<h1>Prueba local de cámara y micrófono</h1>
<p>Esta prueba no conecta con Internet, no guarda grabaciones y no utiliza tu perfil de Gravity. Pulsa un botón únicamente si deseas permitir acceso a tu dispositivo.</p>
<button id="camera">Probar cámara</button><button id="micro">Probar micrófono</button>
<button id="both">Probar ambos</button><button id="stop">Detener y liberar</button>
<video id="preview" playsinline autoplay muted></video><p id="status" role="status">Dispositivos sin activar.</p>
<script>
let active=null;
const stop=()=>{if(active){active.getTracks().forEach(track=>track.stop());active=null}document.getElementById('preview').srcObject=null;document.getElementById('status').textContent='Dispositivos detenidos.'};
document.getElementById('stop').onclick=stop;
async function test(audio,video){
 stop();
 try{
  const stream=await navigator.mediaDevices.getUserMedia({audio,video});active=stream;
  const preview=document.getElementById('preview');preview.srcObject=stream;
  const tracks=stream.getTracks().map(track=>track.kind);
  document.getElementById('status').textContent='Disponibles: '+tracks.join(' + ')+'. No se graba ni envía nada.';
 }catch(error){document.getElementById('status').textContent='No se pudo obtener permiso o dispositivo: '+error.name+'. Revisa permisos del sistema y dispositivo.'}
}
document.getElementById('camera').onclick=()=>test(false,true);
document.getElementById('micro').onclick=()=>test(true,false);
document.getElementById('both').onclick=()=>test(true,true);
window.addEventListener('beforeunload',stop);
</script></html>`;
async function run(){
  await app.whenReady();
  const port=await new Promise((resolve,reject)=>{
    server=http.createServer((_req,res)=>{res.setHeader('Content-Type','text/html; charset=utf-8');res.setHeader('Cache-Control','no-store');res.end(html)}).once('error',reject).listen(0,'127.0.0.1',()=>resolve(server.address().port));
  });
  const origin=`http://127.0.0.1:${port}`;
  const partition='gravity-media-local-'+randomUUID();
  const ses=session.fromPartition(partition);
  let granted=false;
  ses.setPermissionCheckHandler((_wc,permission,requestOrigin)=>permission==='media'&&granted&&(()=>{try{return new URL(requestOrigin).origin===origin}catch{return false}})());
  ses.setPermissionRequestHandler(async(wc,permission,done)=>{
    if(permission!=='media'||!wc?.getURL()?.startsWith(origin+'/'))return done(false);
    try{
      const answer=await dialog.showMessageBox(win,{
        type:'question',message:'¿Permitir acceso temporal a cámara o micrófono?',
        detail:'Solo la página LOCAL de prueba recibirá el dispositivo. Ningún contenido se envía fuera del equipo. Pulsa Detener al terminar.',
        buttons:['Cancelar','Permitir prueba local'],defaultId:0,cancelId:0,noLink:true
      });
      granted=answer.response===1;done(granted);
    }catch{done(false)}
  });
  ses.setDevicePermissionHandler?.(()=>false);
  win=new BrowserWindow({width:760,height:730,title:'Gravity - prueba privada de multimedia',
    webPreferences:{partition,nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,webviewTag:false}});
  // La partición es la misma que utiliza la ventana; nunca perfil persistente.
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  await win.loadURL(origin+'/');
  win.on('closed',()=>app.quit());
}
run().catch(e=>{console.error('Prueba multimedia:',e.message);process.exitCode=1;app.quit()});
app.on('before-quit',()=>{
  try{if(server)server.close()}catch{}
  try{fs.rmSync(temp,{recursive:true,force:true})}catch{}
});
