'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {createLocalDiagnostics,sanitizedMetadata}=require('../diagnostics.cjs');
const directory=fs.mkdtempSync(path.join(os.tmpdir(),'gravity-diag-test-'));
try{
  const writer=createLocalDiagnostics(directory,{maxBytes:540});
  const secret='https://example.com/path?token=SECRET_PASSWORD';
  assert.equal(writer.write('APP_START',{url:secret,path:'C:/Users/Secrets',query:'contraseña',privateTabs:4,unknown:secret}),true);
  assert.equal(writer.write('RENDERER_CRASH',{reason:'oom',scope:'private',errorCode:-23,details:secret}),true);
  assert.equal(writer.write(secret,{x:1}),false,'lista blanca de eventos');
  assert.deepEqual(sanitizedMetadata({ip:secret,reason:secret,permission:'media',tabCount:3}),{permission:'media',tabCount:3});
  for(let i=0;i<100;i++)writer.write('WEBPAGE_LOAD_FAILED',{errorCode:-105,hostname:secret});
  const files=fs.readdirSync(directory).filter(n=>n.startsWith('gravity-events.jsonl'));
  assert(files.length<=4,'rotación hasta tres archivos históricos');
  const joined=files.map(x=>fs.readFileSync(path.join(directory,x),'utf8')).join('');
  assert(!joined.includes('example.com'), 'no URLs privadas');
  assert(!joined.includes('SECRET_PASSWORD'), 'no credenciales');
  assert(!joined.includes('C:/Users'), 'no rutas');
  assert(joined.includes('WEBPAGE_LOAD_FAILED'));
  console.log('GRAVITY diagnóstico: registros sin datos sensibles, listas blancas y rotación OK.');
}finally{fs.rmSync(directory,{recursive:true,force:true})}
