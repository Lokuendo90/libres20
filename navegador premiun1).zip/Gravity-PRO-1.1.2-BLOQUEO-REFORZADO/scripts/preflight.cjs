'use strict';
const fs=require('node:fs'),path=require('node:path');
const pkg=require('../package.json');
const {validatePublishSettings}=require('../release-channel.cjs');const channel=require('../release-channel.json');
const problems=[];
if(Number(process.versions.node.split('.')[0])<22)problems.push('Se requiere Node.js 22 o posterior.');
const root=path.resolve(__dirname,'..');
const lock=path.join(root,'package-lock.json');
if(!fs.existsSync(lock))problems.push('Falta package-lock.json REAL. Generarlo con npm install --package-lock-only en Windows y conservarlo en el repositorio.');
else{
  try{
    const file=JSON.parse(fs.readFileSync(lock,'utf8'));
    if(!file.lockfileVersion||file.packages?.['']?.version!==pkg.version)problems.push('package-lock.json no coincide con package.json.');
    if(!file.packages?.['node_modules/electron-updater'])problems.push('Falta electron-updater en el bloqueo de dependencias.');
  }catch{problems.push('package-lock.json no es válido.');}
}
const pinned=Object.entries({...pkg.dependencies,...pkg.devDependencies});
for(const [name,version] of pinned)if(!/^\d+\.\d+\.\d+(?:-[A-Za-z0-9.-]+)?$/.test(version))problems.push('Dependencia sin versión exacta: '+name);
if(!validatePublishSettings(pkg.build?.publish,channel))problems.push('El canal del instalador y su feed no coinciden o han sido activados prematuramente.');
if(problems.length){console.error('GRAVITY PREFLIGHT: pendiente\n'+problems.map(x=>' - '+x).join('\n'));process.exitCode=1}
else console.log('GRAVITY PREFLIGHT: versiones fijadas, bloqueo de dependencias y publicación controlada OK.');
