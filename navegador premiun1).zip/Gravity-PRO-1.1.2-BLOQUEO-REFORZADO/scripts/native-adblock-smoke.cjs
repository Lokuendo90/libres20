'use strict';
// Verifica bloqueo real de una solicitud y filtrado visual en Electron usando SOLO localhost.
// No toca perfiles personales ni visita páginas públicas; está destinado a Windows.
const http=require('node:http');
const {app,BrowserWindow,session}=require('electron');
const {createShields,parseList}=require('../privacy-shields.cjs');
const {AD_CSS}=require('../ad-cosmetics.cjs');
(async()=>{
  await app.whenReady();
  const server=http.createServer((req,res)=>{
    if(req.url==='/'){res.setHeader('content-type','text/html; charset=utf-8');
      res.end('<!doctype html><div class="adsbygoogle" id="adbox">ANUNCIO</div><div id="content">CONTENIDO NORMAL</div><img id="adimg" src="/ad-image.png"><img id="okimg" src="/ok-image.png">');}
    else if(req.url.endsWith('.png')){
      res.setHeader('content-type','image/png');
      res.end(Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMB/6XcqzUAAAAASUVORK5CYII=','base64'));
    }else{res.statusCode=404;res.end('no encontrado');}
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const port=server.address().port,url=`http://127.0.0.1:${port}`;
  const rules=parseList([`|${url}/ad-image.png|$image`,'##.adsbygoogle'].join('\n'));
  const shields=createShields({rules});
  const partition='gravity-block-test-'+process.pid+'-'+Date.now();
  const s=session.fromPartition(partition);
  let networkBlocked=0;
  s.webRequest.onBeforeRequest({urls:['http://*/*']},(details,callback)=>{
    const block=shields.shouldBlock(details,url+'/');if(block)networkBlocked++;
    callback({cancel:block});
  });
  const win=new BrowserWindow({show:false,width:900,height:600,webPreferences:{partition,sandbox:true,contextIsolation:true,nodeIntegration:false,webSecurity:true}});
  try{
    await Promise.race([win.loadURL(url),new Promise((_,reject)=>setTimeout(()=>reject(Error('Tiempo agotado')),15000))]);
    await win.webContents.insertCSS(AD_CSS+'\n'+shields.cosmeticCssFor(url),{cssOrigin:'user'});
    await new Promise(resolve=>setTimeout(resolve,400));
    const results=await win.webContents.executeJavaScript(`({
      advertisingDisplay:getComputedStyle(document.querySelector('#adbox')).display,
      contentDisplay:getComputedStyle(document.querySelector('#content')).display,
      realImageComplete:document.querySelector('#okimg').complete,
      realImageWidth:document.querySelector('#okimg').naturalWidth,
      adImageWidth:document.querySelector('#adimg').naturalWidth
    })`);
    const approved=networkBlocked>=1&&results.advertisingDisplay==='none'&&results.contentDisplay!=='none'&&results.realImageWidth>0&&results.adImageWidth===0;
    console.log('Gravity prueba real de bloqueo (solo localhost):',JSON.stringify({approved,networkBlocked,...results}));
    if(!approved)process.exitCode=1;
  }finally{
    try{win.destroy()}catch{}
    s.webRequest.onBeforeRequest(null);
    await new Promise(resolve=>server.close(resolve));
    app.quit();
  }
})().catch(e=>{console.error('Fallo de comprobación nativa:',String(e.message||e));process.exitCode=1;app.quit();});
