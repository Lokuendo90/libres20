'use strict';
const assert=require('node:assert/strict');
const {EventEmitter}=require('node:events');
const {
  baseFilename,cleanDownloadFilename,isDangerousDownload,chooseDangerousDownload
}=require('../download-safety.cjs');
assert.equal(baseFilename('C:\\Users\\Downloads\\archivo.exe'),'archivo.exe');
assert.equal(baseFilename('/tmp/factura.pdf'),'factura.pdf');
assert.equal(cleanDownloadFilename('C:\\secret\\CON.txt'),'_CON.txt');
assert.equal(cleanDownloadFilename('imagen.jpg. '),'imagen.jpg');
assert.equal(cleanDownloadFilename('..'),'descarga');
assert.equal(cleanDownloadFilename('docs/../../../malware.bat'),'malware.bat');
assert.equal(cleanDownloadFilename('factura\u202Efdp.exe'),'facturafdp.exe');
assert.equal(cleanDownloadFilename('\\\\server\\share\\informe.txt'),'informe.txt');
assert(cleanDownloadFilename('x'.repeat(300)+'.pdf').length<=180);
for(const file of ['factura.pdf.exe','foo.cmd','instalador.MSIX','C:\\tmp\\atajo.LNK','script.ps1','maqueta.scr','archive.iso','foto\u202Eexe.jpg'])
  assert.equal(isDangerousDownload(file),true,`Debe advertir: ${file}`);
for(const file of ['logo.svg','informe.pdf','foto.jpg','backup.zip','datos.json'])
  assert.equal(isDangerousDownload(file),false,`No debe interrumpir archivos inocuos: ${file}`);
// El chequeo bidi debe ser estable aunque se llame muchas veces.
for(let i=0;i<15;i++)assert(isDangerousDownload('archivo\u202Egnp.exe'));
function fakeDownload(filename){return {getFilename:()=>filename,cancel(){this.cancelled=true}}}
const win={isDestroyed:()=>false};
let dialogs=0,notices=[];
const dialog={showMessageBoxSync(_win,opts){dialogs++;assert.equal(opts.defaultId,0);return dialogs===2?1:0}};
const denied=fakeDownload('malware.exe');
assert.equal(chooseDangerousDownload(denied,win,dialog,s=>notices.push(s)),false);
assert.equal(denied.cancelled,true);
const accepted=fakeDownload('setup.msi');
assert.equal(chooseDangerousDownload(accepted,win,dialog),true);
assert.equal(accepted.cancelled,undefined);
assert.equal(dialogs,2);
assert.equal(chooseDangerousDownload(fakeDownload('foto.jpg'),win,dialog),true);
assert.equal(dialogs,2,'archivos normales no muestran mensajes');
const noUi=fakeDownload('install.ps1');
assert.equal(chooseDangerousDownload(noUi,null,dialog),false);
assert(noUi.cancelled,'descarga peligrosa sin ventana se cancela');
const noDialog=fakeDownload('setup.exe');
assert.equal(chooseDangerousDownload(noDialog,win,{}),false);
assert(noDialog.cancelled,'sin interfaz de confirmación, no dar permiso automáticamente');
assert(notices.some(s=>s.includes('cancelada')));
console.log('GRAVITY descargas: nombres Windows, extensiones ejecutables, bidi y consentimiento: OK.');
