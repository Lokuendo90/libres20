# Gravity 1.0.0-rc.1: estado verificable

| Área | Realizado en el código | Queda pendiente fuera de este entorno |
|---|---|---|
| Identidad visual | HTML, CSS, `motion.js`, íconos y recursos gráficos conservados | Ejecutar comprobación visual en Windows real |
| Funciones 0.9.5 | Pestañas fijadas/grupos, perfiles, contraseñas, captura, PDF, lector, traducción, favoritos, descargas | Probar cada función en equipo real |
| Rendimiento | Suspensión automática opt-in y suspensión manual reforzada con validación estricta; medidores y test de 10/30 pestañas | Medir cifras RAM/CPU reales con páginas representativas |
| Seguridad | Aislamiento de procesos, permisos por origen, CSP de interfaz, validación IPC; canal HTTPS desactivado | Auditoría de seguridad externa, servicios peligrosos, certificado y dependencias |
| Estabilidad | Perfil atómico con `.bak`, cuarentena de perfil corrupto, recuperación de caída; tests de datos nuevos | Uso prolongado y pruebas de crash en Windows |
| Compatibilidad | Pruebas nativas y externas con perfiles temporales | Logins, YouTube DRM, WhatsApp, Google Meet y Docs en Windows 10/11 |
| Instalador `.exe` | NSIS y script de compilación/validación local | Compilar en Windows, probar equipo limpio, firma real Authenticode |
| Actualizaciones | Módulo condicionado por HTTPS, firma e identidad; solicitud de reinicio segura | Dominio, feed `latest.yml`, certificado y ensayo de actualización firmado |
| Publicación | Puerta de calidad + informes reales obligatorios | Aprobar términos, privacidad, soporte y branding/legalidad |

**Conclusión:** RC es una etapa profesional de ingeniería del producto, **no una certificación de lanzamiento**. No se entrega un `.exe` firmado. No se ha probado esta compilación en Windows 10/11, ni se inventan cifras de rendimiento o de compatibilidad.
