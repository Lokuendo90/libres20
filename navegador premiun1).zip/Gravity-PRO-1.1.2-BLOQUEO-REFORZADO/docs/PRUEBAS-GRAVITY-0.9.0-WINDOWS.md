# Gravity 0.9.0 | Validación en Windows sin dañar la instalación anterior

**Antes de comenzar:** conservar Gravity 0.8.1 intacto y copiar `%APPDATA%\gravity-directo` a un respaldo privado. No usar perfiles o contraseñas reales en las primeras pruebas.

## Prueba de arranque y regresión

1. Abrir `INICIAR-GRAVITY-WINDOWS.bat` en la nueva carpeta.
2. Confirmar que portada, colores, fondo, animaciones y distribución son idénticos a los de 0.8.1.
3. Abrir YouTube, reproducir y pausar un video sin excepción JavaScript `audible`.
4. Probar favoritos, historial, navegación atrás/adelante, descarga pequeña, modo privado y restauración de pestañas normales.
5. Ejecutar `COMPROBAR-GRAVITY-NATIVO-WINDOWS.bat`. Este script no sustituye pruebas manuales de login, sonido, cámara o micrófono.

## Las ocho herramientas (comprobar por separado)

1. **Fijada:** abrir `https://example.com`, fijarla desde ☰, intentar cerrarla con la × y con Ctrl+W (debe quedar protegida). Reiniciar, verificar persistencia y luego desfijarla.
2. **Grupos:** crear `Trabajo` en ☰, asignar una pestaña, crear `Estudio`, asignar otra, reiniciar y comprobar que los grupos y sus pestañas se mantienen. Borrar un grupo no debe cerrar su pestaña.
3. **Recuperación:** abrir una página normal, cerrarla, usar Ctrl+Mayús+T. Probar que una pestaña privada no aparece en la lista de recuperadas.
4. **Traducción:** desde una página pública en inglés, pulsar Traducir, leer el aviso y confirmar. Comprobar que se abre una **nueva pestaña** en Google Translate. Cancelar otra vez y comprobar que no se envía ninguna URL. No probar enlaces con tokens ni páginas privadas.
5. **Capturas:** en una página pública, probar captura visible, completa y Seleccionar zona. Para la última, arrastrar un rectángulo en el editor y guardar el PNG. Comprobar que el contenido y la ruta son correctos. Si la página es enorme, la captura completa debe rechazarla limpiamente, sin bloquear Gravity.
6. **Lector:** abrir una noticia o artículo público, pulsar Modo lectura. Verificar que aparece otra ventana con texto, sin alterar la página original.
7. **Perfiles:** crear un perfil de prueba con otro nombre, cambiar a él y verificar que no ve los favoritos del perfil original. Añadir un favorito de prueba, cambiar de vuelta al Original y confirmar que ambos se mantienen separados. No instalar dos versiones simultáneas.
8. **Credenciales:** entrar en `https://example.com/` (sin iniciar sesión), abrir Mis contraseñas, guardar un usuario y una contraseña **ficticia**. Cerrar el panel, volver a abrirlo, copiar la clave y comprobar el resultado. No permitir guardar desde HTTP ni pestañas privadas. Comprobar que el archivo local no contiene el secreto sin cifrar. Borrar esa credencial de prueba. No usar contraseñas reales hasta completar estas pruebas.

## Compatibilidad y carga

- Inicios de sesión: Gmail, Docs y WhatsApp Web con sesiones de prueba.
- Audio y video: YouTube/Netflix (sujetos a DRM de Electron), cámara y micrófono en Google Meet.
- Memoria: medir con 1, 10 y 30 pestañas; comprobar reposo manual, recuperación y que no se pierdan formularios sin guardar.
- Cierre y restauración: finalizar una sesión normal, reiniciar; repetir tras un cierre forzado solo con datos de prueba.

**Si falla algo:** conservar ambos ZIP y el perfil respaldado. Enviar captura del error sin compartir contraseñas, cookies, tokens ni carpetas de perfil. Los registros locales en `%APPDATA%\gravity-directo\diagnostico` deben revisarse antes de compartirse.

**Instalador público pendiente:** validar `GENERAR-INSTALADOR-BETA-WINDOWS.bat` en una máquina limpia. Para distribuir Gravity al público todavía son obligatorias la firma digital, actualizaciones confiables y auditoría final de seguridad.
