# Pruebas de Gravity 0.8.1 en Windows | mejoras aditivas

**Objetivo:** confirmar que las nuevas herramientas funcionan sin alterar lo que ya está bien.

1. Respalda `%APPDATA%\gravity-directo`, cierra Gravity y descomprime 0.8.1 en una carpeta nueva.
2. Inicia `INICIAR-GRAVITY-WINDOWS.bat`. Comprueba que la portada conserva planeta, paisaje, colores, barra, iconos y animaciones.
3. Abre YouTube y reproduce, pausa y reanuda un vídeo; confirma que el error `audible` no reaparece.
4. Abre dos páginas; en el menú ☰ elige **Duplicar pestaña actual**. Debe crearse una copia sin cerrar la original.
5. Elige **Copiar enlace de esta pestaña** y pega el enlace en Bloc de notas. Debe coincidir exactamente con la barra de direcciones.
6. Abre tres pestañas normales y una privada. Elige **Guardar pestañas en un archivo**. Revisa el `.json` exportado sin compartirlo; debe contener las pestañas normales, **nunca** la privada.
7. Elige **Abrir colección de pestañas**, selecciona ese JSON y acepta. Las pestañas anteriores deben seguir abiertas, y las nuevas deben aparecer en el mismo orden.
8. Con una página normal completamente cargada, selecciona **Guardar página como PDF**. Abre el PDF y revisa formato, páginas, textos e imágenes; prueba una página sencilla y otra dinámica.
9. Repite las comprobaciones de favoritos, historial, descargas, ventanas emergentes y recuperación de pestañas de la versión anterior.
10. Comprueba con 30 pestañas abiertas que importar otra colección no cierra ninguna ni importa solo una parte.

Si ocurre un error, conserva la captura del mensaje sin incluir contraseñas, cookies o sesiones. **No envíes archivos de perfil ni colecciones privadas.**

Si algo falla, cierra 0.8.1, conserva sus archivos para diagnóstico y regresa a la versión estable anterior previa restauración del perfil respaldado si es necesario.

**Pendientes para lanzamiento público:** Electron real en Windows 10/11, instalación desde `.exe`, firma, actualización segura, pruebas de servicios web y auditoría de seguridad independiente.
