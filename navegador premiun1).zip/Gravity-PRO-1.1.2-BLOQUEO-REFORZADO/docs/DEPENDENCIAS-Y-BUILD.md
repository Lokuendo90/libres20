# Preparación de dependencias y compilación de Gravity (Windows)

Estado: **Gravity 0.9.0-beta.1, solo uso privado**. No contiene ejecutable firmado ni servicio de actualizaciones.

## Por qué no se entrega `package-lock.json` en este ZIP

El registro npm no estuvo accesible desde el entorno de preparación (falló la resolución de `registry.npmjs.org`). Un archivo de bloqueo inventado no garantizaría versiones reales. En el equipo Windows que sí tiene npm e Internet, el archivo se obtiene de los paquetes oficiales con:

```powershell
npm install --package-lock-only --ignore-scripts --no-audit --no-fund
npm ci --no-audit --no-fund
npm test
```

Después, **agrega `package-lock.json` al control de versiones** en tu repositorio privado. NO agregues `node_modules/`, archivos del perfil, cookies o contraseñas.

## Crear instalador de ensayo

1. Cierra Gravity; conserva una copia de `%APPDATA%\gravity-directo`.
2. Haz doble clic en `GENERAR-INSTALADOR-BETA-WINDOWS.bat`.
3. El script crea/verifica el `package-lock.json`, ejecuta `npm ci` y `npm test`, y llama a `electron-builder --win nsis --x64 --publish never`.
4. Si la compilación tiene éxito, busca `dist/Gravity-Setup-0.9.0-beta.1-x64.exe` (nombre previsto, no está construido en este ZIP).
5. Pruébalo en una VM limpia antes de usarlo en el equipo principal.

El paquete Windows debe instalarse y desinstalarse sin Node.js **en la máquina receptora**. Comprueba que el perfil persistente no se borre al desinstalar sin consentimiento.

## Antes de publicar

Se necesita un editor responsable de la firma Authenticode (con certificado legítimo), pruebas reales Windows 10/11, política de privacidad y un origen HTTPS confiable para las actualizaciones. `npm run release:guard` debe continuar fallando hasta que todo eso esté documentado y aprobado. No activar una actualización automática apuntando a dominios ficticios.
