# Matriz de pruebas reales de Gravity 0.8.0 en Windows

Registro sugerido por cada caso: `fecha`, `versión Windows`, `versión de Gravity`, `resultado`, `captura sin datos privados`, `pasos para reproducir`. No registrar contraseñas ni sesiones personales.

## Pasos inmediatos (en tu PC)

1. Cierra Gravity anterior. Guarda una copia de `%APPDATA%\gravity-directo` (contiene datos privados; NO la envíes públicamente).
2. Descomprime 0.8.0 en carpeta **nueva**; no mezcles archivos con 0.7.0/0.7.1. No abras dos versiones a la vez, comparten perfil.
3. Ejecuta `INICIAR-GRAVITY-WINDOWS.bat`; verifica que abra y que el diseño siga igual (negro/dorado, planeta, botones, animaciones).
4. Ejecuta `COMPROBAR-GRAVITY-NATIVO-WINDOWS.bat` para probar la UI local y el sandbox usando perfil efímero **sin navegar Internet**.
5. Prueba `COMPROBAR-SITIOS-WINDOWS.bat` de forma voluntaria: visita portadas públicas sin iniciar sesión con el comprobador separado (requiere Internet).
6. Prueba YouTube: reproducir, pausar y cambiar el volumen; el mensaje `details.audible` NO debe volver a aparecer.
7. Prueba Gmail, WhatsApp Web, Google Meet y Docs con cuentas de **prueba**, incluyendo adjuntos, OAuth, cámara/micrófono, compartir pantalla y descargas. Si falla una función, conserva captura sin datos personales.
8. Prueba instalación/actualización solo en PC virtual de ensayo, no sobre el perfil principal.

## Casos críticos adicionales

| ID | Prueba | Esperado |
|---|---|---|
| R01 | Descargar `prueba.txt` / PDF | Se descarga normalmente, sin advertencia ejecutable. |
| R02 | Descargar ejecutable de prueba desde un origen confiable | Aviso de riesgo ANTES de guardar; Cancelar cancela, aceptar continúa. **NO ejecutes archivos desconocidos**. |
| R03 | Descargar archivo con nombre `archivo.pdf.exe` | Advierte que puede ejecutar código. |
| R04 | Cerrar Gravity con descarga grande activa | Diálogo ofrece seguir descargando. Cancelar el cierre mantiene Gravity abierto. |
| R05 | Abrir 1 / 10 / 30 pestañas y cambiar entre ellas | Sin pérdida de pestañas ni congelamiento sostenido. Medir RAM/CPU. |
| R06 | Cerrar y volver a abrir Gravity | Recupera pestañas normales; privadas no persisten. |
| R07 | Forzar cierre del proceso **solo en perfil de ensayo** | Se informa cierre inesperado y se recupera último estado guardado. |
| R08 | Abrir una página HTTPS de laboratorio con certificado inválido | Gravity debe rechazar TLS; no permitir conexiones inseguras por defecto. |
| R09 | Intentar `file:`, `javascript:` y `https://user:pass@...` | Se bloquean. No se envía la URL con credenciales al buscador. |
| R10 | Navegación con ventanas emergentes y OAuth | Respeta límites sin impedir ventanas legítimas de autenticación. |
| R11 | Instalador NSIS beta en equipo limpio | Instala/inicia sin Node.js y desinstala sin borrar perfil por sorpresa. |

**IMPORTANTE:** pruebas automatizadas Node ≠ validación real de Windows, DRM, videollamadas o compatibilidad con cuentas.
