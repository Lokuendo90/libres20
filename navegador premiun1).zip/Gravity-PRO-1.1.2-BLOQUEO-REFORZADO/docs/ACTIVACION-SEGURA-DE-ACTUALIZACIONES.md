# Actualizaciones oficiales de Gravity: requisitos de activación

El código de `update-service.cjs` está incorporado, pero **release-channel.json se distribuye desactivado**. No puede existir una URL confiable de actualizaciones hasta que el propietario confirme su dominio, HTTPS y firma del instalador.

Para preparar una publicación real, el responsable técnico deberá:

1. Tener un dominio propio y un origen de actualizaciones HTTPS con acceso administrativo protegido. No permitir HTTP, credenciales en URLs, localhost ni dominios de ejemplo.
2. Tener una **identidad legal del editor** y certificado Authenticode válido. En `package.json`, indicar `build.win.publisherName` exactamente como corresponda al firmante. No usar valores inventados.
3. Tras pruebas de seguridad y firma, configurar `release-channel.json` con `enabled: true`, `channel: stable`, `expectedPublisher` exacto y `feedUrl` HTTPS terminado en `/`.
4. Configurar `build.publish` en `package.json` como `[ { "provider":"generic", "url":"LA_MISMA_URL_HTTPS_QUE_FEEDURL" } ]`. El build NSIS debe producir `latest.yml`, paquetes y metadatos verificables; no subir archivos manualmente sin verificar todos los hashes y firmas.
5. Generar `package-lock.json` real en Windows y guardarlo en el repositorio privado. Compilar con `npm ci`. La versión pública debe ser estable, sin sufijos `-rc` o `-beta`.
6. Ejecutar pruebas de regresión, perfil, descargas, multimedia, compatibilidad, instalador nuevo y actualizaciones desde la última versión firmada. Verificar que no se borre el perfil ni se pierdan pestañas, cookies o preferencias.
7. Verificar con `Get-AuthenticodeSignature` tanto instalador base como actualización, coincidiendo con el editor esperado. Ejecutar el control de publicación `npm run release:guard` desde Windows con aprobaciones formales y evidencia real.
8. Probar una actualización desde el host HTTPS privado antes de hacerlo público. Después, habilitar el canal para usuarios reales.

El motor usa `electron-updater`, permite descargar actualizaciones oficiales una vez activado y **solicita confirmación antes de reiniciar**. No reinicia mientras existan descargas del navegador o no se pueda guardar el perfil. Los intervalos de consulta son de seis horas. Sin canal validado, permanece inerte y no crea peticiones de red.

La actualización no sustituye una política de gestión de vulnerabilidades: revisar cada actualización estable de Electron, Chromium, electron-builder y electron-updater antes de liberarla.
