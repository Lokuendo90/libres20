# GRAVITY 0.9.5 · Validación en Windows 10 / 11

## Reglas

- No elimines Gravity 0.9.0. Guarda una copia PRIVADA de `%APPDATA%\gravity-directo` con el navegador cerrado.
- Ejecuta pruebas nativas de Electron tras instalar las dependencias; las pruebas de Electron usan perfiles temporales, **no** el perfil real.
- Las pruebas públicas nunca necesitan tus credenciales. La prueba local de cámara o micrófono requiere autorización separada.
- No distribuyas como estable hasta medir y corregir resultados reales.

## Orden de las pruebas

1. `INICIAR-GRAVITY-WINDOWS.bat`. Confirmar interfaz original, corrección de audio YouTube, favoritos, descargas, historial, grupos, pestañas fijadas, perfiles, lector, captura y PDF.
2. `COMPROBAR-GRAVITY-NATIVO-WINDOWS.bat`. Verificar interfaz/aislamiento de WebContentsView y carga de 10 pestañas sintéticas locales; reporta memoria/CPU aproximadas. **No usa Internet**.
3. Si la RAM es suficiente, `COMPROBAR-30-PESTANAS-WINDOWS.bat`. Medir memoria/CPU para 30 pestañas sintéticas; hacerlo voluntariamente tras guardar trabajo.
4. `COMPROBAR-SITIOS-WINDOWS.bat`. Aceptar o cancelar la prueba con red. Abre portadas públicas de YouTube, Gmail, WhatsApp Web, Meet, Docs, Wikipedia, example.com SIN iniciar sesión.
5. `COMPROBAR-CAMARA-MICROFONO-WINDOWS.bat`. Prueba voluntaria local; comprobar autorización del sistema y detener los dispositivos.
6. En el navegador, comprobar con tu cuenta de prueba las funciones que NO prueban los scripts: OAuth, QR, YouTube con audio y vídeo, descargas, Drive, videollamadas y pantalla compartida. No compartas contraseñas ni datos personales.
7. Desde el menú Diagnóstico verificar memoria/CPU con 1, 10 y 30 pestañas **reales** y registrar el uso de CPU/RAM en el Administrador de tareas de Windows durante al menos 15 minutos. Comparar con 0.9.0 en condiciones semejantes. Sin estos datos NO afirmar que consume menos recursos.
8. Probar recuperación después de cierre abrupto solo con PERFIL DE LABORATORIO (nuevo usuario local), nunca arriesgar documentos reales. Inspeccionar que las pestañas normales se restauran y privadas no aparecen.

Los reportes técnicos se guardan en `Documentos\Gravity-Diagnosticos`. Abre y revisa un informe antes de enviarlo. Los informes no contienen URLs privadas, credenciales, imágenes de cámara ni audio.

### Interpretación

- **Prueba nativa aprobada:** demuestra funciones específicas con recursos sintéticos; no demuestra compatibilidad con cualquier sitio.
- **CARGA_HTTPS en prueba de sitios:** la portada cargó por HTTPS, no demuestra autenticación o que Meet/WhatsApp funcionan por completo.
- **RAM/CPU estimada:** muestras de procesos, no indicador definitivo de rendimiento ni de seguridad.
- **Micrófono/cámara aprobados:** acceso local al dispositivo, no prueba una llamada completa.

Si falla una comprobación, conserva el reporte y la captura del mensaje y usa la versión 0.9.0 como respaldo mientras se corrige. No borres el perfil para resolver errores.
