# Gravity 1.0.0-rc.1 | Validación Windows antes de distribución

**Estado: CANDIDATA PRIVADA. No se ha declarado estable ni publicada.** El proceso está diseñado para conservar íntegro el perfil `%APPDATA%\gravity-directo`.

## Pasos simples en tu computadora

1. **Conserva 0.9.5 como respaldo**. Cierra el navegador y copia `%APPDATA%\gravity-directo` a una carpeta PRIVADA en el mismo equipo. El perfil puede contener cookies, tokens e historial: no lo envíes por Internet.
2. Extrae el ZIP **en una carpeta nueva**. No lo copies sobre 0.9.5. No ejecutes dos versiones al mismo tiempo, pues usan el mismo perfil histórico.
3. Ejecuta `INICIAR-GRAVITY-WINDOWS.bat`. Haz una comprobación visual y confirma que siguen los 8 módulos de 0.9.0, pestañas, grupos y perfiles. El instalador todavía no es necesario para abrirlo.
4. Ejecuta `VERIFICAR-GRAVITY-WINDOWS.bat`. Corre tests simulados y Electron real en modo local, incluyendo 10 y 30 pestañas. Usa un perfil temporal distinto al habitual.
5. Ejecuta `COMPROBAR-SITIOS-WINDOWS.bat` **solo si aceptas abrir sitios públicos en Internet**. Este comprobador no inicia sesión ni utiliza cookies personales.
6. Ejecuta `COMPROBAR-CAMARA-MICROFONO-WINDOWS.bat` si quieres probar tus dispositivos. Requiere consentimiento. No graba ni transmite audio o vídeo.
7. Ejecuta `REVISAR-RESULTADOS-WINDOWS.bat`. Busca informes recientes en `Documentos\Gravity-Diagnosticos`. Si falta una prueba, marca publicación PENDIENTE.
8. Abre manualmente con una cuenta de PRUEBAS no sensible YouTube (audio y vídeo), Gmail, WhatsApp Web, Google Meet (mic/cámara), Docs, un PDF, un sitio de comercio, y una sesión de descarga. Las pruebas automáticas NO sustituyen esta verificación.
9. En un Windows 10/11 limpio o máquina virtual, ejecuta `GENERAR-INSTALADOR-BETA-WINDOWS.bat` para construir el `.exe` de prueba (necesita npm e Internet). Prueba instalación, creación de accesos directos, apertura sin Node.js en el equipo receptor, cierre, actualización de prueba y desinstalación preservando el perfil.
10. Para publicar: documenta compatibilidad y consumo medido; obtén una firma Authenticode auténtica de tu editor; configura el canal HTTPS propio y sus metadatos; verifica la firma de todos los ejecutables y haz una auditoría de seguridad.

**No eliminar ni renombrar:** `gravity-profile.json`, `gravity-credentials.v1.json`, datos de Chromium, perfiles adicionales, `profiles.json`, `app/assets`, `app/style.css`, `app/index.html`, `app/motion.js`.

## Limitaciones técnicas vigentes

- `Electron 44.9.3` (fijado a una versión estable): no se actualiza arbitrariamente sin pruebas.
- Las pruebas sintéticas de 30 pestañas sirven para medir tendencias, no demostrar rendimiento con páginas reales pesadas.
- Sin certificado Authenticode, NO distribuir instaladores públicos. Un `.exe` sin firma puede activar advertencias de Windows.
- Las actualizaciones automáticas están **programadas pero desactivadas** hasta establecer una infraestructura oficial HTTPS y configurar el editor firmante. Sin esas condiciones no se contacta a servidores de actualización.
- `npm audit` necesita acceder a Internet y se ejecuta antes de crear el instalador de prueba. Sin informe positivo no deberías hacer un lanzamiento público.
