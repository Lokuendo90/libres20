# Escudos Gravity 1.1: arquitectura de protección y límites reales

## Flujo y aislamiento

La interfaz local conserva CSP, sandbox, contextIsolation y su puente IPC restringido. Las WebContentsView externas no reciben preload ni acceso a Node.js. `privacy-shields.cjs` intercepta solicitudes y cabeceras en sesiones Electron. Dado que Electron solo permite el último listener por evento, la política de anuncios, cookies y cabeceras se integra en un único conjunto de manejadores en `configureSession`. Al cerrar la última pestaña privada se eliminan estos manejadores y se solicita borrar sus datos temporales.

## Publicidad y rastreadores

El motor incluye una **pequeña lista integrada de dominios conocidos**, bloquea dominios y subdominios a nivel de recursos, excluye documentos principales y ofrece excepciones por origen. Las listas optativas EasyList/EasyPrivacy se descargan directamente por HTTPS desde sus servidores oficiales y se guardan localmente, mediante archivo temporal y reemplazo atómico. Se aplican solo reglas sencillas de tipo `||dominio^` y un subconjunto estricto de opciones `third-party`/tipos. Se ignoran de forma conservadora las demás reglas, nunca se reinterpretan ampliando su alcance. No se ejecutan scripts de terceros incluidos en listas y no se incorpora el motor de Brave, uBlock o Ghostery. Se inyecta una hoja cosmética mínima en páginas para ocultar contenedores publicitarios reconocibles, sin cambiar `app/style.css`.

**NO garantiza bloqueo total de publicidad**, especialmente anuncios de vídeo integrados en el mismo dominio, reglas cosméticas sofisticadas, anuncios nativos y técnicas antiadblock. Para alcanzar la cobertura de Brave será necesario evaluar una biblioteca mantenida con implementación completa de sintaxis ABP/uBO, pruebas, licencias y actualización segura de reglas.

## Cookies y registros

La función de cookies cruzadas retira `Cookie` en solicitudes de terceros y `Set-Cookie` en respuestas con primer origen conocido. El cálculo de parte principal es conservador y no reemplaza la Public Suffix List actualizada; algunas técnicas de rastreo pueden escapar. Se envían señales DNT/GPC donde las cabeceras sean admitidas por el motor y el sitio, sin garantía de respeto por parte del servidor. No se altera el consentimiento legal ni se auto-hace clic en banners.

La limpieza al salir es optativa y ejecuta eliminación de almacenamiento de la sesión persistente cuando la ventana se cierra normalmente. Si Windows fuerza un cierre o el proceso se bloquea, puede no completarse. Los favoritos e historial se mantienen localmente salvo acción explícita del usuario.

## Navegación inteligente

`smart-search.cjs` tiene alias exactos para dominios conocidos, sin consulta en red por cada pulsación. Las sugerencias se ordenan según favoritos e historial **locales**. Las consultas generales continúan en el buscador seleccionado. El botón «Buscar en varios motores» abre tres pestañas SOLO con una acción explícita; no implementa una búsqueda agregada centralizada ni un servicio de perfilado en servidores de Gravity. Las pestañas privadas no se añaden al historial ni personalizan sugerencias persistentes.

## Advertencias de sitios y archivos

`site-risk.cjs` ofrece indicadores heurísticos limitados: punycode, direcciones IP directas y algunas semejanzas sospechosas. Los enlaces deben seguir las reglas HTTP/HTTPS existentes; no se examina malware inyectado ni se consulta un servicio global de reputación. Los proveedores de reputación comercial tienen términos de uso y credenciales; no se integran APIs no autorizadas.

En Windows se puede pedir examen a Microsoft Defender mediante `MpCmdRun.exe -Scan -ScanType 3 -File`. El comando usa argumentos sin shell, limita el tiempo y nunca ejecuta el archivo descargado. Según Microsoft, resultado 0 NO garantiza ausencia de detecciones; resultado 2 puede indicar malware pendiente o error. La interfaz evita abrir archivos con alerta, pero no elimina la necesidad de usar antivirus actualizado y de analizar descargas sospechosas fuera de Gravity.

## IP pública, anonimato y telemetría

El navegador **no controla las IP externas asignadas por el proveedor**. Una IP inventada no serviría para enrutar respuestas. Se necesita VPN, Tor o proxy REAL para enrutar la conexión. Incluso con ellos, anonimato y geolocalización dependen de DNS/WebRTC, configuración, políticas y del servicio externo. Actualmente Gravity NO tiene VPN incorporada ni afirma que el usuario sea anónimo.

Gravity no incluye envío de historial a un backend propio; los diagnósticos técnicos están en el perfil local. Los servicios visitados, buscadores, proveedores de listas (cuando se actualizan manualmente) y antivirus pueden tener sus propias políticas. Esta arquitectura no suprime esos registros externos.

## Verificaciones del producto antes de lanzamiento

- Pruebas nativas Windows con conexiones reales, solicitudes bloqueadas y casos de no bloqueo (inicios de sesión, pagos, videollamadas).
- Evaluación comparativa de anuncios con una suite reproducible en sitios diversos y corrección de falsos positivos.
- Prueba de limpieza de cookies en sesiones reales, incluso interrumpiendo Windows y recuperando estado.
- Evaluación de reputación de URLs con proveedor autorizado para uso comercial, y pruebas de detección/falsos positivos.
- Validar Microsoft Defender con archivos de prueba inocuos y las opciones del antivirus, nunca con malware real sin aislamiento experto.
- Auditoría de privacidad de IPC, storage, DNS/WebRTC y cadenas de suministro.
- Fijar dependencias con un `package-lock.json` creado REALMENTE desde npm, ejecutar auditoría de dependencias y crear/firma del `.exe` para Windows.

Referencias técnicas y licencias: https://brave.com/shields/ , https://github.com/electron/electron/blob/main/docs/api/web-request.md , https://easylist.to/pages/licence.html , https://learn.microsoft.com/en-us/defender-endpoint/command-line-arguments-microsoft-defender-antivirus , https://developers.google.com/safe-browsing/reference/rest .
