> Historial de matriz anterior. Para la nueva versión **0.8.0**, usa primero `PRUEBAS-GRAVITY-0.8.0-WINDOWS.md`.

# Matriz real de aceptación de GRAVITY 0.7.0 · completar en Windows

**PENDIENTE**: esta tabla contiene procedimientos, no resultados inventados. Usar Windows 10 y 11 x64, con perfiles de laboratorio respaldados. Anotar versión, dispositivo, DPI, memoria, capturas y resultado con fecha para cada caso.

## Antes de empezar

1. Cierra Gravity y **respalda** `%APPDATA%\gravity-directo` completo, incluyendo sesiones Chromium, con el navegador cerrado. Descomprime 0.7.0 aparte.
2. Instala Node.js 22+ y las dependencias (`npm install` si procede), ejecuta `npm test` y abre `INICIAR-GRAVITY-WINDOWS.bat`.
3. Para primeras pruebas utiliza un **perfil Windows de prueba** sin cuentas bancarias ni datos sensibles.
4. Puedes ejecutar `COMPROBAR-SITIOS-WINDOWS.bat` para comprobar solo la carga de portadas públicas en Electron. Esta prueba es opcional y necesita Internet. **No sustituye las pruebas de abajo**.

## Casos manuales obligatorios

| ID | Caso / pasos | Qué debe pasar | Estado |
|---|---|---|---|
| W01 | Abrir, minimizar, maximizar, 100/125/150% DPI; 1000×680 y 1920×1080 | Diseño negro/dorado sin cortes ni botones desplazados | PENDIENTE |
| W02 | Abrir 1, 10, 30 pestañas; reiniciar; volver a medir | Reaparecen todas en su orden, solo se carga activa inicialmente | PENDIENTE |
| W03 | Restaurar 1.004 favoritos, exportar, cerrar y volver | Sin pérdida, exportación exacta | PENDIENTE |
| W04 | Forzar caída de un renderizador en ambiente aislado (DevTools de ensayo), Reintentar | Reaparece la página en proceso nuevo y se registra evento sin URLs | PENDIENTE |
| W05 | Finalizar proceso completo de Gravity con perfil de prueba y reiniciar | Aviso de cierre imprevisto y recuperación del último guardado; ningún formulario no guardado debe prometerse recuperado | PENDIENTE |
| W06 | Abrir YouTube: inicio, reproducir, pantalla completa, sonido, velocidad y 1080p | Reproducción y controles funcionales o defecto documentado | PENDIENTE |
| W07 | Gmail de prueba: login, 2FA, envío y archivos adjuntos de prueba | Autenticación y funciones de correo normales | PENDIENTE |
| W08 | WhatsApp Web de laboratorio: QR, mensajes, adjuntos | Inicio de sesión y uso correcto | PENDIENTE |
| W09 | Google Meet: sala propia de prueba, cámara/micro, compartir pantalla, salir | Permisos correctos, sesión y captura; documentar fallos | PENDIENTE |
| W10 | Google Docs: abrir un documento no privado, escribir, imprimir, descargar PDF | Editor, teclado y descargas funcionan | PENDIENTE |
| W11 | Descargar archivo de prueba grande, pausar, reanudar y cancelar | Descargas estables; reposo no afecta su pestaña mientras corre | PENDIENTE |
| W12 | Repetir permisos (HTTPS, HTTP, `localhost`); revocar y volver a pedir | HTTP público no autoriza cámara/mic, HTTPS pide consentimiento, revocación y expiración funcionan | PENDIENTE |
| W13 | Probar `file:`, `javascript:` y redirección a esquema local desde página de prueba | No ejecuta ni abre rutas locales | PENDIENTE |
| W14 | Probar certificado TLS inválido y DNS fallido en dominio de laboratorio | Navegación muestra error; no se omite el error TLS | PENDIENTE |
| W15 | Medir RAM/CPU con 1/10/30 pestañas, más animaciones activadas y desactivadas | Capturar MB, CPU, duración y comparar con 0.6.1; no declarar mejoras numéricas sin datos | PENDIENTE |
| W16 | Abrir 25 sesiones privadas de forma secuencial | Sin historial privado persistido; cookies aisladas, cierre y permisos correctos | PENDIENTE |
| W17 | OAuth/popups (Google/Microsoft de prueba) y ventanas masivas | OAuth válido cuando corresponda y límites contra abuso | PENDIENTE |
| W18 | Generar instalador beta con NSIS e instalar/desinstalar en una VM limpia | Ejecuta sin Node.js para el usuario final; conserva el perfil salvo elección expresa | PENDIENTE |
| W19 | Build reproducible y firma Authenticode del instalador final | Firma válida, cadena verificable y actualización segura en canal propio | PENDIENTE |

## Criterios de avance

No declarar Gravity 1.0 ni distribución pública con fallos críticos conocidos, pérdida de datos, escapes del sandbox, permisos indebidos o pruebas incompletas. Registrar evidencia real de al menos W01–W17 antes de considerar la fase 4 cerrada, y completar W18–W19 para la fase 5.
